/* CEAIA revamp — shared bilingual content. Every text is [English, 中文]. */
window.CEAIA = {
  meta: {
    title: ["CEAIA Revamp: Navigation, Landing & Design Principles", "CEAIA 改版：导航、首页与设计原则"],
    sub: ["Context, options, evidence and recommendations for the landing-screen revamp (Jira AIWPB-10173)", "首页改版（Jira AIWPB-10173）的背景、方案、依据与建议"],
    owner: ["Product design (UCD), CEAIA", "CEAIA 产品设计（UCD）"],
    date: "15 Oct 2026",
    status: ["Draft for discussion with PO", "待与 PO 讨论的草案"]
  },

  tldr: [
    [["Keep one shared landing, but make Chat and Task an explicit choice.", "保留统一的首页入口，但让 Chat 与 Task 成为明确的选择。"],
     ["Putting the Super agent inside the agent list hides a mode change behind a persona choice. A visible mode switch in the composer meets the single-landing goal without breaking what happens after Send.", "把 Super agent 塞进 agent 列表，等于把“模式切换”伪装成“选人”。在输入区放一个可见的模式开关，既满足统一首页，又不破坏发送之后的流程。"]],
    [["Agent selector position depends on what it controls and when.", "Agent 选择器放哪，取决于它控制什么、何时可改。"],
     ["Nine real products put it in four different places. Recommend: inside the composer, left tool group, before sending; shown read-only in the session header once locked.", "9 个真实产品放在 4 种位置。建议：发送前放在输入框内左侧工具组；会话开始锁定后，以只读形式显示在会话标题区。"]],
    [["Chat history stays with the conversation module, not the global menu.", "对话历史跟随对话模块，而不是常驻全局菜单。"],
     ["Standard users get history where they chat; expert and admin users keep full-width canvases. Add a remembered collapse state and search.", "普通用户在对话处看到历史；专家/管理员保留完整画布。增加记忆折叠状态与搜索。"]],
    [["Some items are standards, not preferences.", "部分事项是标准，不是偏好。"],
     ["User bubble colour comes from the Group X-Cutting Conversational template. Disclaimer wording needs Compliance sign-off. Bubble width and banner prominence can be improved.", "用户气泡颜色来自集团 X-Cutting 对话模板；免责声明措辞需合规审批。气泡宽度与横幅显著度可以优化。"]],
    [["Design principles must ladder up from Group, not be generated in isolation.", "设计原则必须自上而下承接集团，而不是孤立生成。"],
     ["Proposed: 5 CEAIA principles derived from HSBC purpose, CX principles, the Group digital experience ambition and AI-native principles, each with a test and a measure.", "提议：5 条 CEAIA 原则，承接汇丰宗旨、CX 原则、集团数字体验愿景与 AI 原生原则，每条都有检验问题和衡量指标。"]]
  ],

  timeline: [
    { d: "May 2025", t: ["Use case defined (WPB-018 Transformation AI Agent)", "用例定义（WPB-018 转型 AI Agent）"], k: "src" },
    { d: "3 Jun 2026", t: ["Agentic work draft: Super agent explored as a separate mode", "Agentic work 草案：Super agent 作为独立模式探索"], k: "design" },
    { d: "24 Jun 2026", t: ["Mode entry handling. History: merged vs separate. PO chose separate Chat / Task", "模式入口方案。历史记录：合并 vs 分开。PO 选择 Chat / Task 分开"], k: "decision" },
    { d: "14 Aug 2026", t: ["Navigation: 4 options compared; Option 3 confirmed by product", "导航：4 个方案对比；产品确认方案 3"], k: "decision" },
    { d: "Mid Sep 2026", t: ["Super agent POC built and released without design review (13-step tour)", "Super agent POC 未经设计评审即开发上线（13 步引导）"], k: "risk" },
    { d: "23 Sep 2026", t: ["Landing ideation prototype and Evals entry options shared", "首页构想原型与 Evals 入口方案分享"], k: "design" },
    { d: "End Sep 2026", t: ["Main menu restructure proposal incl. Classic / Super agent switch", "主菜单重构提案，含经典 / Super agent 切换"], k: "design" },
    { d: "8 Oct 2026", t: ["Jira AIWPB-10173 assigned with AI-generated mocks and videos", "Jira AIWPB-10173 指派，附 AI 生成的样稿和视频"], k: "src" },
    { d: "9 Oct 2026", t: ["Discussion: single landing, unified sidebar, history; call held", "讨论：统一首页、统一侧栏、历史记录；电话沟通"], k: "src" },
    { d: "13 Oct 2026", t: ["BA review list and Phase 1 deliverables; BA-made design principles circulated", "BA 意见清单与一期交付物；BA 自制设计原则流传"], k: "risk" }
  ],

  common: [
    { s: "agree", t: ["One landing that feels unified, with a seamless switch between classic and Super agent", "统一观感的首页，经典与 Super agent 之间无缝切换"], n: ["Agree on the goal. Disagree on the mechanism (see Topic 1).", "目标一致；实现方式有分歧（见议题 1）。"] },
    { s: "agree", t: ["Role-based UX", "基于角色的体验"], n: ["Raised by design on 9 Oct and already in the menu proposal (standard vs expert / admin).", "设计在 10 月 9 日提出，菜单提案中已分标准用户与专家/管理员。"] },
    { s: "agree", t: ["Improve sidebar structure", "优化侧栏结构"], n: ["Already analysed in Main menu improvements (5 as-is issues).", "主菜单优化中已分析（5 个现状问题）。"] },
    { s: "agree", t: ["Helper chips near the prompt", "输入框旁的辅助提示"], n: ["Fits Intent-first. Make chips role-aware.", "符合“意图优先”，建议按角色配置。"] },
    { s: "agree", t: ["User bubble is too wide", "用户气泡过宽"], n: ["Valid. Apply a max width; colour stays.", "合理。设置最大宽度；颜色不变。"] },
    { s: "partial", t: ["Guide message and disclaimer are too prominent", "引导语与免责声明过于醒目"], n: ["Partly. Use progressive disclosure; wording needs Compliance.", "部分认同。采用渐进披露；措辞需合规审批。"] },
    { s: "partial", t: ["Platform capabilities and roadmap pages", "平台能力与路线图页面"], n: ["Useful idea; content claims and roadmap exposure need governance.", "思路可取；内容真实性与路线图公开需要治理。"] },
    { s: "evidence", t: ["Super agent as an item in the agent selector", "把 Super agent 作为 agent 选择器的一项"], n: ["Not a pure UI change. Needs options analysis (Topic 1).", "不是纯 UI 改动，需要方案分析（议题 1）。"] },
    { s: "evidence", t: ["Chat history always visible in the sidebar", "对话历史常驻侧栏"], n: ["Conflicts with admin journeys. See Topic 6.", "与管理员旅程冲突，见议题 6。"] },
    { s: "standard", t: ["Lighter user bubble colour", "更浅的用户气泡颜色"], n: ["Group standard. Change requests go to X-Cutting design leads.", "集团标准。变更需提交 X-Cutting 设计负责人。"] }
  ],

  audit: {
    rows: [
      { p: "01 Make it theirs", proof: "2x · endowment effect (mug experiment, 1991)", fit: "no",
        f: ["The study measures how people overvalue goods they own. It says nothing about greeting by name or UI personalisation.", "该研究衡量人们对已拥有物品的高估，与“叫出名字”或界面个性化无关。"],
        v: "reframe", to: "P3", vt: ["Reframe as role-shaped experience", "改写为“按角色塑形”"] },
      { p: "02 Simple by default", proof: "3 of 5 · progressive disclosure (NN/g 2006)", fit: "yes",
        f: ["Valid evidence. But progressive disclosure hides advanced options; it does not justify hiding modes that behave differently (Chat vs Task).", "依据成立。但渐进披露是隐藏高级选项，不能用来隐藏行为不同的模式（Chat 与 Task）。"],
        v: "keep", to: "P1", vt: ["Keep, inside Intent first", "保留，并入“意图优先”"] },
      { p: "03 Function before form", proof: "10 sec · response-time limits (Nielsen 1993)", fit: "no",
        f: ["The source is about system latency and progress feedback, not about function versus form. The title treats UI as decoration, which contradicts the Group 'high-taste' ambition.", "原文讲的是系统响应时间与进度反馈，不是功能与形式的取舍。标题把 UI 当装饰，与集团“high-taste”愿景相悖。"],
        v: "reframe", to: "P2", vt: ["Keep 'show progress', drop the title", "保留“显示进度”，弃用标题"] },
      { p: "04 Lead the eye", proof: "20% · words read (NN/g 2008, web articles)", fit: "part",
        f: ["Scanning behaviour is real, but the study covers web articles, not AI answers. This is a content-design guideline.", "扫读行为属实，但研究对象是网页文章而非 AI 回答。属于内容设计规范。"],
        v: "move", to: "STD", vt: ["Move to standards (content design)", "移入标准层（内容设计）"] },
      { p: "05 Show the working", proof: "46% · trust in AI (KPMG / Univ. of Melbourne 2025)", fit: "yes",
        f: ["Strongest item. Matches Group AI-native principle 'Trust and accountability'.", "最有力的一条，与集团 AI 原生原则“信任与问责”一致。"],
        v: "keep", to: "P2", vt: ["Keep, with credit", "保留并署名"] },
      { p: "06 Earn its place", proof: "+32 pts · McKinsey Business Value of Design 2018", fit: "no",
        f: ["A company-level correlation between design maturity and revenue. It cannot test a feature. The same study credits design leadership and process, which argues for a design-led process.", "这是公司层面“设计成熟度与营收”的相关性，无法检验单个功能。该研究恰恰强调设计领导力与流程。"],
        v: "move", to: "MEA", vt: ["Move to measures (business value)", "移入衡量层（业务价值）"] },
      { p: "07 Built to last", proof: "34% · faster with a design system (Figma 2019)", fit: "part",
        f: ["Measures designer speed, not user value. The Group already has Bee-DS / HIVE, so this is a standard, not a product principle.", "衡量的是设计师效率而非用户价值。集团已有 Bee-DS / HIVE，这属于标准而非产品原则。"],
        v: "move", to: "STD", vt: ["Move to standards", "移入标准层"] }
    ],
    structural: [
      [["Not anchored to Group", "未承接集团"], ["Ignores HSBC purpose, CX principles, the digital experience ambition, AI-native principles and trust drivers.", "忽略汇丰宗旨、CX 原则、数字体验愿景、AI 原生原则与信任驱动因素。"]],
      [["Mixes levels", "层级混淆"], ["Values, KPIs, standards and guidelines are all called principles. The Group exploration warns against exactly this.", "价值观、KPI、标准、规范都叫“原则”。集团探索稿明确提醒避免这一点。"]],
      [["Tied to journey moments", "绑定旅程节点"], ["Ordered Arrive → Return, so each principle applies to one moment only. Principles should be cross-cutting decision rules.", "按“到达→返回”排序，每条只适用一个时刻。原则应是贯穿始终的决策规则。"]],
      [["One persona", "单一画像"], ["'One of 10,000+ who won't read the manual' leaves out expert / admin users and the BA, PM, PMO roles.", "“一万人中不读手册的那个”遗漏了专家/管理员以及 BA、PM、PMO 角色。"]],
      [["No conflict rule", "无冲突规则"], ["Nothing says what wins when 'Simple by default' and 'Show the working' disagree.", "没有说明“默认简单”与“展示过程”冲突时谁优先。"]],
      [["Statistics as decoration", "数据作装饰"], ["Numbers are presented as proof of principles they do not test.", "数字被当作“证明”，但并不检验对应原则。"]],
      [["AI specifics missing", "缺失 AI 特性"], ["No variability (non-deterministic output), data protection (PII rule), autonomy levels or multi-modality.", "没有不确定输出、数据保护（PII）、自主程度、多模态等内容。"]]
    ],
    strengths: [
      ["Plain, memorable language", "语言平实易记"],
      ["Each principle has a test question — good practice we keep", "每条都有检验问题——这是好做法，予以保留"],
      ["Names the agentic-AI trust problem", "点出了 Agentic AI 的信任问题"],
      ["'Feature-led → Job-led' is a useful shift", "“功能导向→任务导向”的转变有价值"]
    ]
  },

  ladder: [
    { id: "purpose", lv: ["HSBC purpose", "汇丰宗旨"], q: ["Why we exist", "我们为何存在"], v: ["Opening up a world of possibility", "Opening up a world of possibility（开启无限可能）"] },
    { id: "mission", lv: ["Mission", "使命"], q: ["What we aim to be", "我们要成为什么"], v: ["To be the preferred international financial partner for our clients", "成为客户首选的国际金融伙伴"] },
    { id: "prio", lv: ["Strategic priorities", "战略重点"], q: ["Where we focus", "聚焦何处"], v: ["Drive customer-centricity · Deliver focused sustainable growth · Be simple and agile", "以客户为中心 · 聚焦可持续增长 · 简单敏捷"] },
    { id: "values", lv: ["Values", "价值观"], q: ["How we work", "如何工作"], v: ["We get it done · Take responsibility · Value difference · Succeed together", "We get it done · Take responsibility · Value difference · Succeed together"] },
    { id: "ambition", lv: ["Digital experience ambition", "数字体验愿景"], q: ["Group design team", "集团设计团队"], v: ["Wherever design happens – human, AI, or both – we scale high-taste, effortless and trusted digital experiences, grounded in real user context and shared standards.", "无论设计由人、AI 或两者完成，我们规模化交付高品位、轻松、可信的数字体验，立足真实用户情境与共享标准。"] },
    { id: "cx", lv: ["CX principles", "CX 原则"], q: ["What customers should experience", "客户应获得的体验"], v: ["Delightfully personalised · Connecting opportunities · Inspiring confidence · Remarkably effortless", "贴心个性化 · 连接机遇 · 激发信心 · 极致轻松"] },
    { id: "gdp", lv: ["Group design principles (draft)", "集团设计原则（草案）"], q: ["How design teams work", "设计团队如何工作"], v: ["Understand human context · Connect the whole journey · Make the valuable path effortless · Earn trust · Create with judgement then make it real", "理解人的情境 · 连接完整旅程 · 让有价值的路径轻松 · 赢得信任 · 以判断创造并落地"] },
    { id: "ai", lv: ["AI-native product principles", "AI 原生产品原则"], q: ["How AI experiences behave", "AI 体验如何表现"], v: ["Intent · Multi-modality · Variability · Trust and accountability · Familiarity", "意图 · 多模态 · 可变性 · 信任与问责 · 熟悉感"] },
    { id: "ceaia", lv: ["CEAIA product principles", "CEAIA 产品原则"], q: ["This proposal", "本提案"], v: ["P1 Intent first · P2 Visible work · P3 Role-shaped · P4 Connected journey · P5 Standards first", "P1 意图优先 · P2 过程可见 · P3 按角色塑形 · P4 旅程连贯 · P5 标准为先"], hl: true },
    { id: "std", lv: ["Shared standards", "共享标准"], q: ["How we deliver consistently", "如何一致交付"], v: ["Bee-DS / HIVE guidelines, patterns, components · X-Cutting templates · Specialist lenses: AI, Platform, Accessibility, Conversational", "Bee-DS / HIVE 规范、模式、组件 · X-Cutting 模板 · 专项视角：AI、平台、无障碍、对话"] },
    { id: "measure", lv: ["Measures", "衡量"], q: ["How we know it works", "如何验证"], v: ["Trust drivers: Reliable · Capable · Relationship · Integrity · Secure — plus outcomes, business value, operational quality, inclusion", "信任驱动：可靠 · 专业 · 关系 · 诚信 · 安全——以及成果、业务价值、运营质量、包容性"] }
  ],

  positioning: [
    [["What it is", "产品是什么"], ["An AI-native platform (intelligence layer + knowledge fabric) that works alongside transformation teams, connected to Jira and Confluence.", "AI 原生平台（智能层 + 知识网络），与转型团队协作，连接 Jira 与 Confluence。"]],
    [["Who uses it", "谁在用"], ["Core: BA, PM, PMO. Related: QA, PO, Tech lead. Access: standard vs expert / admin.", "核心：BA、PM、PMO；相关：QA、PO、技术负责人；权限：标准用户 vs 专家/管理员。"]],
    [["Where it is going", "发展方向"], ["Assistant mode (agents, user in control) → Autonomous collaborative mode (Super agent plans and executes, user reviews and directs).", "助手模式（多 agent，用户主导）→ 自主协作模式（Super agent 规划执行，用户审阅与指挥）。"]],
    [["Non-negotiables", "硬性约束"], ["Information security, compliance review, Public / Internal data only, no PII, human accountability.", "信息安全、合规审查、仅限公开/内部数据、禁止 PII、人负最终责任。"]]
  ],

  principles: [
    { id: "P1", n: ["Intent first, right-sized AI", "意图优先，量体裁衣"],
      d: ["Start from what the user wants done. Offer the right depth — quick agent chat or planned Super agent task — and make the difference visible before work starts.", "从用户要完成的事出发。提供合适的深度——快速 agent 对话或有计划的 Super agent 任务——并在开始前让差异可见。"],
      from: ["Make the valuable path effortless · Intent · Remarkably effortless · Be simple and agile", "让有价值的路径轻松 · 意图 · 极致轻松 · 简单敏捷"],
      doo: ["One shared landing; explicit Chat / Task choice; role-aware starters; advanced options disclosed progressively.", "统一首页；明确的 Chat / Task 选择；按角色的起始提示；高级选项渐进披露。"],
      test: ["Before pressing Send, can the user tell what will happen and what it will produce?", "按下发送前，用户能否知道会发生什么、会产出什么？"],
      anti: ["Hiding a mode change inside an agent list.", "把模式切换藏在 agent 列表里。"],
      m: ["First-attempt success · mode switch-backs · time to first useful output", "首次成功率 · 模式回切率 · 首个有效产出时间"] },
    { id: "P2", n: ["Visible work, accountable humans", "过程可见，人来负责"],
      d: ["Show plan, steps, sources, progress and limits. Humans approve consequential steps. AI is always signalled.", "展示计划、步骤、来源、进度与局限。关键步骤由人审批。始终标识 AI。"],
      from: ["Earn trust · Trust and accountability · Variability · Inspiring confidence · Take responsibility", "赢得信任 · 信任与问责 · 可变性 · 激发信心 · 承担责任"],
      doo: ["Plan approval; collapsed think-and-act chain (latest 3 items, 2 layers); Sources tab; disclaimer pattern; stop / retry / error states.", "计划审批；可折叠的思考行动链（最近 3 条，2 层）；来源标签；免责声明模式；停止/重试/错误状态。"],
      test: ["Could the user defend this output to an auditor?", "用户能否向审计方为这份产出辩护？"],
      anti: ["Removing required disclosures for minimalism; showing system files instead of explanations.", "为极简删除必需的披露；用系统文件代替解释。"],
      m: ["Verification rate · trust drivers (Reliable, Integrity) · escalations", "核验率 · 信任驱动（可靠、诚信）· 升级次数"] },
    { id: "P3", n: ["One platform, role-shaped", "一个平台，按角色塑形"],
      d: ["Same platform and patterns, but entry points, depth and density follow the role.", "同一平台与模式，入口、深度与密度跟随角色。"],
      from: ["Understand human context · Delightfully personalised · Value difference", "理解人的情境 · 贴心个性化 · 尊重差异"],
      doo: ["Role-based L1 menu; history where chat work happens; full-width admin canvases; reuse known data (e.g. role from staff profile) instead of asking.", "按角色的一级菜单；历史出现在对话工作处；管理员画布全宽；复用已知数据（如员工档案中的角色）而非重复询问。"],
      test: ["Does this element serve the role that sees it, at that moment?", "这个元素是否服务于此刻看到它的角色？"],
      anti: ["One persona for 10,000 users; asking for data the system already has.", "一万名用户只有一个画像；询问系统已有的数据。"],
      m: ["Task completion by role · menu findability", "分角色任务完成率 · 菜单可寻性"] },
    { id: "P4", n: ["Connected journey, consistent patterns", "旅程连贯，模式一致"],
      d: ["Landing → work → output → return feels like one flow. The same thing looks and behaves the same everywhere. Users always know where they are.", "首页→工作→产出→回访是一条连贯流程。同一事物处处一致。用户始终知道自己在哪。"],
      from: ["Connect the whole journey · Familiarity · Connecting opportunities", "连接完整旅程 · 熟悉感 · 连接机遇"],
      doo: ["L1 / L2 navigation model; one way to show a locked agent; history findable by mode; one word, one meaning ('Task').", "一级/二级导航模型；锁定 agent 的统一展示；按模式可找到历史；一词一义（“Task”）。"],
      test: ["Does the user know where they are, how they got here and what comes next?", "用户是否知道自己在哪、怎么来的、下一步是什么？"],
      anti: ["Adding menu items without IA review; one word with two meanings.", "未经信息架构评审就加菜单项；一词多义。"],
      m: ["Navigation errors · back-tracking · support queries", "导航错误 · 回退次数 · 支持咨询"] },
    { id: "P5", n: ["Standards first, judgement always", "标准为先，判断为本"],
      d: ["Build with Bee-DS / HIVE and X-Cutting templates. Deviate only with evidence. Decide through options, criteria and testing. AI-generated concepts are input, not decisions.", "用 Bee-DS / HIVE 与 X-Cutting 模板构建。偏离须有证据。通过方案、标准与测试决策。AI 生成的概念是输入，不是决定。"],
      from: ["Create with judgement then make it real · High-taste · Shared standards · We get it done", "以判断创造并落地 · 高品位 · 共享标准 · 使命必达"],
      doo: ["Decision records; design review before build; standard components and tokens; deviations logged.", "决策记录；开发前设计评审；标准组件与 token；偏离留痕。"],
      test: ["Which standard does this follow? If none, what evidence justifies the deviation?", "这遵循哪条标准？若没有，什么证据支持偏离？"],
      anti: ["Shipping without design review; adopting a mock because it looks finished.", "未经设计评审就上线；因为样稿“看起来完成了”就采用。"],
      m: ["Design-system coverage · design debt · rework after release", "设计系统覆盖率 · 设计债 · 上线后返工"] }
  ],
  conflict: ["When principles pull apart: P2 accountability first, then P1 clarity of intent, then P3 role fit, then P4 consistency. P5 governs how we build, not whether.", "原则冲突时：P2 问责优先，其次 P1 意图清晰，再次 P3 角色匹配，然后 P4 一致性。P5 规定“如何做”，不决定“做不做”。"],
  mapping: [["01 Make it theirs", "P3"], ["02 Simple by default", "P1"], ["03 Function before form", "P2"], ["04 Lead the eye", "STD"], ["05 Show the working", "P2"], ["06 Earn its place", "MEA"], ["07 Built to last", "STD"]],

  method: [
    [["Frame", "定义问题"], ["User goal, role and moment. What decision are we making?", "用户目标、角色与场景。我们在决定什么？"]],
    [["Constrain", "列出约束"], ["Group standards, prior decisions, compliance, tech limits.", "集团标准、既往决策、合规、技术限制。"]],
    [["Diverge", "发散方案"], ["At least 3 options: as-is, proposals from any role, new ideas.", "至少 3 个方案：现状、任何角色的提议、新想法。"]],
    [["Score", "评分"], ["Criteria derived from the principles, weighted with PO.", "源自原则的评估标准，与 PO 共同定权重。"]],
    [["Evidence", "求证"], ["Real product cases, research, quick usability tests.", "真实产品案例、研究、快速可用性测试。"]],
    [["Decide & log", "决策并记录"], ["PO decides; design records the rationale; validate after release.", "PO 决策；设计记录理由；上线后验证。"]]
  ],

  topics: [
    { id: "t1", n: "1",
      title: ["Chat (classic) and Super agent (task): one landing?", "Chat（经典）与 Super agent（任务）：是否统一首页？"],
      q: ["How should users start a classic agent chat versus a Super agent task from one place?", "用户如何在同一处开始经典 agent 对话或 Super agent 任务？"],
      asis: ["Two working spaces. Chat / Task tabs in the session panel. 'Switch to advanced mode' link and a coach mark on the classic landing. Task landing has its own plan / outputs panel and a 'Select super domain agent' control.", "两个工作空间。会话面板中有 Chat / Task 标签。经典首页有“切换到高级模式”链接与引导提示。任务首页有独立的计划/产出面板和“选择超级领域 agent”控件。"],
      why: ["PO asked to separate the two because they behave differently: classic = talk to one specialist agent and hand over to others; Super agent = complex, long-chain requests with a plan, parallel work and multiple outputs. The agent is fixed once a session starts.", "PO 要求分开，因为两者行为不同：经典 = 与某一专长 agent 对话并可转交；Super agent = 复杂长链请求，带计划、并行执行与多种产出。会话开始后 agent 固定。"],
      prior: ["24 Jun: a merged history (Option 1) was proposed and not chosen; separate Chat / Task history was chosen.", "6 月 24 日：曾提出合并历史（方案 1），未被采用；采用了 Chat / Task 分开。"],
      ba: ["One landing; add 'General Purpose (CEAIA Super Agent)' to the agent dropdown next to SQL Explainer, Meeting Note-Taker, etc. Described as a UI-only change.", "统一首页；把“General Purpose (CEAIA Super Agent)”加入 agent 下拉列表，与 SQL Explainer、Meeting Note-Taker 等并列。被描述为纯 UI 改动。"],
      facts: [
        ["The BA mock still keeps 'Switch to classic mode' in the header, so two modes remain.", "BA 样稿顶部仍保留“Switch to classic mode”，说明两种模式依然存在。"],
        ["After Send, the layout changes (plan panel, Work hub). A dropdown item does not prepare the user for that.", "发送后布局会变化（计划面板、Work hub），下拉选项无法让用户预期这一点。"],
        ["Super agent needs its own domain agent choice — a second selection hidden inside the first.", "Super agent 还需选择领域 agent——一个选择嵌套在另一个里。"],
        ["Session model, history, panels and agent lock all change: not UI-only.", "会话模型、历史、面板、agent 锁定都会变化：并非纯 UI。"]
      ],
      criteria: [
        { id: "c1", n: ["Predictability before Send", "发送前可预期"], w: 3, p: "P1" },
        { id: "c2", n: ["Fit with what happens after Send", "与发送后流程匹配"], w: 3, p: "P4" },
        { id: "c3", n: ["Super agent discoverability", "Super agent 可发现性"], w: 2, p: "P1" },
        { id: "c4", n: ["Learning cost / clicks", "学习成本 / 点击数"], w: 2, p: "P1" },
        { id: "c5", n: ["Build effort & risk (5 = low)", "开发投入与风险（5=低）"], w: 1, p: "P5" },
        { id: "c6", n: ["Scales to future modes", "可扩展至未来模式"], w: 2, p: "P4" }
      ],
      options: [
        { id: "A", tag: "asis", n: ["As-is: separate spaces + switch link", "现状：分离空间 + 切换链接"], s: [4, 5, 2, 3, 5, 3],
          pro: [["Clear mental model; downstream already designed", "心智模型清晰；后续交互已设计"]], con: [["Super agent easy to miss; switching takes a detour", "Super agent 易被忽略；切换绕路"]], img: "ceaia_classic_landing" },
        { id: "B", tag: "ba", n: ["BA: Super agent inside the agent list", "BA：Super agent 放入 agent 列表"], s: [2, 2, 4, 4, 2, 2],
          pro: [["Feels like one landing; fewer clicks", "观感统一；点击更少"]], con: [["Same control means persona and mode", "同一控件既选人又选模式"], ["Layout jumps after Send", "发送后布局突变"], ["Each new mode becomes a fake agent", "每个新模式都会变成伪 agent"]], img: "ba_agent_dropdown" },
        { id: "C", tag: "rec", n: ["Shared landing + explicit Chat | Task switch", "共享首页 + 明确的 Chat | Task 开关"], s: [5, 4, 4, 4, 3, 4],
          pro: [["Meets the single-landing goal", "满足统一首页目标"], ["Users see the mode before Send", "发送前看清模式"]], con: [["Needs a landing refactor", "需重构首页"]], img: "ceaia_task_landing" },
        { id: "D", tag: "alt", n: ["Intent routing: system suggests 'Run as task'", "意图路由：系统建议“作为任务运行”"], s: [3, 4, 5, 5, 2, 5],
          pro: [["Lowest effort for users", "用户最省力"]], con: [["Needs reliable classification and an explanation", "需要可靠的分类与解释"]], img: "ceaia_task_running" }
      ],
      rec: ["Option C now; add D's suggestion chip in Phase 2 on top of C. Re-open the 24 Jun decision with the PO, because C changes how sessions start.", "现在采用方案 C；二期在 C 之上加入 D 的建议提示。由于 C 改变会话启动方式，需与 PO 重新讨论 6 月 24 日的决定。"],
      imgs: ["ceaia_classic_landing", "ceaia_task_landing", "ba_agent_dropdown"]
    },

    { id: "t2", n: "2",
      title: ["Agent selector position and composer actions", "Agent 选择器位置与输入区操作"],
      q: ["Where should the agent selector sit, and should + / send live inside the input?", "Agent 选择器应放在哪里？+ / 发送是否应放进输入框？"],
      asis: ["'Select agent' sits below the input on the left. '+' is outside the input on the left, send is outside on the right.", "“Select agent”位于输入框下方左侧。“+”在输入框外左侧，发送在外右侧。"],
      why: ["The selector chooses who answers the whole session, so it sat apart from the message field. The composer layout followed the earlier component version.", "选择器决定整段会话由谁回答，因此与消息框分开放置。输入区布局沿用早期组件版本。"],
      prior: ["Moving + and send inside the input was already listed in the Sep landing ideation (composer workstream).", "把 + 与发送移入输入框，已列在 9 月首页构想（输入区工作项）中。"],
      ba: ["Selector inside the input, on the right next to send; actions inside the input.", "选择器放进输入框内右侧、紧邻发送；操作移入输入框。"],
      facts: [
        ["9 products, 4 positions: header, above input, inside input, below input.", "9 个产品，4 种位置：顶部标题、输入框上方、输入框内、输入框下方。"],
        ["Session-wide controls tend to sit in the header (Gemini, Rovo, slothGPT, Meta AI).", "作用于整段会话的控件多在顶部（Gemini、Rovo、slothGPT、Meta AI）。"],
        ["When inside the input, the model chip sits in the left tool group, away from send (ChatGPT mobile).", "放在输入框内时，模型选择位于左侧工具组，远离发送（ChatGPT 移动端）。"],
        ["Add-context controls cluster left; submit controls cluster right (Rovo, slothGPT, ChatGPT).", "添加上下文的控件聚在左侧；提交控件聚在右侧（Rovo、slothGPT、ChatGPT）。"]
      ],
      criteria: [
        { id: "c1", n: ["Set context before typing (reading order)", "先设情境再输入（阅读顺序）"], w: 2, p: "P1" },
        { id: "c2", n: ["Distance from Send (mis-tap risk)", "与发送的距离（误触风险）"], w: 2, p: "P2" },
        { id: "c3", n: ["Current agent always visible", "当前 agent 始终可见"], w: 3, p: "P1" },
        { id: "c4", n: ["Shows the lock after session start", "会话开始后体现锁定"], w: 2, p: "P4" },
        { id: "c5", n: ["Room for long names / future controls", "可容纳长名称/未来控件"], w: 2, p: "P4" },
        { id: "c6", n: ["Fit with Bee-DS Chat input", "符合 Bee-DS Chat input"], w: 2, p: "P5" }
      ],
      options: [
        { id: "A", tag: "asis", n: ["As-is: below input, left", "现状：输入框下方左侧"], s: [3, 5, 3, 3, 5, 3], pro: [["Never collides with send", "不会与发送冲突"]], con: [["Reads as a footnote", "看起来像脚注"]], img: "ceaia_classic_landing" },
        { id: "B", tag: "ba", n: ["BA: inside input, right, next to send", "BA：输入框内右侧，紧邻发送"], s: [2, 2, 4, 2, 2, 2], pro: [["Compact", "紧凑"]], con: [["Last thing read, first thing hit", "最后被读到、最先被误触"], ["Long agent names truncate", "长名称被截断"]], img: "ba_landing" },
        { id: "C", tag: "alt", n: ["Inside input, left tool group", "输入框内左侧工具组"], s: [4, 4, 4, 3, 3, 4], pro: [["Context controls together", "情境类控件聚合"]], con: [["Composer gets busier", "输入区更拥挤"], ["Lock state unclear after Send", "发送后锁定状态不清"]], img: "case_chatgpt_mobile" },
        { id: "D", tag: "alt", n: ["Session header", "会话标题区"], s: [3, 5, 5, 5, 4, 3], pro: [["Shows who is answering all session", "整段会话都能看到谁在回答"]], con: [["Far from the composer on landing", "首页时离输入框较远"]], img: "case_rovo" },
        { id: "E", tag: "rec", n: ["C before Send, then D once locked", "发送前用 C，锁定后用 D"], s: [4, 4, 5, 5, 4, 4], pro: [["Right place at each moment", "每个时刻都在合适位置"], ["Makes the agent lock visible", "让 agent 锁定可见"]], con: [["Needs a clear hand-off animation", "需要清晰的过渡动效"]], img: "case_gemini_home" }
      ],
      rec: ["Option E: use C before the first message, then show the agent read-only in the session header (D) once it is locked. Move + and send inside the input, aligned with the Bee-DS Chat input component.", "方案 E：首条消息前用方案 C，会话锁定后在会话标题区只读显示 agent（方案 D）。把 + 与发送移入输入框，与 Bee-DS Chat input 组件对齐。"],
      imgs: ["case_chatgpt_mobile", "case_gemini_welcome", "case_rovo", "case_sloth", "case_meta", "case_copilot_win"]
    },

    { id: "t3", n: "3",
      title: ["AI disclaimer banner", "AI 免责声明横幅"],
      q: ["How prominent should the AI and data-use notice be on the landing?", "首页上的 AI 与数据使用声明应有多醒目？"],
      asis: ["Full information banner at the top of every new chat: AI may hallucinate; you validate outputs; only Public and Internal data; no PII.", "每次新对话顶部显示完整信息横幅：AI 可能产生幻觉；用户需核验；仅限公开与内部数据；禁止 PII。"],
      why: ["Data-classification and accountability rules must be seen before input. The text is a policy statement, not marketing copy.", "数据分级与责任规则必须在输入前被看到。这段文字是政策声明，不是营销文案。"],
      prior: ["—", "—"],
      ba: ["Shorten it and move it to the bottom of the page.", "缩短并移到页面底部。"],
      facts: [
        ["Gemini shows a full privacy card above the input on the welcome screen; the home screen in the same set does not.", "Gemini 欢迎页在输入框上方显示完整隐私卡片；同组的首页则没有。"],
        ["Rovo: 'Uses AI. Verify results.' under the input. Copilot: one short line under the suggestions.", "Rovo：输入框下“Uses AI. Verify results.”；Copilot：建议下方一行短句。"],
        ["Early ChatGPT put 'Limitations' as one of three columns on the empty state.", "早期 ChatGPT 在空状态把“Limitations”作为三栏之一。"],
        ["Changing policy wording needs Risk / Compliance sign-off.", "修改政策措辞需风险/合规审批。"]
      ],
      criteria: [
        { id: "c1", n: ["Compliance: wording & visibility", "合规：措辞与可见性"], w: 3, p: "P2" },
        { id: "c2", n: ["First-use comprehension", "首次理解"], w: 2, p: "P2" },
        { id: "c3", n: ["Ongoing noise (5 = calm)", "长期干扰（5=安静）"], w: 2, p: "P1" },
        { id: "c4", n: ["Shown at the point of risk", "在风险点出现"], w: 2, p: "P2" },
        { id: "c5", n: ["Consistency with AI signalling patterns", "与 AI 标识模式一致"], w: 2, p: "P5" }
      ],
      options: [
        { id: "A", tag: "asis", n: ["As-is: full banner every time", "现状：每次显示完整横幅"], s: [5, 5, 1, 2, 3], pro: [["Always compliant", "始终合规"]], con: [["Dominates the page; becomes invisible through habit", "占据页面；久而视而不见"]], img: "ceaia_classic_landing" },
        { id: "B", tag: "ba", n: ["BA: short footer only", "BA：仅底部短句"], s: [3, 2, 5, 2, 4], pro: [["Quiet", "安静"]], con: [["Small grey text may not meet the rule's intent", "小号灰字可能达不到规则本意"]], img: "ba_landing" },
        { id: "C", tag: "alt", n: ["Progressive: full on first use, short line after", "渐进：首次完整，之后短句"], s: [4, 5, 4, 3, 5], pro: [["Learn once, remind lightly", "学一次，轻提醒"]], con: [["Needs a 'seen' flag and policy-change reset", "需记录已读并在政策变更时重置"]], img: "case_gemini_welcome" },
        { id: "D", tag: "rec", n: ["Progressive + contextual PII reminder on upload", "渐进 + 上传时的 PII 情境提醒"], s: [5, 5, 4, 5, 4], pro: [["Warning appears when risk happens", "风险发生时提醒"]], con: [["Two places to maintain", "需维护两处"]], img: "case_rovo" }
      ],
      rec: ["Option D, subject to Compliance approval of the short wording. Keep the full text one click away ('Learn more').", "采用方案 D，短句措辞需合规批准。完整文本一键可达（“了解更多”）。"],
      imgs: ["case_gemini_welcome", "case_gemini_home", "case_rovo", "case_chatgpt_web"]
    },

    { id: "t4", n: "4",
      title: ["User message bubble", "用户消息气泡"],
      q: ["Can the user bubble be lighter and narrower?", "用户气泡能否更浅、更窄？"],
      asis: ["Dark solid fill, white text; stretches close to the full chat width.", "深色实底白字；几乎占满对话宽度。"],
      why: ["The Group X-Cutting 'Conversational and AI' template defines the customer text message as a dark bubble. Product teams do not redefine it; the template asks teams to bring new needs to X-Cutting and Conversational Banking design leads.", "集团 X-Cutting“Conversational and AI”模板规定客户消息为深色气泡。产品团队不自行改定义；模板要求新需求提交 X-Cutting 与对话银行设计负责人。"],
      prior: ["—", "—"],
      ba: ["Lighter fill, dark-mode version, narrower bubble.", "更浅的底色、深色模式版本、更窄的气泡。"],
      facts: [
        ["Meta AI uses a blue bubble, Copilot a warm one: each brand sets bubble colour in its own system.", "Meta AI 用蓝色气泡，Copilot 用暖色：每个品牌在自己的系统里定义气泡颜色。"],
        ["Width is a layout decision we can improve now.", "宽度属于布局决策，可以立即优化。"],
        ["Dark mode follows Bee-DS tokens, not a custom colour.", "深色模式遵循 Bee-DS token，而非自定义颜色。"]
      ],
      criteria: [], options: [],
      rec: ["Keep the colour (Group standard). Apply a max width (about 75% of the column) and confirm the dark-mode token with Bee-DS.", "保持颜色（集团标准）。设置最大宽度（约为对话栏 75%），并与 Bee-DS 确认深色模式 token。"],
      imgs: ["grp_xcut_bubble", "case_copilot_mobile", "case_meta"]
    },

    { id: "t5", n: "5",
      title: ["Main menu (L1) structure", "主菜单（一级）结构"],
      q: ["How should modules and sessions be organised in the sidebar?", "侧栏中模块与会话应如何组织？"],
      asis: ["Option 3 (hidden L1 menu + visible session bar), confirmed 14 Aug. In build, the menu became crowded: related items split (Dashboard / Insights), temporary items too prominent (Browser automation), repeated icons, Workflow without a future home, new items with no entry rules. A 'Task management' L1 item appeared without design review.", "方案 3（隐藏一级菜单 + 常显会话栏），8 月 14 日确认。开发后菜单变得拥挤：相关项分散（Dashboard/Insights）、临时项过于显眼（Browser automation）、图标重复、Workflow 无未来归属、新功能无入口规则。“Task management”一级入口未经设计评审出现。"],
      why: ["Option 3 balanced simplicity and growth for both small and large module counts.", "方案 3 在模块少与多时都能兼顾简洁与扩展。"],
      prior: ["Options 1 (top nav), 2 (sidebar + session bar) and 4 (unified tree) were compared and not chosen.", "方案 1（顶部导航）、2（侧栏 + 会话栏）、4（统一树）经对比未被采用。"],
      ba: ["'A single sidebar portioned into functionality and conversations' — this is Option 4.", "“一个分为功能与对话的单一侧栏”——即方案 4。"],
      facts: [
        ["Standard users mainly use Chat, Marketplace, Knowledge base.", "标准用户主要使用 Chat、Marketplace、Knowledge base。"],
        ["Expert / admin users work in Agent builder, Skill hub, notification admin, Insights.", "专家/管理员在 Agent builder、Skill hub、通知管理、Insights 中工作。"],
        ["A docked icon rail was already explored in Main menu improvements.", "主菜单优化中已探索常驻图标栏。"]
      ],
      criteria: [
        { id: "c1", n: ["Scales to 5+ modules", "可扩展至 5 个以上模块"], w: 3, p: "P4" },
        { id: "c2", n: ["Role fit", "角色匹配"], w: 3, p: "P3" },
        { id: "c3", n: ["Clicks to switch module", "切换模块的点击数"], w: 2, p: "P1" },
        { id: "c4", n: ["Focus on the work canvas", "聚焦工作画布"], w: 2, p: "P3" },
        { id: "c5", n: ["Governance: clear entry rules", "治理：清晰的入口规则"], w: 2, p: "P5" }
      ],
      options: [
        { id: "O1", tag: "alt", n: ["Top nav + session bar", "顶部导航 + 会话栏"], s: [1, 2, 4, 3, 3], pro: [["Familiar tabs", "熟悉的标签"]], con: [["Runs out of space", "空间不足"]], img: "ceaia_nav_options" },
        { id: "O3", tag: "asis", n: ["Option 3: hidden menu + session bar (chosen)", "方案 3：隐藏菜单 + 会话栏（已选）"], s: [4, 3, 2, 5, 4], pro: [["Clean, task-focused", "简洁、聚焦任务"]], con: [["Switching modules is less obvious", "切换模块不够直观"]], img: "ceaia_menu_chat_task" },
        { id: "O4", tag: "ba", n: ["Option 4 / BA: one sidebar, functions + conversations", "方案 4 / BA：单一侧栏，功能 + 对话"], s: [3, 2, 4, 3, 3], pro: [["Everything in one place", "一处看全"]], con: [["Admins carry a chat list they don't need", "管理员背着用不上的对话列表"], ["Long flat list", "长而扁平的列表"]], img: "ba_landing" },
        { id: "O5", tag: "rec", n: ["Option 3 + docked icon rail + role-based groups", "方案 3 + 常驻图标栏 + 按角色分组"], s: [5, 5, 4, 4, 4], pro: [["One-click module switch", "一键切换模块"], ["Menu by role", "菜单按角色"]], con: [["Icons need a full audit", "需全面审查图标"]], img: "ceaia_menu_improvements" }
      ],
      rec: ["Evolve Option 3: docked icon rail for L1, role-based groups (standard vs expert / admin), the near-term grouping in the menu proposal, and a rule that no L1 item ships without design review.", "演进方案 3：一级菜单常驻图标栏，按角色分组（标准 vs 专家/管理员），采用菜单提案中的近期分组，并规定一级入口未经设计评审不得上线。"],
      imgs: ["ceaia_nav_options", "ceaia_menu_improvements", "ceaia_menu_chat_task"]
    },

    { id: "t6", n: "6",
      title: ["Chat history in the sidebar", "侧栏中的对话历史"],
      q: ["Should chat history always be visible in the sidebar?", "对话历史是否应始终显示在侧栏？"],
      asis: ["History is the L2 session panel of the Chat / Task module, with Chat and Task tabs, pinned, recent and earlier groups.", "历史是 Chat / Task 模块的二级会话面板，含 Chat 与 Task 标签、置顶、最近、更早分组。"],
      why: ["History follows the L1 / L2 model. Standard users mostly chat; expert / admin users spend long journeys in management canvases where a chat list gets in the way.", "历史遵循一级/二级模型。标准用户主要对话；专家/管理员长时间在管理画布中工作，对话列表会造成干扰。"],
      prior: ["24 Jun: merged chat + task history (Option 1) vs separate (chosen).", "6 月 24 日：合并对话 + 任务历史（方案 1）vs 分开（已选）。"],
      ba: ["Conversations always shown and unified across both modes.", "对话始终显示，并在两种模式间统一。"],
      facts: [
        ["ChatGPT and slothGPT keep history always on — chat is their whole product.", "ChatGPT 与 slothGPT 常显历史——对话就是其全部产品。"],
        ["Gemini mobile puts history on its own 'Chats' screen.", "Gemini 移动端把历史放在独立的“Chats”页面。"],
        ["Rovo's chat lives in a side panel of a larger work tool.", "Rovo 的对话位于更大工作工具的侧面板中。"]
      ],
      criteria: [
        { id: "c1", n: ["Standard user finds past chats fast", "标准用户快速找到历史"], w: 3, p: "P3" },
        { id: "c2", n: ["Expert / admin canvas space", "专家/管理员画布空间"], w: 3, p: "P3" },
        { id: "c3", n: ["Consistent with L1 / L2 model", "符合一级/二级模型"], w: 2, p: "P4" },
        { id: "c4", n: ["Chat vs task clarity", "对话与任务区分清晰"], w: 2, p: "P1" },
        { id: "c5", n: ["Scales with long history", "可容纳大量历史"], w: 1, p: "P4" }
      ],
      options: [
        { id: "A", tag: "ba", n: ["BA: always-on in the global sidebar", "BA：常驻全局侧栏"], s: [5, 1, 2, 2, 2], pro: [["Always one glance away", "随时一眼可见"]], con: [["Crowds admin journeys", "挤占管理员旅程"]], img: "case_sloth" },
        { id: "B", tag: "asis", n: ["As-is: inside the Chat / Task module", "现状：位于 Chat / Task 模块内"], s: [4, 5, 5, 4, 3], pro: [["Right place, right role", "位置与角色匹配"]], con: [["Not reachable from other modules", "其他模块无法直达"]], img: "ceaia_menu_chat_task" },
        { id: "C", tag: "rec", n: ["B + remembered collapse + recent & search from the rail", "B + 记忆折叠 + 从图标栏访问最近与搜索"], s: [5, 5, 4, 4, 4], pro: [["Reachable everywhere, visible where needed", "处处可达，需要处可见"]], con: [["One more pattern to build", "多一个模式需开发"]], img: "ceaia_menu_improvements" },
        { id: "D", tag: "alt", n: ["Separate history page / search only", "仅独立历史页/搜索"], s: [2, 5, 4, 3, 5], pro: [["Calmest", "最安静"]], con: [["Slow for frequent chat users", "高频用户效率低"]], img: "case_gemini_chats" }
      ],
      rec: ["Option C. For chat vs task, test a merged list with type icon and filter against the current tabs with the PO, since unified history is the BA's real need.", "采用方案 C。关于对话与任务，与 PO 一起测试“合并列表 + 类型图标 + 筛选”与现有标签方案，因为统一历史是 BA 的真实诉求。"],
      imgs: ["ceaia_menu_chat_task", "ceaia_history_merged", "case_sloth", "case_gemini_chats"]
    },

    { id: "t7", n: "7",
      title: ["Landing content and hierarchy", "首页内容与层级"],
      q: ["What should the landing show, in what order?", "首页应展示什么、以什么顺序？"],
      asis: ["Assistant welcome message, disclaimer banner, guide text, 3 prompt-starter cards, composer at the bottom.", "助手欢迎消息、免责横幅、引导语、3 张起始卡片、底部输入框。"],
      why: ["Built when CEAIA was chat-only; the welcome appears as the first assistant message.", "在 CEAIA 仅有对话时设计；欢迎语作为第一条助手消息出现。"],
      prior: ["23 Sep ideation: greeting + centred composer + brand graphic-hexagon background with light motion + welcome mark.", "9 月 23 日构想：问候语 + 居中输入框 + 品牌六边形动态底纹 + 欢迎标识。"],
      ba: ["Dynamic greeting, centred composer, helper chips, announcement pill, footer note, Platform Overview and Roadmap pages.", "动态问候、居中输入框、辅助提示、公告胶囊、底部声明、平台概览与路线图页面。"],
      facts: [
        ["BA mocks use Inter and a serif greeting, not Univers Next for HSBC, and greys outside Bee-DS.", "BA 样稿使用 Inter 与衬线问候字体，而非 Univers Next for HSBC，灰色也不在 Bee-DS 内。"],
        ["Platform Overview lists integrations (Notion, Slack, Gmail) not in the product brief — needs verification.", "平台概览列出产品简报中没有的集成（Notion、Slack、Gmail）——需要核实。"],
        ["A public roadmap shown to 10,000+ users needs PO and comms ownership.", "向一万多名用户公开路线图，需 PO 与传播负责人认领。"]
      ],
      criteria: [
        { id: "c1", n: ["Prompt-first hierarchy", "以输入为先的层级"], w: 3, p: "P1" },
        { id: "c2", n: ["Compliance & trust signal", "合规与信任信号"], w: 3, p: "P2" },
        { id: "c3", n: ["Brand fidelity (Bee-DS, type, hexagon)", "品牌还原（Bee-DS、字体、六边形）"], w: 2, p: "P5" },
        { id: "c4", n: ["Role & intent guidance", "角色与意图引导"], w: 2, p: "P3" },
        { id: "c5", n: ["Content governance", "内容治理"], w: 2, p: "P2" }
      ],
      options: [
        { id: "A", tag: "asis", n: ["As-is landing", "现状首页"], s: [2, 5, 4, 3, 5], pro: [["Compliant, on-brand", "合规、符合品牌"]], con: [["Reads as a message thread, not a start point", "像消息流而非起点"]], img: "ceaia_classic_landing" },
        { id: "B", tag: "ba", n: ["BA mock", "BA 样稿"], s: [5, 2, 1, 4, 2], pro: [["Clear prompt-first layout", "清晰的输入优先布局"]], con: [["Off-brand type and colour", "字体与颜色不符品牌"], ["Unverified claims", "内容未核实"]], img: "ba_landing" },
        { id: "C", tag: "alt", n: ["Sep design ideation", "9 月设计构想"], s: [5, 3, 5, 3, 4], pro: [["Distinctive and on-brand", "独特且符合品牌"]], con: [["Mode switch and starters not yet resolved", "模式开关与起始提示未定"]], img: "ceaia_task_landing" },
        { id: "D", tag: "rec", n: ["Hybrid: C brand layer + B hierarchy + progressive notice + mode switch", "融合：C 品牌层 + B 层级 + 渐进声明 + 模式开关"], s: [5, 5, 5, 5, 4], pro: [["Keeps the best of each", "取各方之长"]], con: [["Needs Compliance and PO sign-off", "需合规与 PO 签字"]], img: "ceaia_task_landing" }
      ],
      rec: ["Option D. Put Platform Overview / What's new behind the masthead help icon and a dismissible pill; launch Roadmap only with an owner and an approval step.", "采用方案 D。平台概览/新功能放在顶部帮助图标与可关闭胶囊后；路线图需有负责人和审批流程后再上线。"],
      imgs: ["ba_landing", "ba_overview", "ceaia_classic_landing"]
    }
  ],

  poc: [
    { i: ["13-14 step forced tour", "13-14 步强制引导"], p: "P1", fx: ["3 contextual tips max; learn by doing", "最多 3 个情境提示；边用边学"] },
    { i: ["8-question preference form inside the chat stream", "对话流中的 8 题偏好问卷"], p: "P3", fx: ["Pre-fill from staff profile; ask only what's missing, later", "从员工档案预填；只问缺失项，延后问"] },
    { i: ["Model picker exposed (e.g. gpt-5.4)", "暴露模型选择（如 gpt-5.4）"], p: "P1", fx: ["Hide for standard users; admin setting", "对标准用户隐藏；作为管理员设置"] },
    { i: ["Slash commands taught as core (/new, /feedback)", "把斜杠命令当核心功能教（/new、/feedback）"], p: "P3", fx: ["Keep as power-user shortcuts; visible buttons first", "作为高级快捷方式；优先可见按钮"] },
    { i: ["'Tasks are packaged workflows' vs Task mode", "“Task 是打包的工作流”与 Task 模式冲突"], p: "P4", fx: ["One word, one meaning; rename one of them", "一词一义；更名其一"] },
    { i: ["agent.md shown to users, read-only", "向用户展示只读的 agent.md"], p: "P2", fx: ["Show a readable preferences page, editable in Settings", "提供可读的偏好页面，可在设置中编辑"] },
    { i: ["Right panel differs from designed Task plan / Outputs", "右侧面板与设计的任务计划/产出不一致"], p: "P4", fx: ["Align to one panel spec", "统一为一份面板规范"] },
    { i: ["Shipped without design review", "未经设计评审上线"], p: "P5", fx: ["Design review gate before build", "开发前设立设计评审关口"] }
  ],

  raci: {
    cols: [["BA", "BA"], ["Design", "设计"], ["PO", "PO"], ["Tech", "技术"], ["Group DS", "集团设计系统"]],
    rows: [
      [["Requirements, user stories, ACs", "需求、用户故事、验收标准"], ["R", "C", "A", "C", ""]],
      [["IA, interaction, UI", "信息架构、交互、界面"], ["C", "R/A", "C", "C", ""]],
      [["Product design principles", "产品设计原则"], ["C", "R/A", "C", "I", "C"]],
      [["Priority and scope", "优先级与范围"], ["C", "C", "A", "C", ""]],
      [["Feasibility and build", "可行性与开发"], ["I", "C", "C", "R/A", ""]],
      [["Deviation from Group standards", "偏离集团标准"], ["I", "R", "C", "I", "A"]]
    ],
    note: ["Concept mocks from any role are welcome as intent sketches. They enter the process at step 3 (Diverge), not as specifications.", "欢迎任何角色提供概念样稿，作为意图草图。它们在第 3 步（发散方案）进入流程，而不是作为规格。"]
  },

  asks: [
    ["Agree the decision method and the 5 CEAIA principles as the review basis.", "同意以决策方法与 5 条 CEAIA 原则作为评审依据。"],
    ["Re-open the 24 Jun mode decision; choose between Topic 1 options C and B.", "重新讨论 6 月 24 日的模式决定；在议题 1 方案 C 与 B 之间决策。"],
    ["Compliance review of the short disclaimer wording.", "合规审查免责声明短句。"],
    ["Design review gate before any new L1 item or POC release.", "任何新增一级入口或 POC 上线前设立设计评审关口。"],
    ["Usability test: mode switch and history (merged vs tabs), 5 users per role.", "可用性测试：模式开关与历史（合并 vs 标签），每个角色 5 人。"]
  ],

  cases: [
    { img: "case_chatgpt_web", n: "ChatGPT (web, earlier)", sel: ["No selector in this version", "此版本无选择器"], dis: ["'Limitations' column on empty state", "空状态的“Limitations”栏"], hist: ["Always-on sidebar", "常驻侧栏"], notes: ["1 history · 2 limitations · 3 tools inside input, left", "1 历史 · 2 局限说明 · 3 输入框内左侧工具"] },
    { img: "case_chatgpt_mobile", n: "ChatGPT (mobile)", sel: ["Inside input, left tool group", "输入框内左侧工具组"], dis: ["—", "—"], hist: ["Menu", "菜单"], notes: ["1 model chip · 2 tools · 3 voice / send, right", "1 模型选择 · 2 工具 · 3 语音/发送在右"] },
    { img: "case_gemini_welcome", n: "Gemini (mobile, welcome)", sel: ["Header, centre", "顶部居中"], dis: ["Full card above input", "输入框上方完整卡片"], hist: ["Separate screen", "独立页面"], notes: ["1 model in header · 2 privacy card", "1 顶部模型 · 2 隐私卡片"] },
    { img: "case_gemini_home", n: "Gemini (mobile, home)", sel: ["Header, centre", "顶部居中"], dis: ["Not shown", "不显示"], hist: ["Separate screen", "独立页面"], notes: ["1 model in header · 2 composer without notice", "1 顶部模型 · 2 无声明的输入区"] },
    { img: "case_rovo", n: "Atlassian Rovo (side panel)", sel: ["Header, left", "顶部左侧"], dis: ["One line under input", "输入框下一行"], hist: ["Behind menu", "收在菜单中"], notes: ["1 agent in header · 2 + and settings inside input · 3 'Uses AI. Verify results.'", "1 顶部 agent · 2 输入框内 + 与设置 · 3 “Uses AI. Verify results.”"] },
    { img: "case_sloth", n: "slothGPT (web concept)", sel: ["Header, left", "顶部左侧"], dis: ["One line under input", "输入框下一行"], hist: ["Always-on sidebar", "常驻侧栏"], notes: ["1 model in header · 2 history · 3 actions inside input · 4 notice", "1 顶部模型 · 2 历史 · 3 输入框内操作 · 4 声明"] },
    { img: "case_copilot_win", n: "Microsoft Copilot (Windows)", sel: ["Above input (conversation style)", "输入框上方（对话风格）"], dis: ["Short line under suggestions", "建议下方短句"], hist: ["—", "—"], notes: ["1 style switch · 2 notice · 3 new topic, outside input", "1 风格切换 · 2 声明 · 3 新话题在输入框外"] },
    { img: "case_copilot_mobile", n: "Microsoft Copilot (mobile)", sel: ["—", "—"], dis: ["—", "—"], hist: ["—", "—"], notes: ["1 brand-coloured user bubble · 2 action outside input", "1 品牌色用户气泡 · 2 输入框外操作"] },
    { img: "case_meta", n: "Meta AI (mobile)", sel: ["Header, under name", "顶部名称下"], dis: ["Line above input", "输入框上方一行"], hist: ["In Messenger list", "在 Messenger 列表中"], notes: ["1 model in header · 2 brand-coloured user bubble · 3 notice", "1 顶部模型 · 2 品牌色气泡 · 3 声明"] }
  ]
};
