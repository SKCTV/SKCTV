import base64,os,re,io
from PIL import Image
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(root)
data=open('data.js',encoding='utf-8').read()
def uri(path,maxw=1400,q=80):
    im=Image.open(path).convert('RGB')
    if im.width>maxw: im=im.resize((maxw,int(im.height*maxw/im.width)),Image.LANCZOS)
    b=io.BytesIO(); im.save(b,'JPEG',quality=q,optimize=True)
    return 'data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode()
def imgmap(folder,names):
    return 'window.IMG={'+','.join(f'"{n}":"{uri(os.path.join(folder,n+".jpg"))}"' for n in names)+'};'
inline_data='<script>\n'+data+'\n</script>'
for name in ['report','deck','prototype','reply-kit']:
    s=open(f'src/{name}.html',encoding='utf-8').read()
    s=s.replace('<script src="data.js"></script>',inline_data)
    if name in ('report','deck'):
        used=sorted(set(re.findall(r'["\'`]((?:case|ceaia|ba|grp|poc|rec)_[a-z0-9_]+)["\'`]',s+data)))
        used=[u for u in used if os.path.exists(f'assets/{u}.jpg')]
        s=s.replace('<script>\n'+data,'<script>'+imgmap('assets',used)+'</script>\n<script>\n'+data,1)
        s=s.replace('const img = n => `assets/${n}.jpg`;','const img = n => (window.IMG[n]||"");').replace('const img=n=>`assets/${n}.jpg`;','const img=n=>(window.IMG[n]||"");')
    if name=='reply-kit':
        used=sorted(f[:-4] for f in os.listdir('reply-images') if f.endswith('.jpg'))
        s=s.replace('<script>\nlet LANG','<script>'+imgmap('reply-images',used)+'</script>\n<script>\nlet LANG',1)
        s=s.replace('src="reply-images/${n}.jpg"','src="${window.IMG[n]}"').replace("'reply-images/'+f.dataset.img+'.jpg'","window.IMG[f.dataset.img]")
    open(f'{name}.html','w',encoding='utf-8').write(s)
    left=re.findall(r'src="data\.js"|`assets/|reply-images/\$|\'reply-images/\'',s)
    print(name, round(len(s)/1e6,2),'MB', 'external refs left:',left)
