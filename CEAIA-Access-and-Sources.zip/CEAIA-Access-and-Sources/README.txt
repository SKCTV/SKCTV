CEAIA – No access (AIWPB-9195) and Sources (AIWPB-2816)
Exported 28 Oct 2026

01-Report
  CEAIA-Access-and-Sources-Report.html   Standalone report, EN / 简体中文 switch, images embedded
  CEAIA-Access-and-Sources-Report-EN.pdf A4, English
  CEAIA-Access-and-Sources-Report-ZH.pdf A4, Simplified Chinese

02-Prototypes  (open in any browser, works offline)
  CEAIA-No-Access-Prototype.html          Options A/B/C, illustration switch, Prod/PrePROD, mobile, future request flow, S4/S5/S7
  CEAIA-Sources-Prototype.html            Normal + Super agent, inline [Icon link] citations, 7-source passage, panel, viewer, large view

03-Screens  (PNG @2x, product frame only)
  No-access/   14 states
  Sources/     Normal-agent_01–16, Super-agent_01–16, Narrow_01–03, Variant_* (inline and end-of-reply options)

04-Illustrations  (PNG @3x, transparent)
  A_Recommended_Shield-on-hexagon.png    North Star "Shield (Shadow)" + "&asset_illustration" hexagon ground
  B_Globe-alert-barrier.png              North Star WPBDR-1231
  C_Ineligible-list.png                  North Star "Ineligible_MaxPlan" (WPBDR-1211)
  Shield-only.png

Live versions (private until shared):
  No access prototype  https://claude.ai/artifact/BU4tQtkaMt2N9weYSDpscQ
  Sources prototype    https://claude.ai/artifact/UCsRLKpqU2H4RracXFcQ1a
  Report               https://claude.ai/artifact/EkAASRSwrJ35GrZ9e9Pggo

Notes
  - Prototype content is sample data. Font falls back to Helvetica (Univers Next for HSBC isn't available on the web).
  - Type icons (globe / document / book / lock) are drawn to match; swap for the group icon library.
