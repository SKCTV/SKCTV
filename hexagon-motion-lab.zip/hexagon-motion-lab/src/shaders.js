/* GLSL ES 3.00 sources.
   VERT  - full-screen triangle
   FRAG  - halftone renderer: field -> tone -> pointer -> mask -> screen
   PFRAG - one step of the per-cell sustain / release state (ping-ponged) */
(function(){
const VERT = `#version 300 es
in vec2 aPos; void main(){ gl_Position = vec4(aPos,0.0,1.0); }`;

const FRAG = `#version 300 es
precision highp float;
out vec4 outColor;

uniform vec2  uCenter;
uniform float uUnit;
uniform float uTime;

uniform sampler2D uField;
uniform float uUseField;     // 1 = play the measured field from the source clip
uniform float uFrame;        // float frame index into the sheet
uniform float uFrames;
uniform float uCols;
uniform vec2  uTileIn;       // inner tile size in px
uniform vec2  uSheet;        // sheet size in px
uniform float uXfade;        // seamless-loop crossfade, in frames
uniform vec2  uLoop;         // lo, hi frame of the loop range

uniform int   uShapeMode;    // 0 icon 1 cover 2 bleed 3 honeycomb 4 knockout 5 array
/* ---- array: every mark is its own instance of the single animation ---- */
uniform vec3  uArrLat;       // row step x (hs), row spacing (vs), row shift as a fraction of hs
uniform vec2  uPl[6];        // the six placements, centred, in mark half-heights
uniform float uArrOn;        // per-mark timing (measured field only)
uniform float uArrCycle;     // step through the six placements
uniform float uTau;          // global clock, in frames of warped time
uniform float uLtau;         // warped length of one cycle, pause included
uniform float uPerMark;      // 1 = each mark changes placement on its own; 0 = the whole array together
uniform float uTarr;         // whole-array period: one cycle plus the full stagger
uniform float uOverlap;      // how long two consecutive placements stay alive together
uniform float uFadeIn, uFadeOut;   // how long a placement takes to arrive and to leave
uniform float uNc;           // cycle length in source frames (loop window + sustain/fade tail)
uniform float uBody;         // loop window length in source frames
uniform float uLoopIn;
uniform highp sampler2D uTable;  // R32F: row 0 warped time -> source frame, row 1 visible ink
uniform float uTableM;
uniform sampler2D uAtlas;    // every frame of one cycle with sustain/fade already applied
uniform float uUseAtlas, uAtlasCols, uAtlasStride;
uniform vec2  uAtlasSize;
uniform int   uCPat, uCPatPrev;      // choreography, and the one it is blending from
uniform float uCMix, uCRev, uCRevPrev;
uniform float uSpread;       // delay range, in warped frames
uniform float uCJitter, uCAngle, uCCurve, uGlide, uGrow;
uniform vec2  uCOrigin, uStageHalf;
uniform float uPeakFrameA, uDwellWA, uPeakLiftA;
/* whole-array mode: the array itself is the screen and each mark is one dot */
uniform float uWhole, uCompSize, uCompInk, uCompFeather, uCompHour, uCompMask;
uniform vec2  uCompFit;      // mark units per composite unit, x and y
uniform float uCompGain;     // 1 / the clip's peak coverage, so sparse clips still read
uniform float uHourglass, uTileGap, uFeather;
uniform vec2  uMirror;
uniform float uKaleido, uLayers, uFreq, uFlowAngle, uSwirl;
uniform float uNoiseMix, uNoiseScale, uNoiseDrift;
uniform float uContrast, uBias, uBreathAmt, uBreathPer, uGamma;
uniform float uCell, uDotMax, uJitter, uScatter, uStagger, uGridAngle, uSoft, uInvert;
uniform int   uSpot;
uniform vec3  uInkA, uInkB, uGroundC, uBg;
uniform float uDuo, uOpacity;
uniform vec2  uPointer, uPVel;
uniform float uPEnergy, uPRadius, uPStrength, uPMirror;
uniform int   uPMode;
uniform float uReveal;
uniform sampler2D uPersist;  // per-cell attack / sustain / release state
uniform float uUsePersist;
uniform float uFlicker;      // per-cell size scatter, measured at 0.039
uniform float uFlickRate;
uniform float uCentreDip;    // the source runs slightly tighter dots at the centre

const float PI = 3.14159265359;
const float LA[5] = float[5](0.0, 1.5707963, 0.7853982, 2.3561945, 0.3926991);
const float LS[5] = float[5](0.31, -0.23, 0.19, -0.27, 0.13);
const float LF[5] = float[5](1.0, 1.37, 0.81, 1.73, 2.31);
const float LW[5] = float[5](1.0, 0.85, 0.70, 0.50, 0.35);

vec2 rot(vec2 p, float a){ float s=sin(a), c=cos(a); return mat2(c,-s,s,c)*p; }
float h11(float x){ return fract(sin(x*12.9898)*43758.5453); }
float n11(float x){ float i=floor(x), f=fract(x); f=f*f*(3.0-2.0*f); return mix(h11(i), h11(i+1.0), f); }
float h21(vec2 p){ p = fract(p*vec2(127.1,311.7)); p += dot(p,p+34.56); return fract(p.x*p.y*95.4307); }
float h31(vec3 p){ p = fract(p*0.3183099+vec3(0.71,0.113,0.419)); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float vnoise(vec3 x){
  vec3 i = floor(x), f = fract(x); f = f*f*(3.0-2.0*f);
  return mix(mix(mix(h31(i),h31(i+vec3(1,0,0)),f.x), mix(h31(i+vec3(0,1,0)),h31(i+vec3(1,1,0)),f.x), f.y),
             mix(mix(h31(i+vec3(0,0,1)),h31(i+vec3(1,0,1)),f.x), mix(h31(i+vec3(0,1,1)),h31(i+vec3(1,1,1)),f.x), f.y), f.z);
}
float fbm(vec3 p){ float a=0.5,s=0.0,n=0.0; for(int i=0;i<3;i++){ s+=a*vnoise(p); n+=a; p*=2.07; a*=0.5; } return s/n; }

float hexSDF(vec2 p){ vec2 q=abs(p); return max(q.y-1.0, q.x+q.y-2.0); }
float hourSDF(vec2 p){ vec2 q=abs(p); return max(q.x-1.0, q.y-q.x); }

vec2 tileFold(vec2 p){
  mat2 M = mat2(3.0,1.0,3.0,-1.0), Mi = mat2(1.0/6.0,1.0/6.0,0.5,-0.5);
  vec2 l = Mi*p, best = p; float bd = 1e9;
  for(int i=0;i<2;i++) for(int j=0;j<2;j++){
    vec2 c = p - M*(floor(l)+vec2(float(i),float(j)));
    float d = hexSDF(c); if(d < bd){ bd = d; best = c; }
  }
  return best;
}
float artSDF(vec2 p){
  if(uShapeMode == 2) return -1.0;
  vec2 mp = p;
  if(uShapeMode == 3) mp = tileFold(p)/max(uTileGap,0.05);
  float d = hexSDF(mp);
  if(uHourglass > 0.5) d = max(d, -hourSDF(mp));
  if(uShapeMode == 4) d = -d;
  return d;
}

/* ---- measured field from the source clip ---- */
vec2 domainOf(vec2 p){
  vec2 d = vec2((p.x+2.0)*0.25, 1.0-(p.y+1.0)*0.5);
  return 1.0 - abs(mod(d, 2.0) - 1.0);                  // mirrored repeat
}
float fieldAtUV(vec2 d, float fi){
  float f0 = floor(fi), w = fi - f0;
  float a = 0.0, b = 0.0;
  for(int s=0;s<2;s++){
    float f = mod(f0 + float(s), uFrames);
    float c = mod(f, uCols), r = floor(f/uCols);
    vec2 px = vec2(c,r)*(uTileIn+2.0) + 1.0 + d*uTileIn;
    float v = texture(uField, px/uSheet).r;
    if(s == 0) a = v; else b = v;
  }
  return mix(a, b, w);
}
float fieldAt(vec2 p, float fi){ return fieldAtUV(domainOf(p), fi); }
/* Seamless loop: play the body [lo+xf, hi], and over the last xf frames dissolve
   into the head [lo, lo+xf]. Output at tt=L equals output at tt=0 exactly. */
float fieldLoopedUV(vec2 d, float fi){
  float L = max(uLoop.y - uLoop.x - uXfade, 1.0);
  float tt = mod(fi, L);
  float v = fieldAtUV(d, uLoop.x + uXfade + tt);
  if(uXfade > 0.5){
    float sgap = tt - (L - uXfade);
    if(sgap > 0.0) v = mix(v, fieldAtUV(d, uLoop.x + sgap), smoothstep(0.0, 1.0, sgap/uXfade));
  }
  return v;
}
float fieldLooped(vec2 p, float fi){ return fieldLoopedUV(domainOf(p), fi); }

vec2 foldCoords(vec2 p){
  vec2 q = p;
  if(uMirror.x > 0.5) q.x = abs(q.x);
  if(uMirror.y > 0.5) q.y = abs(q.y);
  if(uKaleido > 0.5){ vec2 a = abs(q); q = (a.y > a.x) ? vec2(a.y,a.x) : a; }
  return q;
}
float waveField(vec2 q, float t){
  float f = 0.0, n = 0.0;
  for(int i=0;i<5;i++){
    if(float(i) >= uLayers) break;
    float a = LA[i] + uFlowAngle;
    f += LW[i]*sin(2.0*PI*(dot(q, vec2(cos(a),sin(a)))*uFreq*LF[i] + t*LS[i]));
    n += LW[i];
  }
  return f/max(n,1e-4);
}

float spot(vec2 lp){
  if(uSpot == 0) return 0.5 + 0.25*(cos(2.0*PI*lp.x)+cos(2.0*PI*lp.y));
  if(uSpot == 1) return clamp(length(lp)/0.7071, 0.0, 1.0);
  if(uSpot == 2) return max(abs(lp.x),abs(lp.y))*2.0;
  if(uSpot == 3) return clamp(abs(lp.x)+abs(lp.y), 0.0, 1.0);
  return abs(lp.y)*2.0;
}
/* map a requested ink AREA to the threshold each spot needs, so every screen
   shape carries the same weight and a measured coverage renders at its true size */
float spotGain(float v){
  v = clamp(v, 0.0, 1.0);
  if(uSpot == 1) return 0.7978845 * sqrt(v);   // circle : area = 1.5708 c^2
  if(uSpot == 2) return sqrt(v);               // square : area = c^2
  if(uSpot == 3) return 0.7071068 * sqrt(v);   // diamond: area = 2 c^2
  return v;                                    // euclidean / line screen
}

/* ---------------- array helpers ---------------- */
float tableAt(int row, float x){
  x = clamp(x, 0.0, uTableM - 1.0);
  float i0 = floor(x);
  float a = texelFetch(uTable, ivec2(int(i0), row), 0).r;
  float b = texelFetch(uTable, ivec2(int(min(i0 + 1.0, uTableM - 1.0)), row), 0).r;
  return mix(a, b, x - i0);
}
float atlasAt(vec2 d, float f){
  float s = f/uAtlasStride, f0 = floor(s);
  float a = 0.0, b = 0.0;
  for(int k=0;k<2;k++){
    float ff = f0 + float(k);
    float c = mod(ff, uAtlasCols), r = floor(ff/uAtlasCols);
    float v = texture(uAtlas, (vec2(c,r)*(uTileIn+2.0) + 1.0 + d*uTileIn)/uAtlasSize).r;
    if(k == 0) a = v; else b = v;
  }
  return mix(a, b, s - f0);
}
/* where in the choreography a mark sits, 0..1 (before the spread is applied) */
float pat01(int pat, float rev, vec2 id, vec2 B, float h){
  vec2 hs = uStageHalf;
  float d = 0.0;
  if(pat == 1){                                   // sweep along a direction
    vec2 dir = vec2(cos(uCAngle), sin(uCAngle));
    d = dot(B, dir)/max(abs(dir.x)*hs.x + abs(dir.y)*hs.y, 1e-3)*0.5 + 0.5;
  }else if(pat == 2){                             // ripple out from the origin
    d = length(B - uCOrigin)/max(length(abs(uCOrigin) + hs), 1e-3);
  }else if(pat == 3){                             // spiral round the origin
    vec2 q = B - uCOrigin;
    d = fract(atan(q.y, q.x)/(2.0*PI) + 0.5 + length(q)/max(length(hs), 1e-3));
  }else if(pat == 4){                             // scattered
    d = h;
  }else if(pat == 5){                             // checkerboard: two alternating groups
    d = mod(id.x + id.y, 2.0);
  }else if(pat == 6){                             // snake: reading order, turning each row
    float rows = max(1.0, floor(2.0*hs.y/uArrLat.y));
    float rp = clamp((hs.y - B.y)/(2.0*hs.y), 0.0, 1.0)*rows;
    float row = floor(rp);
    float cf = clamp(B.x/hs.x*0.5 + 0.5, 0.0, 1.0);
    if(mod(row, 2.0) > 0.5) cf = 1.0 - cf;
    d = (row + cf)/(rows + 1.0);
  }
  d = mix(clamp(d, 0.0, 1.0), h, uCJitter);
  if(rev > 0.5) d = 1.0 - d;
  return pow(max(d, 0.0), uCCurve);
}
float proceduralAt(vec2 q0, float t){
  vec2 q = foldCoords(q0);
  if(abs(uSwirl) > 0.001) q = rot(q, uSwirl*length(q)*0.5);
  float v = 0.5 + 0.5*waveField(q, t);
  if(uNoiseMix > 0.001) v = mix(v, fbm(vec3(q*uNoiseScale, t*uNoiseDrift)), uNoiseMix);
  return v + sin(2.0*PI*uTime/max(uBreathPer,0.2))*uBreathAmt;
}
float tone(float v, float lift){
  v = (v - 0.5)*uContrast + 0.5 + uBias + lift;
  return pow(clamp(v, 0.0, 1.0), uGamma);
}
/* the animation spread across the whole array: pos is in mark units, screen space */
float compSample(vec2 pos, float frame, float lift){
  vec2 C = pos/max(uCompFit, vec2(1e-3));
  float raw;
  if(uUseField > 0.5 && uArrOn > 0.5){
    if(frame >= uNc - 0.001)  raw = 0.0;
    else if(uUseAtlas > 0.5)  raw = atlasAt(domainOf(C), frame);
    else                      raw = (frame < uBody) ? fieldAtUV(domainOf(C), uLoopIn + frame) : 0.0;
  }else{
    raw = proceduralAt(C, uTime);
  }
  float v = tone(raw*uCompGain, lift);
  if(uCompMask > 0.5){                       // optional: cut the composite to one big hexagon
    float cd = hexSDF(C);
    if(uCompHour > 0.5) cd = max(cd, -hourSDF(C));
    v *= 1.0 - smoothstep(-uCompFeather, uCompFeather, cd);
  }
  return clamp(v, 0.0, 1.0);
}
float markDelay(vec2 id, vec2 B){
  float h = h21(id*0.713 + vec2(3.1, 9.7));
  return mix(pat01(uCPatPrev, uCRevPrev, id, B, h), pat01(uCPat, uCRev, id, B, h), uCMix)*uSpread;
}
/* Nearest mark to pg, with each candidate at its own placement and glide.
   Returns the mark's position; r = its time inside its own cycle. */
vec2 findMark(vec2 pg, out vec2 mid, out float mr, out float mw){
  float hs = uArrLat.x, vs = uArrLat.y, sh = uArrLat.z;
  float best = 1e9;
  vec2 bestPos = vec2(0.0);
  mid = vec2(0.0); mr = 0.0; mw = 1.0;
  float reachX = 5.2 + 1.8*uGlide, reachY = 3.2 + 1.8*uGlide;
  float rowc = floor(pg.y/vs + 0.5);
  for(int dr=-4; dr<=4; dr++){
    float row = rowc + float(dr);
    if(abs(row*vs - pg.y) > reachY) continue;
    float colc = floor(pg.x/hs - row*sh + 0.5);
    for(int dc=-2; dc<=2; dc++){
      float col = colc + float(dc);
      vec2 B = vec2((col + row*sh)*hs, row*vs);
      if(abs(B.x - pg.x) > reachX) continue;
      vec2 id = vec2(row, col);
      if(uArrOn < 0.5){
        vec2 pos0 = B + uPl[0];
        float d0 = hexSDF(pg - pos0);
        if(d0 < best){ best = d0; bestPos = pos0; mid = id; mr = 0.0; mw = 1.0; }
        continue;
      }
      /* consecutive placements overlap in time, so the one leaving and the one arriving
         are both alive for a moment, each carrying its own weight */
      float del = markDelay(id, B);
      float tauBase = (uPerMark > 0.5) ? (uTau - del) : uTau;
      float stride = max(uTarr - uOverlap, 1.0);
      float n0 = floor(tauBase/stride);
      for(int inst=0; inst<2; inst++){
        float nn = n0 - float(inst);
        float age = tauBase - nn*stride;                 // how far into its life this placement is
        if(age >= uTarr) continue;
        float w = smoothstep(0.0, 1.0, clamp(age/max(uFadeIn, 1e-3), 0.0, 1.0))
                * smoothstep(0.0, 1.0, clamp((uTarr - age)/max(uFadeOut, 1e-3), 0.0, 1.0));
        if(w < 0.004) continue;
        float r = (uPerMark > 0.5) ? age : (age - del);
        if(r < 0.0 || r > uLtau) continue;               // this mark is outside its own slot
        float k = (uArrCycle > 0.5) ? mod(nn, 6.0) : 0.0;
        vec2 cur = uPl[int(k)];
        vec2 pos = B + cur;
        if(uArrCycle > 0.5 && uGlide > 0.001){
          vec2 prv = uPl[int(mod(k + 5.0, 6.0))], nxt = uPl[int(mod(k + 1.0, 6.0))];
          pos += uGlide*mix(0.5*(prv - cur), 0.5*(nxt - cur), r/uLtau);
        }
        float dd = hexSDF(pg - pos);
        if(dd < best){ best = dd; bestPos = pos; mid = id; mr = r; mw = w; }
      }
    }
  }
  return bestPos;
}

void main(){
  vec2 pg = (gl_FragCoord.xy - uCenter)/uUnit;   // screen position, in mark units
  vec2 p = pg;
  vec2 markId = vec2(0.0);
  vec2 origin = vec2(0.0);
  float markScale = 1.0, markFrame = 0.0;
  float compV = 1.0, compLift = 0.0, markW = 1.0;
  if(uShapeMode == 5){
    float mr;
    origin = findMark(pg, markId, mr, markW);
    if(uArrOn > 0.5) markFrame = tableAt(0, mr/uLtau*(uTableM - 1.0));   // warped time -> source frame

    if(uWhole > 0.5){
      /* the animation runs across the whole array: each mark is a window onto it,
         and its cells read the field at their own place on screen */
      if(uArrOn > 0.5 && markFrame < uBody){
        float dz = (uLoopIn + markFrame - uPeakFrameA)/max(uDwellWA, 1.0);
        compLift = uPeakLiftA*exp(-dz*dz);
      }
      if(uCompSize > 0.001){
        compV = compSample(origin, markFrame, compLift);
        markScale = mix(1.0, sqrt(compV), uCompSize);
      }
    }else if(uArrOn > 0.5){
      float vis = tableAt(1, markFrame/max(uNc, 1.0)*(uTableM - 1.0));
      markScale = mix(1.0 - uGrow, 1.0, sqrt(clamp(vis, 0.0, 1.0)));
    }
    if(markScale < 0.002){ outColor = vec4(uBg, 1.0); return; }
    p = (pg - origin)/markScale;
  }

  vec2 gp = rot(p, uGridAngle)/uCell;
  float rowShift = 0.0;
  if(uStagger > 0.5){ gp.y /= 0.8660254; rowShift = mod(floor(gp.y),2.0)*0.5; gp.x += rowShift; }
  vec2 id = floor(gp)+0.5, lp = gp-id, cellPos = id;
  if(uStagger > 0.5){ cellPos.x -= rowShift; cellPos.y *= 0.8660254; }
  vec2 cp = rot(cellPos*uCell, -uGridAngle);

  float rnd = h21(id*1.37 + 7.3 + markId*31.7);
  vec2 cpg = origin + cp*markScale;              // cell centre on screen, for the pointer

  float infl;
  {
    vec2 dv = cpg - uPointer;
    if(uPMirror > 0.5) dv = abs(cpg) - abs(uPointer);
    float r = max(uPRadius,1e-3);
    infl = exp(-dot(dv,dv)/(r*r))*uPEnergy;
  }

  vec2 fq = cp;
  if(uPMode == 2 || uPMode == 4) fq += uPVel*infl*uPStrength*1.6;

  float v;
  float markLift = 0.0;
  bool whole = (uShapeMode == 5 && uWhole > 0.5);
  if(whole){
    vec2 sp2 = cpg;
    if(uPMode == 2 || uPMode == 4) sp2 += uPVel*infl*uPStrength*1.6;
    v = (uCompInk > 0.001) ? mix(1.0, compSample(sp2, markFrame, compLift), uCompInk) : 1.0;
  }else if(uShapeMode == 5 && uArrOn > 0.5){
    if(markFrame >= uNc - 0.001)  v = 0.0;
    else if(uUseAtlas > 0.5)      v = atlasAt(domainOf(fq), markFrame);
    else                          v = (markFrame < uBody) ? fieldAtUV(domainOf(fq), uLoopIn + markFrame) : 0.0;
    if(markFrame < uBody){
      float dz = (uLoopIn + markFrame - uPeakFrameA)/max(uDwellWA, 1.0);
      markLift = uPeakLiftA*exp(-dz*dz);
    }
  }else if(uUseField > 0.5){
    if(uUsePersist > 0.5){
      v = texture(uPersist, domainOf(fq)).r;
    }else{
      v = fieldLooped(fq, uFrame + (rnd-0.5)*uScatter*30.0);
    }
  }else{
    v = proceduralAt(fq, uTime + (rnd-0.5)*uScatter);
  }

  float dotBoost = 0.0;
  if(!whole){
    if(uCentreDip > 0.001) v *= 1.0 - uCentreDip*exp(-dot(cp,cp)/0.2025);
    if(uFlicker > 0.0001) v += (n11(rnd*613.0 + uTime*uFlickRate) - 0.5)*5.0*uFlicker;
    v = tone(v, markLift);
    v += (rnd-0.5)*uJitter;
  }
  {
    if(uPMode == 0)      v += uPStrength*infl;
    else if(uPMode == 1) v += uPStrength*infl*sin(2.0*PI*(length(cpg-uPointer)*1.6 - uTime*0.9));
    else if(uPMode == 3) v -= uPStrength*infl;
    else if(uPMode == 4){ v += uPStrength*infl*0.5; dotBoost = infl*0.35*clamp(uPStrength,0.0,1.5); }
  }

  float d = artSDF(p);
  if(uShapeMode != 2) v *= smoothstep(0.5*uCell, -(0.5+uFeather)*uCell, d);

  if(uReveal < 0.999){
    float e = (uShapeMode == 2) ? (1.0-clamp(length(p)/2.2,0.0,1.0)) : -d;
    float thr = uReveal*1.5 - 0.05;
    v *= 1.0 - smoothstep(thr, thr+0.24, e);
  }
  v = clamp(v, 0.0, 1.0)*markW;     // the placement's own fade in and out

  float lvl = v;
  if(uInvert > 0.5) lvl = 1.0 - lvl;
  float raw = lvl*uDotMax + dotBoost;
  float c = (raw <= 1.0) ? spotGain(max(raw,0.0)) : raw;

  vec2 sp = lp;
  if(uStagger > 0.5) sp.y *= 0.8660254;
  float s = spot(sp);
  float w = fwidth(s)*0.6 + uSoft + 1e-4;
  float ca = c*(1.0+2.0*w) - w;
  float cov = 1.0 - smoothstep(ca-w, ca+w, s);

  vec3 col = mix(uGroundC, mix(uInkA, uInkB, uDuo*v), cov);
  float shell = (uShapeMode == 2) ? 1.0 : smoothstep((1.5+uFeather)*uCell, -(1.5+uFeather)*uCell, d);
  col = mix(uBg, col, shell*uOpacity);
  outColor = vec4(col, 1.0);
}`;

/* One step of the dot life cycle, run on a small buffer the size of the clip's
   own cell grid. R = how bright the cell is now, G = sustain frames left.
   A cell brightens instantly, holds, then releases — all in source frames, so
   the envelope stays locked to the animation whatever the speed. */
const PFRAG = `#version 300 es
precision highp float;
out vec4 outState;
uniform sampler2D uField;
uniform sampler2D uPrev;
uniform vec2  uPSize;
uniform float uFrame, uFrames, uCols, uXfade;
uniform vec2  uLoop, uTileIn, uSheet;
uniform float uStep;      // source frames advanced since the last pass
uniform float uHold;      // sustain, source frames
uniform float uRelease;   // fade-out, source frames
uniform float uInit;

float fieldAtUV(vec2 d, float fi){
  float f0 = floor(fi), w = fi - f0;
  float a = 0.0, b = 0.0;
  for(int s=0;s<2;s++){
    float f = mod(f0 + float(s), uFrames);
    float c = mod(f, uCols), r = floor(f/uCols);
    vec2 px = vec2(c,r)*(uTileIn+2.0) + 1.0 + d*uTileIn;
    float v = texture(uField, px/uSheet).r;
    if(s == 0) a = v; else b = v;
  }
  return mix(a, b, w);
}
float fieldLoopedUV(vec2 d, float fi){
  float L = max(uLoop.y - uLoop.x - uXfade, 1.0);
  float tt = mod(fi, L);
  float v = fieldAtUV(d, uLoop.x + uXfade + tt);
  if(uXfade > 0.5){
    float sgap = tt - (L - uXfade);
    if(sgap > 0.0) v = mix(v, fieldAtUV(d, uLoop.x + sgap), smoothstep(0.0, 1.0, sgap/uXfade));
  }
  return v;
}
void main(){
  vec2 d = gl_FragCoord.xy / uPSize;
  float src = fieldLoopedUV(d, uFrame);
  if(uInit > 0.5){ outState = vec4(src, 0.0, 0.0, 1.0); return; }
  vec4 p = texture(uPrev, d);
  float lvl = p.r, hold = p.g * 512.0;
  if(src >= lvl){
    lvl = src; hold = uHold;                       // the front arrives
  }else{
    float left = uStep;
    float used = min(hold, left);
    hold -= used; left -= used;                    // sustain
    if(left > 0.0) lvl -= (uRelease > 0.01) ? left/uRelease : 1.0;   // release
    lvl = max(lvl, src);
  }
  outState = vec4(clamp(lvl,0.0,1.0), clamp(hold,0.0,512.0)/512.0, 0.0, 1.0);
}`;
/* copies the persistence state into one padded tile of the array atlas */
const CFRAG = `#version 300 es
precision highp float;
out vec4 o;
uniform sampler2D uSrc;
uniform vec2 uOrigin, uInner;
void main(){
  vec2 lp = gl_FragCoord.xy - uOrigin - 1.0;
  vec2 uv = clamp((lp + 0.5)/uInner, 0.5/uInner, 1.0 - 0.5/uInner);
  o = vec4(texture(uSrc, uv).r, 0.0, 0.0, 1.0);
}`;
window.HML_SHADERS = {VERT, FRAG, PFRAG, CFRAG};
})();
