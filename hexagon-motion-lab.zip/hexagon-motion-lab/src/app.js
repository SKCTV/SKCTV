(function(){
"use strict";
/* Hexagon Motion Lab — engine and UI. Loads after clips.js, i18n.js and shaders.js. */

/* ============================================================
   Language
   ============================================================ */
const STR = window.HML_STR;
let lang = "zh";
try{ const s = localStorage.getItem("hml_lang"); if(s === "en" || s === "zh") lang = s; }catch(e){}
const T = () => STR[lang];

/* ============================================================
   Shader
   ============================================================ */
const {VERT, FRAG, PFRAG, CFRAG} = window.HML_SHADERS;

/* ============================================================
   Parameters
   ============================================================ */
const P = {
  useField:1, seamless:1, speed:1.00, hold:0.45,
  peakFrame:108, dwell:0.60, dwellWidth:14, peakLift:0.00, sustain:0, fade:0,
  loopIn:20, loopOut:265, xfade:40,
  density:96, dotMax:1.08, spot:0, feather:0.40,
  shapeMode:0, size:1.00, hourglass:1, tileGap:0.86, opacity:1,
  arrayScale:1.00, arrayGapX:1, arrayGapY:1, arrayShift:0.5, arraySnap:1,
  arrayCycle:1, arrayPause:0.20,
  arrWhole:0, compGain:1.00, compScale:1.00, compFit:1, compSize:0.00, compInk:1.00, compMask:0, compFeather:0.06, compHour:1,
  tailScale:1.00, plOverlap:45, plFadeIn:30, plFadeOut:30,
  placeMode:0, choreo:0, spread:0.60, cAngle:0, cJitter:0, cCurve:1, cReverse:0, cClick:1, glide:0, grow:0,
  bg:"#000000", ground:"#000000", inkA:"#db0011", inkB:"#ff4a3d", duo:0,
  hover:1, pMode:4, pRadius:0.75, pStrength:0.85, pInertia:0.14, pMirror:0,
  contrast:1.00, bias:0.00, gamma:1.00, jitter:0.00, scatter:0.00,
  flicker:0.000, flickRate:3.60, centreDip:0.00,
  gridAngle:0, soft:0.00, stagger:0, invert:0,
  freq:0.55, layers:4, flowAngle:0, swirl:0, mirrorX:1, mirrorY:1, kaleido:0,
  noiseMix:0.34, noiseScale:0.95, noiseDrift:0.22, breathAmt:0.24, breathPer:4.30
};

const isOrig = () => !!P.useField;
const SCHEMA = [
 {id:"gBasics", open:true, note:()=> isOrig() ? (STR[lang]["noteOrig"+clipId] ? "noteOrig"+clipId : "noteOrigAny") : "noteProc", items:[
   {k:"speed",   t:"range", min:0, max:12, step:.05, fmt:v=>v.toFixed(2)+"×", when:()=>!compareOn, why:"offCmp"},
   {k:"timeline", t:"timeline", when:()=>isOrig(), why:"offOrig"},
   {k:"hold",     t:"range", min:0, max:1, step:.01, fmt:v=>v===0?"off":"×"+(1+4*v).toFixed(1), hint:"hHold", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"seamless", t:"toggle", when:()=>isOrig()&&!compareOn&&P.shapeMode!==5, why:()=>compareOn?"offCmp":(P.shapeMode===5?"offArrayLoop":"offOrig")},
   {k:"loopIn",   t:"range", min:0, max:300, step:1, fmt:v=>String(v), when:()=>isOrig()&&!!P.seamless&&!compareOn, why:()=>compareOn?"offCmp":(isOrig()?"offSeam":"offOrig")},
   {k:"loopOut",  t:"range", min:1, max:301, step:1, fmt:v=>String(v), when:()=>isOrig()&&!!P.seamless&&!compareOn, why:()=>compareOn?"offCmp":(isOrig()?"offSeam":"offOrig")},
   {k:"xfade",    t:"range", min:0, max:90, step:1, fmt:v=>v+"f / "+(v/30).toFixed(2)+"s", hint:"hXfade", when:()=>isOrig()&&!!P.seamless&&!compareOn&&P.shapeMode!==5, why:()=>compareOn?"offCmp":(P.shapeMode===5?"offArrayLoop":(isOrig()?"offSeam":"offOrig"))},
   {k:"density", t:"range", min:12, max:260, step:1, fmt:v=>v+"", hint:"hDensity"},
   {k:"dotMax",  t:"range", min:.2, max:1.4, step:.01, fmt:v=>v.toFixed(2)},
   {k:"spot",    t:"seg", opts:"spotOpts", hint:"hSpot"},
   {k:"feather", t:"range", min:0, max:6, step:.05, fmt:v=>v.toFixed(2), hint:"hFeather", when:()=>P.shapeMode!==2, why:"offBleed"}
 ]},
 {id:"gPeak", open:true, note:()=>"notePeak", items:[
   {k:"sustain",    t:"range", min:0, max:220, step:1, fmt:v=>v?v+"f / "+(v/30).toFixed(2)+"s":"off", hint:"hSustain", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"fade",       t:"range", min:0, max:220, step:1, fmt:v=>v?v+"f / "+(v/30).toFixed(2)+"s":"instant", hint:"hFade", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"tailScale",  t:"range", min:0, max:1.5, step:.05, fmt:v=>Math.round(v*100)+"%", hint:"hTail", when:()=>P.shapeMode===5&&isOrig()&&(P.sustain>0||P.fade>0), why:()=>P.shapeMode!==5?"offArray":(isOrig()?"offNoTail":"offOrig")},
   {k:"peakFrame",  t:"range", min:0, max:300, step:1, fmt:v=>String(v), hint:"hPeakFrame", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"dwell",      t:"range", min:0, max:4, step:.05, fmt:v=>v?v.toFixed(2)+"s":"off", hint:"hDwell", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"dwellWidth", t:"range", min:3, max:60, step:1, fmt:v=>v+"f", when:()=>isOrig()&&!compareOn&&P.dwell>0, why:()=>compareOn?"offCmp":(isOrig()?"offDwell":"offOrig")},
   {k:"peakLift",   t:"range", min:0, max:.6, step:.01, fmt:v=>v?"+"+v.toFixed(2):"off", hint:"hPeakLift", when:()=>isOrig(), why:"offOrig"}
 ]},
 {id:"gFrame", open:true, items:[
   {k:"mode",    t:"seg", opts:"modeOpts", key:"shapeMode", hint:"hMode"},
   {k:"size",    t:"range", min:.2, max:3, step:.01, fmt:v=>Math.round(v*100)+"%", when:()=>P.shapeMode!==5, why:"offSizeArr"},
   {k:"hourglass", t:"toggle", when:()=>P.shapeMode!==2, why:"offBleed"},
   {k:"tileGap", t:"range", min:.4, max:1, step:.01, fmt:v=>v.toFixed(2), when:()=>P.shapeMode===3, why:"offHoney"},
   {k:"opacity", t:"range", min:0, max:1, step:.01, fmt:v=>Math.round(v*100)+"%", when:()=>P.shapeMode!==2, why:"offBleed"}
 ]},
 {id:"gArrLayout", open:true, note:()=>"noteArrLayout", items:[
   {k:"arrayScale", t:"range", min:.2, max:6, step:.01, fmt:v=>markPx(v)+"px", hint:"hArrayScale", when:()=>P.shapeMode===5, why:"offArray"},
   {k:"arrayGapX",  t:"range", min:0, max:4, step:.5, fmt:v=>v.toFixed(2), hint:"hGapX", when:()=>P.shapeMode===5, why:"offArray"},
   {k:"arrayGapY",  t:"range", min:0, max:4, step:.5, fmt:v=>v.toFixed(2), hint:"hGapY", when:()=>P.shapeMode===5, why:"offArray"},
   {k:"arrayShift", t:"range", min:0, max:1, step:.05, fmt:v=>Math.round(v*100)+"%", hint:"hShift", when:()=>P.shapeMode===5, why:"offArray"},
   {k:"arraySnap",  t:"toggle", hint:"hSnap", when:()=>P.shapeMode===5, why:"offArray"}
 ]},
 {id:"gArrMotion", open:true, note:()=>"noteArrMotion", items:[
   {k:"arrWhole",   t:"seg", opts:"scopeOpts", hint:"hScope", when:()=>P.shapeMode===5, why:"offArray"},
   {k:"compFit",    t:"seg", opts:"fitOpts", hint:"hCompFit", when:()=>P.shapeMode===5&&!!P.arrWhole, why:()=>P.shapeMode===5?"offPerMark":"offArray"},
   {k:"compScale",  t:"range", min:.2, max:4, step:.01, fmt:v=>Math.round(v*100)+"%", hint:"hCompScale", when:()=>P.shapeMode===5&&!!P.arrWhole, why:()=>P.shapeMode===5?"offPerMark":"offArray"},
   {k:"compSize",   t:"range", min:0, max:1, step:.01, fmt:v=>Math.round(v*100)+"%", hint:"hCompSize", when:()=>P.shapeMode===5&&!!P.arrWhole, why:()=>P.shapeMode===5?"offPerMark":"offArray"},
   {k:"compGain",   t:"range", min:.25, max:3, step:.01, fmt:v=>v.toFixed(2)+"×", hint:"hCompGain", when:()=>P.shapeMode===5&&!!P.arrWhole, why:()=>P.shapeMode===5?"offPerMark":"offArray"},
   {k:"compInk",    t:"range", min:0, max:1, step:.01, fmt:v=>Math.round(v*100)+"%", hint:"hCompInk", when:()=>P.shapeMode===5&&!!P.arrWhole, why:()=>P.shapeMode===5?"offPerMark":"offArray"},
   {k:"compFeather",t:"range", min:0, max:.6, step:.005, fmt:v=>v.toFixed(3), when:()=>P.shapeMode===5&&!!P.arrWhole&&!!P.compMask, why:()=>P.shapeMode===5?"offPerMark":"offArray"},
   {k:"compMask",   t:"toggle", hint:"hCompMask", when:()=>P.shapeMode===5&&!!P.arrWhole, why:()=>P.shapeMode===5?"offPerMark":"offArray"},
   {k:"compHour",   t:"toggle", when:()=>P.shapeMode===5&&!!P.arrWhole&&!!P.compMask, why:()=>P.shapeMode!==5?"offArray":(P.arrWhole?"offCompMask":"offPerMark")},
   {k:"cPresets",  t:"chips", opts:"cPresetOpts", when:()=>P.shapeMode===5&&!P.arrWhole&&isOrig(), why:()=>P.arrWhole?"offWhole":P.shapeMode===5?"offOrig":"offArray"},
   {k:"choreo",    t:"seg", opts:"choreoOpts", hint:"hChoreo", when:()=>P.shapeMode===5&&!P.arrWhole&&isOrig(), why:()=>P.arrWhole?"offWhole":P.shapeMode===5?"offOrig":"offArray"},
   {k:"spread",    t:"range", min:0, max:2, step:.01, fmt:v=>v.toFixed(2)+"×", hint:"hSpread", when:()=>P.shapeMode===5&&!P.arrWhole&&isOrig()&&(P.choreo>0||P.cJitter>0), why:()=>P.arrWhole?"offWhole":P.shapeMode!==5?"offArray":(isOrig()?"offUnison":"offOrig")},
   {k:"cAngle",    t:"range", min:-3.1416, max:3.1416, step:.01, fmt:v=>Math.round(v*57.2958)+"°", when:()=>P.shapeMode===5&&!P.arrWhole&&isOrig()&&P.choreo===1, why:()=>P.arrWhole?"offWhole":P.shapeMode!==5?"offArray":"offSweep"},
   {k:"cClick",    t:"toggle", hint:"hClick", when:()=>P.shapeMode===5&&!P.arrWhole&&isOrig()&&(P.choreo===2||P.choreo===3), why:()=>P.arrWhole?"offWhole":P.shapeMode!==5?"offArray":"offCentre"},
   {k:"cJitter",   t:"range", min:0, max:1, step:.01, fmt:v=>Math.round(v*100)+"%", hint:"hCJitter", when:()=>P.shapeMode===5&&!P.arrWhole&&isOrig(), why:()=>P.arrWhole?"offWhole":P.shapeMode===5?"offOrig":"offArray"},
   {k:"cCurve",    t:"range", min:.3, max:3, step:.01, fmt:v=>v.toFixed(2), hint:"hCurve", when:()=>P.shapeMode===5&&!P.arrWhole&&isOrig()&&(P.choreo>0||P.cJitter>0), why:()=>P.arrWhole?"offWhole":P.shapeMode!==5?"offArray":(isOrig()?"offUnison":"offOrig")},
   {k:"cReverse",  t:"toggle", when:()=>P.shapeMode===5&&!P.arrWhole&&isOrig()&&P.choreo>0, why:()=>P.arrWhole?"offWhole":P.shapeMode!==5?"offArray":(isOrig()?"offUnison":"offOrig")},
   {k:"grow",      t:"range", min:0, max:1, step:.01, fmt:v=>v?Math.round(v*100)+"%":"off", hint:"hGrow", when:()=>P.shapeMode===5&&!P.arrWhole&&isOrig(), why:()=>P.arrWhole?"offWhole":P.shapeMode===5?"offOrig":"offArray"},
   {k:"arrayCycle",t:"toggle", hint:"hArrayCycle", when:()=>P.shapeMode===5&&isOrig(), why:()=>P.shapeMode===5?"offOrig":"offArray"},
   {k:"placeMode", t:"seg", opts:"placeOpts", hint:"hPlaceMode", when:()=>P.shapeMode===5&&isOrig()&&!!P.arrayCycle&&!P.arrWhole, why:()=>P.shapeMode!==5?"offArray":(isOrig()?"offArrCycle":"offOrig")},
   {k:"glide",     t:"range", min:0, max:1, step:.01, fmt:v=>v?Math.round(v*100)+"%":"cut", hint:"hGlide", when:()=>P.shapeMode===5&&isOrig()&&!!P.arrayCycle, why:()=>P.shapeMode!==5?"offArray":(isOrig()?"offArrCycle":"offOrig")},
   {k:"plOverlap", t:"range", min:0, max:240, step:1, fmt:v=>v?v+"f / "+(v/30).toFixed(2)+"s":"none", hint:"hOverlap", when:()=>P.shapeMode===5&&isOrig()&&!!P.arrayCycle, why:()=>P.shapeMode!==5?"offArray":(isOrig()?"offArrCycle":"offOrig")},
   {k:"plFadeIn",  t:"range", min:0, max:180, step:1, fmt:v=>v?v+"f / "+(v/30).toFixed(2)+"s":"instant", hint:"hPlFade", when:()=>P.shapeMode===5&&isOrig(), why:()=>P.shapeMode===5?"offOrig":"offArray"},
   {k:"plFadeOut", t:"range", min:0, max:180, step:1, fmt:v=>v?v+"f / "+(v/30).toFixed(2)+"s":"instant", when:()=>P.shapeMode===5&&isOrig(), why:()=>P.shapeMode===5?"offOrig":"offArray"},
   {k:"arrayPause",t:"range", min:0, max:3, step:.05, fmt:v=>v.toFixed(2)+"s", when:()=>P.shapeMode===5&&isOrig(), why:()=>P.shapeMode===5?"offOrig":"offArray"}
 ]},
 {id:"gColour", open:true, items:[
   {k:"bg",     t:"color"},
   {k:"ground", t:"color"},
   {k:"inkA",   t:"color"},
   {k:"duo",    t:"range", min:0, max:1, step:.01, fmt:v=>Math.round(v*100)+"%"},
   {k:"inkB",   t:"color", when:()=>P.duo>0.001, why:"offDuo"}
 ]},
 {id:"gPointer", open:true, items:[
   {k:"hover",     t:"toggle"},
   {k:"pMode",     t:"seg", opts:"pOpts", hint:"hPMode", when:()=>!!P.hover, why:"offHover"},
   {k:"pRadius",   t:"range", min:.15, max:2.5, step:.01, fmt:v=>v.toFixed(2), when:()=>!!P.hover, why:"offHover"},
   {k:"pStrength", t:"range", min:0, max:2, step:.01, fmt:v=>v.toFixed(2), when:()=>!!P.hover, why:"offHover"},
   {k:"pInertia",  t:"range", min:.02, max:.6, step:.01, fmt:v=>v.toFixed(2), when:()=>!!P.hover, why:"offHover"},
   {k:"pMirror",   t:"toggle", when:()=>!!P.hover, why:"offHover"}
 ]},
 {id:"gTone", open:false, items:[
   {k:"contrast",  t:"range", min:.3, max:5, step:.01, fmt:v=>v.toFixed(2)},
   {k:"bias",      t:"range", min:-.6, max:.6, step:.01, fmt:v=>(v>0?"+":"")+v.toFixed(2)},
   {k:"gamma",     t:"range", min:.3, max:3, step:.01, fmt:v=>v.toFixed(2)},
   {k:"flicker",   t:"range", min:0, max:.25, step:.001, fmt:v=>v.toFixed(3), hint:"hFlicker"},
   {k:"flickRate", t:"range", min:.2, max:14, step:.1, fmt:v=>v.toFixed(1), when:()=>P.flicker>0.0001, why:"offFlick"},
   {k:"centreDip", t:"range", min:0, max:.8, step:.01, fmt:v=>v.toFixed(2), hint:"hCentre"},
   {k:"jitter",    t:"range", min:0, max:.5, step:.01, fmt:v=>v.toFixed(2)},
   {k:"scatter",   t:"range", min:0, max:3, step:.01, fmt:v=>v.toFixed(2)+"s", hint:"hScatter"},
   {k:"gridAngle", t:"range", min:-.7854, max:.7854, step:.005, fmt:v=>(v*57.2958).toFixed(1)+"°"},
   {k:"soft",      t:"range", min:0, max:.4, step:.005, fmt:v=>v.toFixed(3)},
   {k:"stagger",   t:"toggle"},
   {k:"invert",    t:"toggle"}
 ]},
 {id:"gMotion", open:false, note:()=>"noteMotion", items:[
   {k:"freq",      t:"range", min:.15, max:2.2, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig(), why:"offProc"},
   {k:"layers",    t:"range", min:1, max:5, step:1, fmt:v=>String(v), when:()=>!isOrig(), why:"offProc"},
   {k:"flowAngle", t:"range", min:-3.1416, max:3.1416, step:.01, fmt:v=>Math.round(v*57.2958)+"°", when:()=>!isOrig(), why:"offProc"},
   {k:"swirl",     t:"range", min:-1.5, max:1.5, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig(), why:"offProc"},
   {k:"mirrorX",   t:"toggle", when:()=>!isOrig(), why:"offProc"},
   {k:"mirrorY",   t:"toggle", when:()=>!isOrig(), why:"offProc"},
   {k:"kaleido",   t:"toggle", when:()=>!isOrig(), why:"offProc"},
   {k:"noiseMix",  t:"range", min:0, max:1, step:.01, fmt:v=>Math.round(v*100)+"%", when:()=>!isOrig(), why:"offProc"},
   {k:"noiseScale",t:"range", min:.2, max:4, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig()&&P.noiseMix>.001, why:()=>isOrig()?"offProc":"offNoise"},
   {k:"noiseDrift",t:"range", min:0, max:1.5, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig()&&P.noiseMix>.001, why:()=>isOrig()?"offProc":"offNoise"},
   {k:"breathAmt", t:"range", min:0, max:.6, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig(), why:"offProc"},
   {k:"breathPer", t:"range", min:1, max:14, step:.1, fmt:v=>v.toFixed(1)+"s", when:()=>!isOrig(), why:"offProc"}
 ]}
];

/* ============================================================
   GL
   ============================================================ */
const cv = document.getElementById("gl");
const gl = cv.getContext("webgl2", {antialias:false, alpha:false, powerPreference:"high-performance"});
if(!gl){
  document.getElementById("stage").innerHTML =
    '<p style="margin:auto;padding:24px;color:#aaa;max-width:40ch;text-align:center">WebGL2 required.</p>';
  return;
}
function compile(type, src){
  const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
  if(!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}
const prog = gl.createProgram();
gl.attachShader(prog, compile(gl.VERTEX_SHADER, VERT));
gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FRAG));
gl.bindAttribLocation(prog, 0, "aPos");
gl.linkProgram(prog);
if(!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
gl.useProgram(prog);
gl.bindVertexArray(gl.createVertexArray());
gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,3,-1,-1,3]), gl.STATIC_DRAW);
gl.enableVertexAttribArray(0);
gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

function makeProgram(fs){
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl.VERTEX_SHADER, VERT));
  gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fs));
  gl.bindAttribLocation(p, 0, "aPos");
  gl.linkProgram(p);
  if(!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  return p;
}
const pProg = makeProgram(PFRAG);
const PU = {};
("uField uPrev uPSize uFrame uFrames uCols uXfade uLoop uTileIn uSheet uStep uHold uRelease uInit")
  .split(" ").forEach(n => PU[n] = gl.getUniformLocation(pProg, n));

const cProg = makeProgram(CFRAG);
const CU = {};
("uSrc uOrigin uInner").split(" ").forEach(n => CU[n] = gl.getUniformLocation(cProg, n));

const HAS_FLOAT = !!gl.getExtension("EXT_color_buffer_float");
const pFbo = gl.createFramebuffer();
let pTex = [null, null], pIdx = 0, pSize = [1,1], pInit = true;
function allocPersist(w, h){
  if(pSize[0] === w && pSize[1] === h && pTex[0]) return;
  pSize = [w, h];
  [0,1].forEach(i => {
    if(pTex[i]) gl.deleteTexture(pTex[i]);
    const t = gl.createTexture();
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, t);
    if(HAS_FLOAT) gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,w,h,0,gl.RGBA,gl.HALF_FLOAT,null);
    else          gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,w,h,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    pTex[i] = t;
  });
  pInit = true;
}

/* one attack / sustain / release step of the per-cell state */
function persistStep(S, frameAbs, step, init, lo, hi, xf){
  gl.useProgram(pProg);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, textures[clipId].tex);
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, pTex[pIdx]);
  gl.uniform1i(PU.uField, 0); gl.uniform1i(PU.uPrev, 1);
  gl.uniform2f(PU.uPSize, pSize[0], pSize[1]);
  gl.uniform1f(PU.uFrame, frameAbs);
  gl.uniform1f(PU.uFrames, S.frames);
  gl.uniform1f(PU.uCols, S.cols);
  gl.uniform1f(PU.uXfade, xf);
  gl.uniform2f(PU.uLoop, lo, hi);
  gl.uniform2f(PU.uTileIn, S.inner[0], S.inner[1]);
  gl.uniform2f(PU.uSheet, S.size[0], S.size[1]);
  gl.uniform1f(PU.uStep, step);
  gl.uniform1f(PU.uHold, P.sustain);
  gl.uniform1f(PU.uRelease, P.fade);
  gl.uniform1f(PU.uInit, init ? 1 : 0);
  gl.bindFramebuffer(gl.FRAMEBUFFER, pFbo);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, pTex[1-pIdx], 0);
  gl.viewport(0, 0, pSize[0], pSize[1]);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  pIdx = 1 - pIdx;
}

const U = {};
("uCenter uUnit uTime uField uUseField uFrame uFrames uCols uTileIn uSheet uXfade uLoop uShapeMode uHourglass " +
 "uTileGap uFeather uMirror uKaleido uLayers uFreq uFlowAngle uSwirl uNoiseMix uNoiseScale uNoiseDrift uContrast " +
 "uBias uBreathAmt uBreathPer uGamma uCell uDotMax uJitter uScatter uStagger uGridAngle uSoft uInvert uSpot " +
 "uInkA uInkB uGroundC uBg uDuo uOpacity uPointer uPVel uPEnergy uPRadius uPStrength uPMirror uPMode uReveal uFlicker uFlickRate uCentreDip uPersist uUsePersist uArrLat uPl uArrOn uArrCycle uTau uLtau uNc uBody uLoopIn uTable uTableM uAtlas uUseAtlas " +
 "uAtlasCols uAtlasStride uAtlasSize uCPat uCPatPrev uCMix uCRev uCRevPrev uSpread uCJitter uCAngle uCCurve uGlide uGrow " +
 "uCOrigin uStageHalf uPeakFrameA uDwellWA uPeakLiftA uPerMark uTarr " +
 "uWhole uCompFit uCompSize uCompInk uCompFeather uCompHour uCompMask uCompGain uOverlap uFadeIn uFadeOut")
 .split(" ").forEach(n => U[n] = gl.getUniformLocation(prog, n));

/* Clips come from clips/clips.js (window.HML_CLIPS). Each entry carries its field
   sheet, reference video, envelope and the screen preset it was drawn with.
   tools/add_clip.py writes new entries; nothing in this file names a clip. */
const CLIPS = window.HML_CLIPS;
let clipId = Object.keys(CLIPS)[0];
const SHEET = () => CLIPS[clipId];
gl.uniform1i(U.uField, 0);
gl.activeTexture(gl.TEXTURE0);
gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
const textures = {};
Object.keys(CLIPS).forEach(k => {
  const t = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 1, 1, 0, gl.RED, gl.UNSIGNED_BYTE, new Uint8Array([0]));
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  textures[k] = {tex:t, ready:false};
  const img = new Image();
  img.decoding = "async";
  img.onload = () => {
    try{
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, gl.RED, gl.UNSIGNED_BYTE, img);
      textures[k].ready = true;
      gl.bindTexture(gl.TEXTURE_2D, textures[clipId].tex);
    }catch(err){
      /* a page opened from file:// cannot hand its images to WebGL */
      console.error(err);
      setTimeout(() => toast(T().fileProto), 400);
    }
  };
  img.src = CLIPS[k].field;
});
const fieldReady = () => textures[clipId].ready;

const hex2rgb = h => { const n = parseInt(h.slice(1),16); return [((n>>16)&255)/255,((n>>8)&255)/255,(n&255)/255]; };

/* ============================================================
   State
   ============================================================ */
let W=1, H=1, dpr=1, time=0, phase=0, dPhase=0, rateNow=1, playing=true, reveal=1, revealing=false;
let lastShape = -1, lastCycle = -1;
/* the two array scopes want very different mark sizes, so each keeps its own layout */
let lastWhole = -1;
const LAYOUT = {perMark:{arrayScale:1.0, arrayGapX:1, arrayGapY:1},
                whole:  {arrayScale:0.85, arrayGapX:0.5, arrayGapY:0.5}};

/* ENV[clip][frame] = that frame's ink, normalised to the clip's own peak.
   It is what the playhead rides: a fuller frame is played slower. */
const ENV = Object.fromEntries(Object.keys(CLIPS).map(k => [k, CLIPS[k].env]));
function loopSpan(){
  const S = SHEET();
  if(!P.seamless) return {lo:0, xf:0, L:S.frames};
  const lo = Math.max(0, Math.min(P.loopIn, P.loopOut-2));
  const xf = Math.max(0, Math.min(P.xfade, (P.loopOut-lo)-1));
  return {lo, xf, L:Math.max(1, P.loopOut - lo - xf)};
}
/* ---- Array: six placements, each a neighbouring slot of the 2:1 tessellation ----
   up, upper-right, lower-right, down, lower-left, upper-left: six steps and back.
   Offsets are in mark half-heights; the ring of placements is centred on the stage. */
const ARR_STEPS = [[0,2],[3,1],[3,-1],[0,-2],[-3,-1],[-3,1]];
const ARR_POS = [[0,0]];
for(let i=0;i<5;i++) ARR_POS.push([ARR_POS[i][0]+ARR_STEPS[i][0], ARR_POS[i][1]+ARR_STEPS[i][1]]);
const ARR_MID = [ARR_POS.reduce((a,p)=>a+p[0],0)/6, ARR_POS.reduce((a,p)=>a+p[1],0)/6];
const PL_FLAT = new Float32Array(ARR_POS.flatMap(p => [p[0]-ARR_MID[0], p[1]-ARR_MID[1]]));
const arrayOn = () => P.shapeMode === 5 && P.useField && !compareOn;
/* one-click starting points for the array choreography */
const CPRESETS = [
  {choreo:0, spread:0,    cJitter:0,    cCurve:1,   cReverse:0, glide:0,   grow:0},     // unison
  {choreo:1, spread:0.6,  cJitter:0.08, cCurve:1,   cReverse:0, glide:0,   grow:0.2, cAngle:0},   // sweep
  {choreo:2, spread:0.75, cJitter:0.05, cCurve:0.8, cReverse:0, glide:0,   grow:0.35},  // ripple
  {choreo:3, spread:1.0,  cJitter:0,    cCurve:1,   cReverse:0, glide:0.6, grow:0.25},  // spiral
  {choreo:4, spread:1.0,  cJitter:0,    cCurve:1,   cReverse:0, glide:0,   grow:0.5},   // twinkle
  {choreo:6, spread:0.5,  cJitter:0,    cCurve:1,   cReverse:0, glide:1,   grow:0.15},  // parade
  {choreo:5, spread:0.5,  cJitter:0,    cCurve:1,   cReverse:0, glide:0.3, grow:0.2}    // checker
];
/* lattice: same-row step 4a(1+gapX), row spacing 2a(1+gapY), rows shifted by a fraction of the step */
function arrLattice(){
  const g = v => P.arraySnap ? Math.round(v*2)/2 : v;
  return [4*(1 + g(P.arrayGapX)), 2*(1 + g(P.arrayGapY)), P.arrayShift];
}
/* first and last frame with any ink, so a cycle runs from empty to empty */
function inkExtent(){
  const e = ENV[clipId]; let lo = 0, hi = e.length-1;
  while(lo < hi && e[lo] < 0.004) lo++;
  while(hi > lo && e[hi] < 0.004) hi--;
  return [Math.max(0, lo-1), Math.min(e.length-1, hi+1)];
}
/* the frame of the clip with the least ink: what an empty mark shows */
function emptyFrame(){
  const e = ENV[clipId]; let k = 0;
  for(let i=1;i<e.length;i++) if(e[i] < e[k]) k = i;
  return k;
}

/* ---- array timing: one cycle of the single animation, precomputed ----
   Each mark runs its own copy of this cycle, offset by its choreography delay, so the
   hold-at-full slowdown, the peak hold, sustain and fade all happen per mark.
   Row 0 of the table maps warped time -> source frame; row 1 is the mark's visible ink. */
const TABLE_M = 1024;
const tableTex = gl.createTexture();
gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, tableTex);
gl.texImage2D(gl.TEXTURE_2D, 0, gl.R32F, 1, 2, 0, gl.RED, gl.FLOAT, new Float32Array(2));
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
let tableKey = "", TI = null;
function arrayTiming(){
  const S = SHEET();
  const key = [clipId, P.loopIn, P.loopOut, P.hold, P.dwell, P.dwellWidth, P.peakFrame,
               P.sustain, P.fade, P.arrayPause, P.tailScale, S.fps].join("|");
  if(key === tableKey && TI) return TI;
  const body = Math.max(2, P.loopOut - P.loopIn);
  const persist = P.sustain > 0 || P.fade > 0;
  const Nc = Math.ceil(body + (persist ? (P.sustain + P.fade)*P.tailScale : 0));
  const pauseF = P.arrayPause*S.fps;
  const cum = new Float64Array(Nc + 1);
  for(let f=0; f<Nc; f++) cum[f+1] = cum[f] + (f < body ? slowAt(P.loopIn + f) : 1);
  const Ltau = cum[Nc] + pauseF;
  const data = new Float32Array(TABLE_M*2);
  for(let i=0, f=0; i<TABLE_M; i++){
    const r = i/(TABLE_M-1)*Ltau;
    if(r >= cum[Nc]){ data[i] = Nc; continue; }
    while(f < Nc-1 && cum[f+1] <= r) f++;
    data[i] = f + (r - cum[f])/Math.max(cum[f+1] - cum[f], 1e-6);
  }
  /* visible ink: the scalar twin of the per-cell sustain / release */
  const vis = new Float32Array(Nc + 1);
  let lvl = 0, hold = 0, vmax = 1e-6;
  for(let g=0; g<=Nc; g++){
    const src = g < body ? fullnessAt(P.loopIn + g) : 0;
    if(!persist) lvl = src;
    else if(src >= lvl){ lvl = src; hold = P.sustain; }
    else{
      let left = 1; const used = Math.min(hold, left); hold -= used; left -= used;
      if(left > 0) lvl -= P.fade > 0.01 ? left/P.fade : 1;
      lvl = Math.max(lvl, src, 0);
    }
    vis[g] = lvl; vmax = Math.max(vmax, lvl);
  }
  for(let i=0; i<TABLE_M; i++){
    const x = i/(TABLE_M-1)*Nc, g0 = Math.floor(x), w = x - g0;
    data[TABLE_M + i] = (vis[g0]*(1-w) + vis[Math.min(Nc, g0+1)]*w)/vmax;
  }
  gl.activeTexture(gl.TEXTURE2);
  gl.bindTexture(gl.TEXTURE_2D, tableTex);
  gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.R32F, TABLE_M, 2, 0, gl.RED, gl.FLOAT, data);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  tableKey = key;
  TI = {body, Nc, pauseF, Ltau, persist, data};
  return TI;
}
function warpJS(r){
  const x = Math.max(0, Math.min(TABLE_M-1, r/TI.Ltau*(TABLE_M-1))), i0 = Math.floor(x);
  return TI.data[i0]*(1-(x-i0)) + TI.data[Math.min(TABLE_M-1, i0+1)]*(x-i0);
}

/* ---- the atlas: every frame of one cycle with sustain / release already applied,
   baked by stepping the same persistence shader one source frame at a time ---- */
const atlasFbo = gl.createFramebuffer();
let atlasTex = null, atlasKey = "", AT = null;
function bakeAtlas(){
  const S = SHEET(), ti = TI;
  if(!ti || !ti.persist || !fieldReady()){ AT = null; return; }
  const key = [clipId, P.loopIn, P.loopOut, P.sustain, P.fade, ti.Nc, P.tailScale].join("|");
  if(key === atlasKey && AT) return;
  const iw = S.inner[0], ih = S.inner[1], tw = iw + 2, th = ih + 2;
  const maxC = Math.floor(4096/tw), maxR = Math.floor(4096/th);
  const stride = Math.max(1, Math.ceil((ti.Nc + 2)/(maxC*maxR)));
  const count = Math.ceil((ti.Nc + 1)/stride) + 1;
  const cols = Math.min(maxC, count), rows = Math.ceil(count/cols);
  const AW = cols*tw, AH = rows*th;
  if(atlasTex) gl.deleteTexture(atlasTex);
  atlasTex = gl.createTexture();
  gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D, atlasTex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, AW, AH, 0, gl.RED, gl.UNSIGNED_BYTE, null);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.bindFramebuffer(gl.FRAMEBUFFER, atlasFbo);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, atlasTex, 0);
  gl.viewport(0, 0, AW, AH); gl.clearColor(0,0,0,1); gl.clear(gl.COLOR_BUFFER_BIT);

  allocPersist(iw, ih);
  const empty = emptyFrame();
  for(let f=0; f<=ti.Nc; f++){
    persistStep(S, f < ti.body ? P.loopIn + f : empty, 1, f === 0, 0, S.frames, 0);
    if(f % stride) continue;
    const t = f/stride, c = t % cols, r = Math.floor(t/cols);
    gl.useProgram(cProg);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, pTex[pIdx]);
    gl.uniform1i(CU.uSrc, 1);
    gl.uniform2f(CU.uOrigin, c*tw, r*th);
    gl.uniform2f(CU.uInner, iw, ih);
    gl.bindFramebuffer(gl.FRAMEBUFFER, atlasFbo);
    gl.viewport(c*tw, r*th, tw, th);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  gl.viewport(0, 0, W, H);
  gl.useProgram(prog);
  pInit = true;                                  // the live buffer was borrowed
  atlasKey = key;
  AT = {cols, AW, AH, stride};
}

/* choreography changes blend in over ~1.2 s instead of snapping every mark's phase */
const CH = {pat:0, rev:0, prevPat:0, prevRev:0, mix:1, spread:0.6, ox:0, oy:0, tx:0, ty:0};

/* where the playhead is, whatever the mode */
function playState(){
  if(arrayOn()){
    const ti = arrayTiming();
    /* the readout follows the mark with no delay */
    const per = !P.arrWhole && (P.placeMode === 1 || !P.arrayCycle);
    const T = (per || P.arrWhole) ? ti.Ltau : ti.Ltau*(1 + CH.spread);
    const stride = Math.max(T - Math.min(P.plOverlap, T - 1), 1);
    const n = Math.floor(phase/stride), r = Math.min(phase - n*stride, ti.Ltau);
    const cf = warpJS(r);
    const inBody = cf < ti.body;
    return { arr:true, cycle:n, cf, inBody, frame: inBody ? P.loopIn + cf : P.loopOut,
             placement: P.arrayCycle ? ((n % 6) + 6) % 6 : 0, ti };
  }
  const sp = loopSpan();
  const tt = ((phase % sp.L) + sp.L) % sp.L;
  return { arr:false, frame: sp.lo + sp.xf + tt, sp };
}
/* real seconds of one loop (or one array placement), hold curve integrated in */
function loopSeconds(){
  const S = SHEET();
  let f = 0;
  if(arrayOn()){
    const ti = arrayTiming();
    const T = (P.arrWhole || P.placeMode === 1 || !P.arrayCycle) ? ti.Ltau : ti.Ltau*(1 + CH.spread);
    f = Math.max(T - Math.min(P.plOverlap, T - 1), 1);   // the cadence you actually see
  }else{
    const sp = loopSpan();
    for(let i=0;i<sp.L;i++) f += slowAt(sp.lo + sp.xf + i);
  }
  return f / S.fps / Math.max(P.speed, 0.01);
}
function fullnessAt(absFrame){
  const e = ENV[clipId];
  const i = Math.max(0, Math.min(e.length-1, Math.round(absFrame)));
  return e[i];
}
/* Gaussian centred on the peak frame, wrapped into the loop */
function peakG(absFrame){
  if(P.dwell <= 0 && P.peakLift <= 0) return 0;
  let d = absFrame - P.peakFrame;
  if(!arrayOn()){ const L = loopSpan().L; d = ((d % L) + L*1.5) % L - L/2; }
  const w = Math.max(1, P.dwellWidth);
  return Math.exp(-(d*d)/(w*w));
}
/* dwell depth chosen so the pause lasts exactly P.dwell seconds */
function dwellDepth(){
  const w = Math.max(1, P.dwellWidth);
  return P.dwell > 0 ? (P.dwell*SHEET().fps)/(w*Math.sqrt(Math.PI)) : 0;
}
function slowAt(absFrame){
  return 1 + P.hold*4*fullnessAt(absFrame) + dwellDepth()*peakG(absFrame);
}
let last=performance.now(), fpsAcc=0, fpsN=0, compareOn=false;
const ptr = {tx:0,ty:0,x:0,y:0,vx:0,vy:0,energy:0,inside:false};
const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
const video = document.getElementById("ref");

function resize(){
  const r = cv.getBoundingClientRect();
  dpr = Math.min(window.devicePixelRatio||1, 2);
  const w = Math.max(1,Math.round(r.width*dpr)), h = Math.max(1,Math.round(r.height*dpr));
  if(w!==W||h!==H){ W=w; H=h; cv.width=W; cv.height=H; gl.viewport(0,0,W,H); }
}
new ResizeObserver(resize).observe(cv);

/* The source frames the hexagon at 60.5% of picture width / 53.8% of picture height.
   min(W*0.15125, H*0.269) reproduces exactly that inside an object-fit:contain 16:9 box,
   so the rebuild and the reference video land on the same pixels in Compare. */
/* array marks default to the reference layout: half-height = 3.81% of the stage */
const markPx = v => Math.round(2*Math.min(W,H)*0.0381*v/dpr);
function unitPx(){
  if(P.shapeMode===5) return Math.min(W,H)*0.0381*P.arrayScale;
  if(P.shapeMode===0) return Math.min(W*0.15125, H*0.269)*P.size;
  if(P.shapeMode===1) return Math.max(W*0.25, H*0.5)*P.size;
  return Math.min(W,H)*0.5*P.size;
}

function frame(now){
  const dt = Math.min(0.1,(now-last)/1000); last = now;
  fpsAcc += dt; fpsN++;
  if(fpsAcc>0.5){ roF.textContent = Math.round(fpsN/fpsAcc); fpsAcc=0; fpsN=0; }

  dPhase = 0;
  if(compareOn && !video.paused){
    time = video.currentTime; phase = time*SHEET().fps; rateNow = 1;
  }else if(playing){
    const st0 = playState();
    rateNow = st0.arr ? 1 : 1/slowAt(st0.frame);
    dPhase = dt*P.speed*SHEET().fps*rateNow;
    phase += dPhase;
    time  += dt*P.speed*rateNow;
  }
  if(P.shapeMode === 5 && lastShape !== 5) enterArray();
  lastShape = P.shapeMode;
  if(P.arrWhole !== lastWhole){
    if(lastWhole !== -1){
      const from = P.arrWhole ? LAYOUT.perMark : LAYOUT.whole;
      const to   = P.arrWhole ? LAYOUT.whole   : LAYOUT.perMark;
      Object.keys(from).forEach(k => from[k] = P[k]);
      Object.assign(P, to);
      syncAll();
    }
    lastWhole = P.arrWhole;
  }

  /* ease the choreography: a new pattern blends in, spread and centre glide */
  if(P.choreo !== CH.pat || P.cReverse !== CH.rev){
    if(CH.mix > 0.5){ CH.prevPat = CH.pat; CH.prevRev = CH.rev; }
    CH.pat = P.choreo; CH.rev = P.cReverse; CH.mix = 0;
  }
  CH.mix = Math.min(1, CH.mix + dt/1.2);
  CH.spread += (P.spread - CH.spread)*Math.min(1, dt*2.5);
  if(!P.cClick){ CH.tx = 0; CH.ty = 0; }
  CH.ox += (CH.tx - CH.ox)*Math.min(1, dt*1.6);
  CH.oy += (CH.ty - CH.oy)*Math.min(1, dt*1.6);
  if(revealing){ reveal = Math.min(1, reveal+dt/1.15); if(reveal>=1) revealing = false; }

  const k = 1-Math.pow(1-P.pInertia, dt*60);
  const ox=ptr.x, oy=ptr.y;
  ptr.x += (ptr.tx-ptr.x)*k; ptr.y += (ptr.ty-ptr.y)*k;
  if(dt>0){
    ptr.vx += (((ptr.x-ox)/dt)*0.09-ptr.vx)*Math.min(1,dt*6);
    ptr.vy += (((ptr.y-oy)/dt)*0.09-ptr.vy)*Math.min(1,dt*6);
  }
  const want = (P.hover && ptr.inside)?1:0;
  ptr.energy += (want-ptr.energy)*Math.min(1, dt*(want?4.5:2.6));

  resize();
  const S = SHEET(), sp = loopSpan(), st = playState();
  const unit = unitPx();
  /* never draw cells smaller than ~1.6 device px: below that a halftone only aliases */
  let cell = 2/Math.max(2,P.density), gridAuto = false;
  if(cell*unit < 1.6){ cell = 1.6/unit; gridAuto = true; }
  const fi = compareOn ? time*S.fps : (st.arr ? st.frame : phase);
  const loLoop = st.arr ? 0 : sp.lo, xfLoop = st.arr ? 0 : sp.xf,
        hiLoop = st.arr ? S.frames : (sp.lo + sp.xf + sp.L);
  if(st.arr) bakeAtlas();
  const persistOn = (P.useField && !compareOn && !st.arr && (P.sustain > 0 || P.fade > 0) && fieldReady());

  if(persistOn){
    allocPersist(S.inner[0], S.inner[1]);
    persistStep(S, fi, dPhase, pInit, loLoop, hiLoop, xfLoop);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, W, H);
    gl.useProgram(prog);
    pInit = false;
  }else{
    pInit = true;
  }
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, textures[clipId].tex);
  gl.uniform1i(U.uField, 0);
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, pTex[pIdx] || textures[clipId].tex);
  gl.uniform1i(U.uPersist, 1);
  gl.uniform1f(U.uUsePersist, persistOn ? 1 : 0);

  gl.uniform2f(U.uCenter, W/2, H/2);
  gl.uniform1f(U.uUnit, unit);
  gl.uniform1f(U.uTime, time);
  gl.uniform1f(U.uUseField, (P.useField && fieldReady())?1:0);
  gl.uniform1f(U.uFrame, fi);
  gl.uniform1f(U.uFrames, S.frames);
  gl.uniform1f(U.uCols, S.cols);
  gl.uniform2f(U.uTileIn, S.inner[0], S.inner[1]);
  gl.uniform2f(U.uSheet, S.size[0], S.size[1]);
  gl.uniform1f(U.uXfade, compareOn ? 0 : xfLoop);
  gl.uniform2f(U.uLoop, compareOn ? 0 : loLoop, compareOn ? S.frames : hiLoop);
  gl.uniform1i(U.uShapeMode, (compareOn && P.shapeMode === 5) ? 0 : (P.shapeMode|0));
  const lat = arrLattice(), ti = st.arr ? st.ti : null;
  gl.uniform3f(U.uArrLat, lat[0], lat[1], lat[2]);
  gl.uniform2fv(U.uPl, PL_FLAT);
  gl.uniform1f(U.uArrOn, st.arr ? 1 : 0);
  gl.uniform1f(U.uArrCycle, P.arrayCycle ? 1 : 0);
  gl.uniform1f(U.uTau, phase);
  gl.uniform1f(U.uLtau, ti ? ti.Ltau : 1);
  const whole = st.arr && !!P.arrWhole;
  gl.uniform1f(U.uPerMark, (!whole && (P.placeMode === 1 || !P.arrayCycle)) ? 1 : 0);
  const TT = ti ? ti.Ltau*(1 + (whole ? 0 : CH.spread)) : 1;
  gl.uniform1f(U.uTarr, TT);
  gl.uniform1f(U.uOverlap, Math.min(P.plOverlap, TT - 1));
  gl.uniform1f(U.uFadeIn, P.plFadeIn);
  gl.uniform1f(U.uFadeOut, P.plFadeOut);
  gl.uniform1f(U.uWhole, whole ? 1 : 0);
  /* the composite hexagon is framed like the Icon view, then scaled */
  /* the field's 2:1 domain laid over the stage: contain, cover or stretched */
  const fx = W/4, fy = H/2;
  let sxp, syp;
  if(P.compFit === 0){ sxp = syp = Math.min(fx, fy); }
  else if(P.compFit === 2){ sxp = fx; syp = fy; }
  else { sxp = syp = Math.max(fx, fy); }
  gl.uniform2f(U.uCompFit, sxp*P.compScale/unit, syp*P.compScale/unit);
  gl.uniform1f(U.uCompMask, P.compMask ? 1 : 0);
  gl.uniform1f(U.uCompGain, P.compGain*(1/Math.max(SHEET().peak || 1, 0.05)));
  gl.uniform1f(U.uCompSize, P.compSize);
  gl.uniform1f(U.uCompInk, P.compInk);
  gl.uniform1f(U.uCompFeather, P.compFeather);
  gl.uniform1f(U.uCompHour, P.compHour ? 1 : 0);
  gl.uniform1f(U.uNc, ti ? ti.Nc : 1);
  gl.uniform1f(U.uBody, ti ? ti.body : 1);
  gl.uniform1f(U.uLoopIn, P.loopIn);
  gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, tableTex);
  gl.uniform1i(U.uTable, 2);
  gl.uniform1f(U.uTableM, TABLE_M);
  gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D, (st.arr && AT) ? atlasTex : textures[clipId].tex);
  gl.uniform1i(U.uAtlas, 3);
  gl.uniform1f(U.uUseAtlas, (st.arr && AT) ? 1 : 0);
  gl.uniform1f(U.uAtlasCols, AT ? AT.cols : 1);
  gl.uniform1f(U.uAtlasStride, AT ? AT.stride : 1);
  gl.uniform2f(U.uAtlasSize, AT ? AT.AW : 1, AT ? AT.AH : 1);
  const cm = CH.mix*CH.mix*(3 - 2*CH.mix);
  gl.uniform1i(U.uCPat, CH.pat); gl.uniform1i(U.uCPatPrev, CH.prevPat);
  gl.uniform1f(U.uCMix, cm);
  gl.uniform1f(U.uCRev, CH.rev); gl.uniform1f(U.uCRevPrev, CH.prevRev);
  gl.uniform1f(U.uSpread, (whole ? 0 : CH.spread)*(ti ? ti.Ltau : 1));
  gl.uniform1f(U.uCJitter, P.cJitter);
  gl.uniform1f(U.uCAngle, P.cAngle);
  gl.uniform1f(U.uCCurve, P.cCurve);
  gl.uniform1f(U.uGlide, P.arrayCycle ? P.glide : 0);
  gl.uniform1f(U.uGrow, P.grow);
  gl.uniform2f(U.uCOrigin, CH.ox, CH.oy);
  gl.uniform2f(U.uStageHalf, W/2/unit, H/2/unit);
  gl.uniform1f(U.uPeakFrameA, P.peakFrame);
  gl.uniform1f(U.uDwellWA, P.dwellWidth);
  gl.uniform1f(U.uPeakLiftA, P.peakLift);
  gl.uniform1f(U.uHourglass, P.hourglass?1:0);
  gl.uniform1f(U.uTileGap, P.tileGap);
  gl.uniform1f(U.uFeather, P.feather);
  gl.uniform2f(U.uMirror, P.mirrorX?1:0, P.mirrorY?1:0);
  gl.uniform1f(U.uKaleido, P.kaleido?1:0);
  gl.uniform1f(U.uLayers, P.layers);
  gl.uniform1f(U.uFreq, P.freq);
  gl.uniform1f(U.uFlowAngle, P.flowAngle);
  gl.uniform1f(U.uSwirl, P.swirl);
  gl.uniform1f(U.uNoiseMix, P.noiseMix);
  gl.uniform1f(U.uNoiseScale, P.noiseScale);
  gl.uniform1f(U.uNoiseDrift, P.noiseDrift);
  gl.uniform1f(U.uContrast, P.contrast);
  gl.uniform1f(U.uBias, P.bias + (st.arr ? 0 : P.peakLift*peakG(st.frame)));
  gl.uniform1f(U.uBreathAmt, P.breathAmt);
  gl.uniform1f(U.uBreathPer, P.breathPer);
  gl.uniform1f(U.uGamma, P.gamma);
  gl.uniform1f(U.uCell, cell);
  gl.uniform1f(U.uDotMax, P.dotMax);
  gl.uniform1f(U.uJitter, P.jitter);
  gl.uniform1f(U.uScatter, P.scatter);
  gl.uniform1f(U.uStagger, P.stagger?1:0);
  gl.uniform1f(U.uGridAngle, P.gridAngle);
  gl.uniform1f(U.uSoft, P.soft);
  gl.uniform1f(U.uInvert, P.invert?1:0);
  gl.uniform1i(U.uSpot, P.spot|0);
  gl.uniform3fv(U.uInkA, hex2rgb(P.inkA));
  gl.uniform3fv(U.uInkB, hex2rgb(P.inkB));
  gl.uniform3fv(U.uGroundC, hex2rgb(P.ground));
  gl.uniform3fv(U.uBg, hex2rgb(P.bg));
  gl.uniform1f(U.uDuo, P.duo);
  gl.uniform1f(U.uOpacity, P.opacity);
  gl.uniform2f(U.uPointer, ptr.x, ptr.y);
  gl.uniform2f(U.uPVel, ptr.vx, ptr.vy);
  gl.uniform1f(U.uPEnergy, ptr.energy);
  gl.uniform1f(U.uPRadius, P.pRadius);
  gl.uniform1f(U.uPStrength, P.pStrength);
  gl.uniform1f(U.uPMirror, P.pMirror?1:0);
  gl.uniform1i(U.uPMode, P.pMode|0);
  gl.uniform1f(U.uReveal, P.useField?1:reveal);
  gl.uniform1f(U.uFlicker, P.flicker);
  gl.uniform1f(U.uFlickRate, P.flickRate);
  gl.uniform1f(U.uCentreDip, P.centreDip);

  gl.drawArrays(gl.TRIANGLES, 0, 3);

  roT.textContent = P.speed < 0.01 ? "—" : loopSeconds().toFixed(2);
  roFr.textContent = (st.arr && !st.inBody) ? "—" : String(Math.round(st.frame));
  roPl.parentNode.hidden = !st.arr;
  if(st.arr) roPl.textContent = (st.placement+1) + "/6";
  roB.textContent = "×"+(st.arr ? (st.inBody ? slowAt(st.frame) : 1) : 1/Math.max(rateNow,1e-3)).toFixed(2);
  drawTimeline();
  roG.textContent = gridAuto ? Math.round(2/cell) + "*" : P.density;
  roC.textContent = (cell*unit/dpr).toFixed(1)+"px";
  requestAnimationFrame(frame);
}

function toHex(e){
  const r = cv.getBoundingClientRect(), unit = unitPx();
  return [((e.clientX-r.left)*dpr-W/2)/unit, (H/2-(e.clientY-r.top)*dpr)/unit];
}
cv.addEventListener("pointermove", e => { const q=toHex(e); ptr.tx=q[0]; ptr.ty=q[1]; ptr.inside=true; });
cv.addEventListener("pointerenter", e => { const q=toHex(e); if(ptr.energy<0.01){ptr.x=q[0];ptr.y=q[1];} ptr.tx=q[0]; ptr.ty=q[1]; ptr.inside=true; });
cv.addEventListener("pointerleave", () => { ptr.inside=false; });
cv.addEventListener("pointerdown", e => {
  cv.setPointerCapture(e.pointerId); ptr.inside=true;
  if(P.shapeMode === 5 && P.cClick && (P.choreo === 2 || P.choreo === 3)){ const q = toHex(e); CH.tx = q[0]; CH.ty = q[1]; }
});
cv.addEventListener("dblclick", () => { CH.tx = 0; CH.ty = 0; });

/* ============================================================
   UI
   ============================================================ */
const rail = document.getElementById("rail");
const rows = [];           // {it, key, wrap, sync, setLang}
const groups = [];
let tlCanvas = null, tlCtx = null;

/* entering the array: a cycle runs the whole clip, first ink to last */
function enterArray(){
  const [lo, hi] = inkExtent();
  P.loopIn = lo; P.loopOut = hi; phase = 0; pInit = true;
  syncAll();
}
function autoLoop(){
  if(P.shapeMode === 5){ enterArray(); return; }
  const e = ENV[clipId], n = e.length;
  let lo = 0, hi = n-1;
  while(lo < n-1 && e[lo] < 0.12) lo++;
  while(hi > 0   && e[hi] < 0.12) hi--;
  P.loopIn = lo; P.loopOut = hi;
  P.xfade = Math.max(4, Math.min(40, Math.round((hi-lo)/6)));
  P.seamless = 1; phase = 0; syncAll();
}

function drawTimeline(){
  if(!tlCanvas || !tlCtx) return;
  const e = ENV[clipId], n = e.length;
  const r = tlCanvas.getBoundingClientRect();
  if(r.width < 4) return;
  const w = Math.round(r.width*dpr), h = Math.round(r.height*dpr);
  if(tlCanvas.width !== w || tlCanvas.height !== h){ tlCanvas.width = w; tlCanvas.height = h; }
  const cs = getComputedStyle(document.documentElement);
  let acc = cs.getPropertyValue("--accent").trim();
  if(!/^#[0-9a-f]{6}$/i.test(acc)) acc = "#db0011";
  const tlDim  = cs.getPropertyValue("--tl-dim").trim()  || "rgba(0,0,0,.5)";
  const tlMark = cs.getPropertyValue("--tl-mark").trim() || "#888";
  const tlPeak = cs.getPropertyValue("--tl-peak").trim() || "#fff";
  const c = tlCtx, pad = 3*dpr, gh = h-2*pad, X = i => pad + (Math.max(0,Math.min(n-1,i))/(n-1))*(w-2*pad);
  c.clearRect(0,0,w,h);

  c.beginPath(); c.moveTo(X(0), h-pad);
  for(let i=0;i<n;i++) c.lineTo(X(i), h-pad-e[i]*gh);
  c.lineTo(X(n-1), h-pad); c.closePath();
  c.fillStyle = "rgba(128,136,146,0.42)"; c.fill();

  if(P.hold > 0.001 || P.dwell > 0.001){
    c.beginPath();
    for(let i=0;i<n;i++){
      const y = h-pad-(1/slowAt(i))*gh;
      i ? c.lineTo(X(i),y) : c.moveTo(X(i),y);
    }
    c.strokeStyle = acc; c.lineWidth = 1.4*dpr;
    c.setLineDash([3*dpr,3*dpr]); c.stroke(); c.setLineDash([]);
  }

  const sp = loopSpan(), st = playState();
  if(st.arr){
    const a = X(P.loopIn), b = X(P.loopOut);
    c.fillStyle = tlDim; c.fillRect(0,0,a,h); c.fillRect(b,0,w-b,h);
    c.fillStyle = tlMark; c.fillRect(a-dpr,0,2*dpr,h); c.fillRect(b-dpr,0,2*dpr,h);
  }else if(P.seamless){
    const a = X(sp.lo), b = X(sp.lo+sp.xf+sp.L);
    c.fillStyle = tlDim; c.fillRect(0,0,a,h); c.fillRect(b,0,w-b,h);
    c.fillStyle = acc+"2e";
    c.fillRect(a,0,X(sp.lo+sp.xf)-a,h);
    c.fillRect(X(sp.lo+sp.L),0,b-X(sp.lo+sp.L),h);
    c.fillStyle = tlMark;
    c.fillRect(a-dpr,0,2*dpr,h); c.fillRect(b-dpr,0,2*dpr,h);
  }
  if(P.dwell > 0.001 || P.peakLift > 0.001){
    c.fillStyle = tlPeak;
    const pw = Math.max(2*dpr, X(P.peakFrame+P.dwellWidth)-X(P.peakFrame-P.dwellWidth));
    c.fillRect(X(P.peakFrame)-pw/2, h-3*dpr, pw, 3*dpr);
    c.fillRect(X(P.peakFrame)-dpr*0.75, 0, 1.5*dpr, h);
  }
  const ph = st.arr ? (st.inBody ? st.frame : P.loopOut) : st.frame;
  c.fillStyle = acc; c.fillRect(X(ph)-dpr, 0, 2*dpr, h);
}

function build(){
  rail.textContent = "";
  rows.length = 0; groups.length = 0;
  SCHEMA.forEach(g => {
    const d = document.createElement("details");
    d.className = "grp"; d.open = g.open;
    const s = document.createElement("summary"); d.appendChild(s);
    const body = document.createElement("div"); body.className = "grp-body";
    let noteEl = null;
    if(g.note){ noteEl = document.createElement("p"); noteEl.className = "grpnote"; body.appendChild(noteEl); }
    g.items.forEach(it => body.appendChild(makeCtl(it)));
    d.appendChild(body); rail.appendChild(d);
    groups.push({g, s, noteEl});
  });
  const act = document.createElement("div");
  act.className = "grp-body"; act.style.paddingTop = "16px";
  act.innerHTML = '<div class="rowbtns"><button class="btn" id="btnReset"></button>'+
    '<button class="btn" id="btnShader"></button></div><p class="hint" id="foot"></p>';
  rail.appendChild(act);
  document.getElementById("btnReset").addEventListener("click", () => {
    Object.assign(P, DEFAULTS, CLIPS[clipId].preset);
    Object.assign(P, STAGE[effectiveTheme()]);
    syncAll(); applyLang(); stageFollowTheme();
  });
  document.getElementById("btnShader").addEventListener("click", () => copy(FRAG, "GLSL"));
}

function makeCtl(it){
  const key = it.key || it.k;
  const wrap = document.createElement("div"); wrap.className = "ctl";
  const id = "c_" + key;
  let setLang = () => {};

  if(it.t === "range"){
    wrap.innerHTML = '<div class="lab"><label for="'+id+'"><span></span></label><output></output></div>'+
      '<input type="range" id="'+id+'" min="'+it.min+'" max="'+it.max+'" step="'+it.step+'">';
    const inp = wrap.querySelector("input"), out = wrap.querySelector("output"), lb = wrap.querySelector("span");
    const sync = () => { inp.value = P[key]; out.textContent = it.fmt(+P[key]); };
    inp.addEventListener("input", () => { P[key] = +inp.value; out.textContent = it.fmt(+inp.value); refreshCtx(); });
    setLang = () => { lb.textContent = T()[it.k] || it.k; };
    rows.push({it, key, wrap, sync, setLang});
  }
  else if(it.t === "toggle"){
    wrap.innerHTML = '<div class="sw"><span></span><button class="tog" id="'+id+'" role="switch"></button></div>';
    const b = wrap.querySelector("button"), lb = wrap.querySelector("span");
    const sync = () => b.setAttribute("aria-pressed", P[key] ? "true" : "false");
    b.addEventListener("click", () => { P[key] = P[key] ? 0 : 1; sync(); refreshCtx(); });
    setLang = () => { lb.textContent = T()[it.k] || it.k; };
    rows.push({it, key, wrap, sync, setLang});
  }
  else if(it.t === "seg"){
    wrap.innerHTML = '<div class="lab"><span></span></div><div class="segs"></div>';
    const box = wrap.querySelector(".segs"), lb = wrap.querySelector("span");
    const n = Array.isArray(it.opts) ? it.opts.length : T()[it.opts].length;
    const btns = [];
    for(let i=0;i<n;i++){
      const b = document.createElement("button");
      b.className = "seg"; b.dataset.v = i;
      b.addEventListener("click", () => { P[key] = i; sync(); refreshCtx(); });
      box.appendChild(b); btns.push(b);
    }
    const sync = () => btns.forEach(b => b.setAttribute("aria-pressed", (+b.dataset.v === +P[key]) ? "true":"false"));
    setLang = () => {
      lb.textContent = T()[it.k] || it.k;
      const names = Array.isArray(it.opts) ? it.opts.map(o => T()[o] || o) : T()[it.opts];
      btns.forEach((b,i) => b.textContent = names[i]);
    };
    rows.push({it, key, wrap, sync, setLang});
  }
  else if(it.t === "chips"){
    wrap.innerHTML = '<div class="lab"><span></span></div><div class="segs"></div>';
    const box = wrap.querySelector(".segs"), lb = wrap.querySelector("span");
    const btns = CPRESETS.map((bundle, i) => {
      const b = document.createElement("button");
      b.type = "button"; b.className = "seg";
      b.addEventListener("click", () => { Object.assign(P, bundle); syncAll(); });
      box.appendChild(b); return b;
    });
    const sync = () => {};
    setLang = () => { lb.textContent = T()[it.k] || it.k; const n = T()[it.opts]; btns.forEach((b,i) => b.textContent = n[i]); };
    rows.push({it, key:it.k, wrap, sync, setLang});
  }
  else if(it.t === "timeline"){
    wrap.innerHTML = '<div class="lab tlrow"><span></span><button type="button" class="tlauto"></button></div>'+
      '<canvas class="tl"></canvas>';
    const lb = wrap.querySelector("span"), btn = wrap.querySelector(".tlauto");
    tlCanvas = wrap.querySelector("canvas"); tlCtx = tlCanvas.getContext("2d");
    btn.addEventListener("click", autoLoop);
    tlCanvas.addEventListener("pointerdown", e => {
      tlCanvas.setPointerCapture(e.pointerId);
      const n = CLIPS[clipId].frames;
      const pick = ev => {
        const rc = tlCanvas.getBoundingClientRect();
        return Math.max(0, Math.min(n, Math.round(((ev.clientX-rc.left)/rc.width)*(n-1))));
      };
      const f0 = pick(e);
      const grab = Math.abs(f0-P.loopIn) < Math.abs(f0-P.loopOut) ? "loopIn" : "loopOut";
      const move = ev => {
        const fr = pick(ev);
        if(grab === "loopIn") P.loopIn = Math.min(fr, P.loopOut-4);
        else                  P.loopOut = Math.max(fr, P.loopIn+4);
        P.seamless = 1; syncAll();
      };
      move(e);
      const up = () => { window.removeEventListener("pointermove",move); window.removeEventListener("pointerup",up); };
      window.addEventListener("pointermove",move); window.addEventListener("pointerup",up);
      e.preventDefault();
    });
    const sync = () => {};
    setLang = () => { lb.textContent = T()[it.k] || it.k; btn.textContent = T().auto; };
    rows.push({it, key:it.k, wrap, sync, setLang});
  }
  else if(it.t === "color"){
    wrap.innerHTML = '<div class="lab"><label for="'+id+'"><span></span></label></div>'+
      '<div class="colorrow"><input type="color" id="'+id+'"><code></code></div>';
    const inp = wrap.querySelector("input"), code = wrap.querySelector("code"), lb = wrap.querySelector("span");
    const sync = () => { inp.value = P[key]; code.textContent = P[key]; };
    inp.addEventListener("input", () => { P[key] = inp.value; code.textContent = inp.value; refreshCtx(); });
    setLang = () => { lb.textContent = T()[it.k] || it.k; };
    rows.push({it, key, wrap, sync, setLang});
  }

  const hintEl = document.createElement("p"); hintEl.className = "hint"; wrap.appendChild(hintEl);
  const whyEl = document.createElement("p"); whyEl.className = "why"; wrap.appendChild(whyEl);
  const r = rows[rows.length-1];
  r.hintEl = hintEl; r.whyEl = whyEl;
  const base = r.setLang;
  r.setLang = () => { base(); hintEl.textContent = it.hint ? (T()[it.hint]||"") : ""; hintEl.hidden = !it.hint; };
  r.sync();
  return wrap;
}

function refreshCtx(){
  /* spacing snaps to half a mark while Snap is on, so the array stays proportional */
  rows.forEach(r => {
    if(r.key !== "arrayGapX" && r.key !== "arrayGapY") return;
    const inp = r.wrap.querySelector("input");
    inp.step = P.arraySnap ? "0.5" : "0.01";
    if(P.arraySnap){ const v = Math.round(P[r.key]*2)/2; if(v !== P[r.key]){ P[r.key] = v; r.sync(); } }
  });
  rows.forEach(r => {
    const ok = r.it.when ? !!r.it.when() : true;
    r.wrap.classList.toggle("off", !ok);
    if(!ok){
      const w = typeof r.it.why === "function" ? r.it.why() : r.it.why;
      r.whyEl.textContent = w ? (T()[w] || "") : "";
    }
  });
  groups.forEach(o => { if(o.noteEl) o.noteEl.textContent = T()[o.g.note()] || ""; });
}
const syncAll = () => { rows.forEach(r => r.sync()); refreshCtx(); };

function applyLang(){
  const t = T();
  document.getElementById("ttl").textContent = t.title;
  document.getElementById("sub").textContent = t.sub;
  document.getElementById("mOrig").textContent = t.orig;
  document.getElementById("mProc").textContent = t.proc;
  document.getElementById("btnCmp").textContent = t.compare;
  document.getElementById("btnPlay").textContent = playing ? t.play : t.paused;
  document.getElementById("btnReplay").textContent = t.replay;
  document.getElementById("btnSolo").textContent =
    document.getElementById("stage").classList.contains("solo") ? t.exitSolo : t.solo;
  document.getElementById("btnCopy").textContent = t.copy;
  document.getElementById("btnLang").textContent = lang === "zh" ? "EN" : "中文";
  document.getElementById("labL").textContent = t.labL;
  document.getElementById("labR").textContent = t.labR;
  document.getElementById("rlT").firstChild.nodeValue = t.rlT + " ";
  document.getElementById("rlFr").firstChild.nodeValue = t.rlFr + " ";
  document.getElementById("rlG").firstChild.nodeValue = t.rlG + " ";
  document.getElementById("rlC").firstChild.nodeValue = t.rlC + " ";
  document.getElementById("rlB").firstChild.nodeValue = t.rlB + " ";
  document.getElementById("rlPl").firstChild.nodeValue = t.rlPl + " ";
  document.getElementById("btnReset").textContent = t.reset;
  document.getElementById("btnShader").textContent = t.glsl;
  document.getElementById("foot").textContent = t.hFoot;
  groups.forEach(o => o.s.textContent = t[o.g.id] || o.g.id);
  rows.forEach(r => r.setLang());
  refreshCtx();
  document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
}

const DEFAULTS = Object.assign({}, P);
build(); applyLang(); syncAll();

/* ---------- toolbar ---------- */
const toast = msg => {
  const el = document.getElementById("toast");
  el.textContent = msg; el.classList.add("on");
  clearTimeout(toast._id); toast._id = setTimeout(() => el.classList.remove("on"), 1800);
};
async function copy(text, label){
  try{ await navigator.clipboard.writeText(text); toast(label + " " + T().copied); }
  catch(e){ toast(T().clipFail); }
}
/* header clip switcher, one button per manifest entry */
const clipBox = document.getElementById("clipsw");
Object.keys(CLIPS).forEach(k => {
  const b = document.createElement("button");
  b.type = "button"; b.dataset.clip = k; b.textContent = CLIPS[k].name;
  b.setAttribute("aria-pressed", k === clipId ? "true" : "false");
  b.addEventListener("click", () => setClip(k));
  clipBox.appendChild(b);
});
function setClip(k){
  clipId = k;
  Object.assign(P, CLIPS[k].preset);
  if(P.shapeMode === 5) enterArray();
  [...clipBox.children].forEach(b => b.setAttribute("aria-pressed", b.dataset.clip === k ? "true" : "false"));
  document.getElementById("sub").textContent = CLIPS[k].name;
  time = 0; phase = 0;
  rows.forEach(r => {
    if(r.key === "loopIn" || r.key === "loopOut" || r.key === "peakFrame"){
      const inp = r.wrap.querySelector("input"); if(inp) inp.max = CLIPS[k].frames;
    }
  });
  video.src = CLIPS[k].ref;
  if(compareOn){ video.currentTime = 0; video.play().catch(()=>{}); }
  syncAll();
}

const setMode = useField => {
  P.useField = useField ? 1 : 0;
  document.getElementById("mOrig").setAttribute("aria-pressed", useField ? "true":"false");
  document.getElementById("mProc").setAttribute("aria-pressed", useField ? "false":"true");
  if(!useField){ reveal = 0; revealing = true; }
  refreshCtx();
};
document.getElementById("mOrig").addEventListener("click", () => setMode(true));
document.getElementById("mProc").addEventListener("click", () => setMode(false));

const btnPlay = document.getElementById("btnPlay");
const setPlay = v => {
  playing = v; btnPlay.textContent = v ? T().play : T().paused;
  if(compareOn){ v ? video.play() : video.pause(); }
};
setPlay(!reduced);
btnPlay.addEventListener("click", () => setPlay(!playing));
document.getElementById("btnReplay").addEventListener("click", () => {
  time = 0; phase = 0; if(compareOn) video.currentTime = 0;
  if(!P.useField){ reveal = 0; revealing = true; }
});
document.getElementById("btnSolo").addEventListener("click", () => {
  const on = document.getElementById("stage").classList.toggle("solo");
  document.getElementById("btnSolo").textContent = on ? T().exitSolo : T().solo;
  requestAnimationFrame(resize);
});
document.getElementById("btnCopy").addEventListener("click", () => copy(JSON.stringify(P,null,2), "Config"));
/* ---------- theme: auto / light / dark, for the chrome and the stage ---------- */
const STAGE = { light:{bg:"#ffffff", ground:"#ffffff"}, dark:{bg:"#000000", ground:"#000000"} };
const root = document.documentElement;
const hostTheme = root.getAttribute("data-theme");       // whatever the page was opened with
const mqDark = matchMedia("(prefers-color-scheme: dark)");
let themeMode = "auto";
try{ const t = localStorage.getItem("hml_theme"); if(t === "light" || t === "dark" || t === "auto") themeMode = t; }catch(e){}
function effectiveTheme(){
  if(themeMode !== "auto") return themeMode;
  const h = root.getAttribute("data-theme");
  if(h === "light" || h === "dark") return h;
  return mqDark.matches ? "dark" : "light";
}
/* swap the stage colours only if they are still the other theme's defaults,
   so a colour you picked by hand survives a theme change */
function stageFollowTheme(){
  const eff = effectiveTheme(), other = eff === "dark" ? "light" : "dark";
  let changed = false;
  ["bg","ground"].forEach(k => {
    if(String(P[k]).toLowerCase() === STAGE[other][k]){ P[k] = STAGE[eff][k]; changed = true; }
  });
  if(changed) syncAll();
  const b = document.getElementById("btnTheme");
  if(b) b.textContent = T()["theme_"+themeMode];
}
function applyTheme(){
  if(themeMode === "auto"){ hostTheme ? root.setAttribute("data-theme", hostTheme) : root.removeAttribute("data-theme"); }
  else root.setAttribute("data-theme", themeMode);
  stageFollowTheme();
}
document.getElementById("btnTheme").addEventListener("click", () => {
  themeMode = themeMode === "auto" ? "light" : themeMode === "light" ? "dark" : "auto";
  try{ localStorage.setItem("hml_theme", themeMode); }catch(e){}
  applyTheme();
});
mqDark.addEventListener("change", () => { if(themeMode === "auto") stageFollowTheme(); });
new MutationObserver(() => { if(themeMode === "auto") stageFollowTheme(); })
  .observe(root, {attributes:true, attributeFilter:["data-theme"]});
applyTheme();

document.getElementById("btnLang").addEventListener("click", () => {
  lang = lang === "zh" ? "en" : "zh";
  try{ localStorage.setItem("hml_lang", lang); }catch(e){}
  build(); applyLang(); syncAll(); stageFollowTheme();
});

/* ---------- compare ---------- */
const stage = document.getElementById("stage"), split = document.getElementById("split");
let splitX = 0.5;
function layoutSplit(){
  split.style.left = (splitX*100) + "%";
  video.style.clipPath = "inset(0 0 0 " + (splitX*100) + "%)";
  document.getElementById("labR").style.opacity = splitX > 0.88 ? "0" : "1";
  document.getElementById("labL").style.opacity = splitX < 0.12 ? "0" : "1";
}
layoutSplit();
document.getElementById("btnCmp").addEventListener("click", e => {
  compareOn = !compareOn;
  e.currentTarget.setAttribute("aria-pressed", compareOn ? "true":"false");
  stage.classList.toggle("cmp", compareOn);
  if(compareOn){
    setMode(true); P.speed = 1; P.loopMode = 0; P.shapeMode = 0; P.size = 1;
    syncAll();
    video.currentTime = 0; video.play().catch(()=>{});
    if(!playing) setPlay(true);
  }else{ video.pause(); }
  refreshCtx();
});
split.addEventListener("pointerdown", e => {
  split.setPointerCapture(e.pointerId);
  const move = ev => {
    const r = stage.getBoundingClientRect();
    splitX = Math.min(1, Math.max(0, (ev.clientX-r.left)/r.width));
    layoutSplit();
  };
  const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); };
  window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  e.preventDefault();
});

document.addEventListener("keydown", e => {
  if(e.key === "Escape" && stage.classList.contains("solo")){
    stage.classList.remove("solo");
    document.getElementById("btnSolo").textContent = T().solo;
  }
  if(e.key === " " && e.target === document.body){ e.preventDefault(); setPlay(!playing); }
});

const roT=document.getElementById("roT"), roFr=document.getElementById("roFr"),
      roG=document.getElementById("roG"), roC=document.getElementById("roC"),
      roB=document.getElementById("roB"), roF=document.getElementById("roF"), roPl=document.getElementById("roPl");

Object.assign(P, CLIPS[clipId].preset);
syncAll();
video.src = CLIPS[clipId].ref;
resize();
requestAnimationFrame(frame);
window.HexMotion = {params:P, frag:FRAG, gl, canvas:cv, set(o){ Object.assign(P,o); syncAll(); }};
})();
