(function(){
"use strict";
/* Hexagon Motion Lab — engine and UI. Loads after clips.js, i18n.js and shaders.js. */

/* ============================================================
   Language
   ============================================================ */
const STR = window.HML_STR;
let lang = "zh";
try{ const s = localStorage.getItem("hml_lang"); if(s === "en" || s === "zh") lang = s; }catch(e){}
const T = () => STR[lang];

/* ============================================================
   Shader
   ============================================================ */
const {VERT, FRAG, PFRAG} = window.HML_SHADERS;

/* ============================================================
   Parameters
   ============================================================ */
const P = {
  useField:1, seamless:1, speed:1.00, hold:0.45,
  peakFrame:108, dwell:0.60, dwellWidth:14, peakLift:0.00, sustain:0, fade:0,
  loopIn:20, loopOut:265, xfade:40,
  density:96, dotMax:1.08, spot:0, feather:0.40,
  shapeMode:0, size:1.00, hourglass:1, tileGap:0.86, opacity:1,
  bg:"#000000", ground:"#000000", inkA:"#db0011", inkB:"#ff4a3d", duo:0,
  hover:1, pMode:4, pRadius:0.75, pStrength:0.85, pInertia:0.14, pMirror:0,
  contrast:1.00, bias:0.00, gamma:1.00, jitter:0.00, scatter:0.00,
  flicker:0.000, flickRate:3.60, centreDip:0.00,
  gridAngle:0, soft:0.00, stagger:0, invert:0,
  freq:0.55, layers:4, flowAngle:0, swirl:0, mirrorX:1, mirrorY:1, kaleido:0,
  noiseMix:0.34, noiseScale:0.95, noiseDrift:0.22, breathAmt:0.24, breathPer:4.30
};

const isOrig = () => !!P.useField;
const SCHEMA = [
 {id:"gBasics", open:true, note:()=> isOrig() ? (STR[lang]["noteOrig"+clipId] ? "noteOrig"+clipId : "noteOrigAny") : "noteProc", items:[
   {k:"speed",   t:"range", min:0, max:3, step:.01, fmt:v=>v.toFixed(2)+"×", when:()=>!compareOn, why:"offCmp"},
   {k:"timeline", t:"timeline", when:()=>isOrig(), why:"offOrig"},
   {k:"hold",     t:"range", min:0, max:1, step:.01, fmt:v=>v===0?"off":"×"+(1+4*v).toFixed(1), hint:"hHold", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"seamless", t:"toggle", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"loopIn",   t:"range", min:0, max:300, step:1, fmt:v=>String(v), when:()=>isOrig()&&!!P.seamless&&!compareOn, why:()=>compareOn?"offCmp":(isOrig()?"offSeam":"offOrig")},
   {k:"loopOut",  t:"range", min:1, max:301, step:1, fmt:v=>String(v), when:()=>isOrig()&&!!P.seamless&&!compareOn, why:()=>compareOn?"offCmp":(isOrig()?"offSeam":"offOrig")},
   {k:"xfade",    t:"range", min:0, max:90, step:1, fmt:v=>v+"f / "+(v/30).toFixed(2)+"s", hint:"hXfade", when:()=>isOrig()&&!!P.seamless&&!compareOn, why:()=>compareOn?"offCmp":(isOrig()?"offSeam":"offOrig")},
   {k:"density", t:"range", min:12, max:260, step:1, fmt:v=>v+"", hint:"hDensity"},
   {k:"dotMax",  t:"range", min:.2, max:1.4, step:.01, fmt:v=>v.toFixed(2)},
   {k:"spot",    t:"seg", opts:"spotOpts", hint:"hSpot"},
   {k:"feather", t:"range", min:0, max:6, step:.05, fmt:v=>v.toFixed(2), hint:"hFeather", when:()=>P.shapeMode!==2, why:"offBleed"}
 ]},
 {id:"gPeak", open:true, note:()=>"notePeak", items:[
   {k:"sustain",    t:"range", min:0, max:220, step:1, fmt:v=>v?v+"f / "+(v/30).toFixed(2)+"s":"off", hint:"hSustain", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"fade",       t:"range", min:0, max:220, step:1, fmt:v=>v?v+"f / "+(v/30).toFixed(2)+"s":"instant", hint:"hFade", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"peakFrame",  t:"range", min:0, max:300, step:1, fmt:v=>String(v), hint:"hPeakFrame", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"dwell",      t:"range", min:0, max:4, step:.05, fmt:v=>v?v.toFixed(2)+"s":"off", hint:"hDwell", when:()=>isOrig()&&!compareOn, why:()=>compareOn?"offCmp":"offOrig"},
   {k:"dwellWidth", t:"range", min:3, max:60, step:1, fmt:v=>v+"f", when:()=>isOrig()&&!compareOn&&P.dwell>0, why:()=>compareOn?"offCmp":(isOrig()?"offDwell":"offOrig")},
   {k:"peakLift",   t:"range", min:0, max:.6, step:.01, fmt:v=>v?"+"+v.toFixed(2):"off", hint:"hPeakLift", when:()=>isOrig(), why:"offOrig"}
 ]},
 {id:"gFrame", open:true, items:[
   {k:"mode",    t:"seg", opts:"modeOpts", key:"shapeMode", hint:"hMode"},
   {k:"size",    t:"range", min:.2, max:3, step:.01, fmt:v=>Math.round(v*100)+"%"},
   {k:"hourglass", t:"toggle", when:()=>P.shapeMode!==2, why:"offBleed"},
   {k:"tileGap", t:"range", min:.4, max:1, step:.01, fmt:v=>v.toFixed(2), when:()=>P.shapeMode===3, why:"offHoney"},
   {k:"opacity", t:"range", min:0, max:1, step:.01, fmt:v=>Math.round(v*100)+"%", when:()=>P.shapeMode!==2, why:"offBleed"}
 ]},
 {id:"gColour", open:true, items:[
   {k:"bg",     t:"color"},
   {k:"ground", t:"color"},
   {k:"inkA",   t:"color"},
   {k:"duo",    t:"range", min:0, max:1, step:.01, fmt:v=>Math.round(v*100)+"%"},
   {k:"inkB",   t:"color", when:()=>P.duo>0.001, why:"offDuo"}
 ]},
 {id:"gPointer", open:true, items:[
   {k:"hover",     t:"toggle"},
   {k:"pMode",     t:"seg", opts:"pOpts", hint:"hPMode", when:()=>!!P.hover, why:"offHover"},
   {k:"pRadius",   t:"range", min:.15, max:2.5, step:.01, fmt:v=>v.toFixed(2), when:()=>!!P.hover, why:"offHover"},
   {k:"pStrength", t:"range", min:0, max:2, step:.01, fmt:v=>v.toFixed(2), when:()=>!!P.hover, why:"offHover"},
   {k:"pInertia",  t:"range", min:.02, max:.6, step:.01, fmt:v=>v.toFixed(2), when:()=>!!P.hover, why:"offHover"},
   {k:"pMirror",   t:"toggle", when:()=>!!P.hover, why:"offHover"}
 ]},
 {id:"gTone", open:false, items:[
   {k:"contrast",  t:"range", min:.3, max:5, step:.01, fmt:v=>v.toFixed(2)},
   {k:"bias",      t:"range", min:-.6, max:.6, step:.01, fmt:v=>(v>0?"+":"")+v.toFixed(2)},
   {k:"gamma",     t:"range", min:.3, max:3, step:.01, fmt:v=>v.toFixed(2)},
   {k:"flicker",   t:"range", min:0, max:.25, step:.001, fmt:v=>v.toFixed(3), hint:"hFlicker"},
   {k:"flickRate", t:"range", min:.2, max:14, step:.1, fmt:v=>v.toFixed(1), when:()=>P.flicker>0.0001, why:"offFlick"},
   {k:"centreDip", t:"range", min:0, max:.8, step:.01, fmt:v=>v.toFixed(2), hint:"hCentre"},
   {k:"jitter",    t:"range", min:0, max:.5, step:.01, fmt:v=>v.toFixed(2)},
   {k:"scatter",   t:"range", min:0, max:3, step:.01, fmt:v=>v.toFixed(2)+"s", hint:"hScatter"},
   {k:"gridAngle", t:"range", min:-.7854, max:.7854, step:.005, fmt:v=>(v*57.2958).toFixed(1)+"°"},
   {k:"soft",      t:"range", min:0, max:.4, step:.005, fmt:v=>v.toFixed(3)},
   {k:"stagger",   t:"toggle"},
   {k:"invert",    t:"toggle"}
 ]},
 {id:"gMotion", open:false, note:()=>"noteMotion", items:[
   {k:"freq",      t:"range", min:.15, max:2.2, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig(), why:"offProc"},
   {k:"layers",    t:"range", min:1, max:5, step:1, fmt:v=>String(v), when:()=>!isOrig(), why:"offProc"},
   {k:"flowAngle", t:"range", min:-3.1416, max:3.1416, step:.01, fmt:v=>Math.round(v*57.2958)+"°", when:()=>!isOrig(), why:"offProc"},
   {k:"swirl",     t:"range", min:-1.5, max:1.5, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig(), why:"offProc"},
   {k:"mirrorX",   t:"toggle", when:()=>!isOrig(), why:"offProc"},
   {k:"mirrorY",   t:"toggle", when:()=>!isOrig(), why:"offProc"},
   {k:"kaleido",   t:"toggle", when:()=>!isOrig(), why:"offProc"},
   {k:"noiseMix",  t:"range", min:0, max:1, step:.01, fmt:v=>Math.round(v*100)+"%", when:()=>!isOrig(), why:"offProc"},
   {k:"noiseScale",t:"range", min:.2, max:4, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig()&&P.noiseMix>.001, why:()=>isOrig()?"offProc":"offNoise"},
   {k:"noiseDrift",t:"range", min:0, max:1.5, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig()&&P.noiseMix>.001, why:()=>isOrig()?"offProc":"offNoise"},
   {k:"breathAmt", t:"range", min:0, max:.6, step:.01, fmt:v=>v.toFixed(2), when:()=>!isOrig(), why:"offProc"},
   {k:"breathPer", t:"range", min:1, max:14, step:.1, fmt:v=>v.toFixed(1)+"s", when:()=>!isOrig(), why:"offProc"}
 ]}
];

/* ============================================================
   GL
   ============================================================ */
const cv = document.getElementById("gl");
const gl = cv.getContext("webgl2", {antialias:false, alpha:false, powerPreference:"high-performance"});
if(!gl){
  document.getElementById("stage").innerHTML =
    '<p style="margin:auto;padding:24px;color:#aaa;max-width:40ch;text-align:center">WebGL2 required.</p>';
  return;
}
function compile(type, src){
  const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
  if(!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}
const prog = gl.createProgram();
gl.attachShader(prog, compile(gl.VERTEX_SHADER, VERT));
gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FRAG));
gl.bindAttribLocation(prog, 0, "aPos");
gl.linkProgram(prog);
if(!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
gl.useProgram(prog);
gl.bindVertexArray(gl.createVertexArray());
gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,3,-1,-1,3]), gl.STATIC_DRAW);
gl.enableVertexAttribArray(0);
gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

function makeProgram(fs){
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl.VERTEX_SHADER, VERT));
  gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fs));
  gl.bindAttribLocation(p, 0, "aPos");
  gl.linkProgram(p);
  if(!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  return p;
}
const pProg = makeProgram(PFRAG);
const PU = {};
("uField uPrev uPSize uFrame uFrames uCols uXfade uLoop uTileIn uSheet uStep uHold uRelease uInit")
  .split(" ").forEach(n => PU[n] = gl.getUniformLocation(pProg, n));

const HAS_FLOAT = !!gl.getExtension("EXT_color_buffer_float");
const pFbo = gl.createFramebuffer();
let pTex = [null, null], pIdx = 0, pSize = [1,1], pInit = true;
function allocPersist(w, h){
  if(pSize[0] === w && pSize[1] === h && pTex[0]) return;
  pSize = [w, h];
  [0,1].forEach(i => {
    if(pTex[i]) gl.deleteTexture(pTex[i]);
    const t = gl.createTexture();
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, t);
    if(HAS_FLOAT) gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,w,h,0,gl.RGBA,gl.HALF_FLOAT,null);
    else          gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,w,h,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    pTex[i] = t;
  });
  pInit = true;
}

const U = {};
("uCenter uUnit uTime uField uUseField uFrame uFrames uCols uTileIn uSheet uXfade uLoop uShapeMode uHourglass " +
 "uTileGap uFeather uMirror uKaleido uLayers uFreq uFlowAngle uSwirl uNoiseMix uNoiseScale uNoiseDrift uContrast " +
 "uBias uBreathAmt uBreathPer uGamma uCell uDotMax uJitter uScatter uStagger uGridAngle uSoft uInvert uSpot " +
 "uInkA uInkB uGroundC uBg uDuo uOpacity uPointer uPVel uPEnergy uPRadius uPStrength uPMirror uPMode uReveal uFlicker uFlickRate uCentreDip uPersist uUsePersist")
 .split(" ").forEach(n => U[n] = gl.getUniformLocation(prog, n));

/* Clips come from clips/clips.js (window.HML_CLIPS). Each entry carries its field
   sheet, reference video, envelope and the screen preset it was drawn with.
   tools/add_clip.py writes new entries; nothing in this file names a clip. */
const CLIPS = window.HML_CLIPS;
let clipId = Object.keys(CLIPS)[0];
const SHEET = () => CLIPS[clipId];
gl.uniform1i(U.uField, 0);
gl.activeTexture(gl.TEXTURE0);
gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
const textures = {};
Object.keys(CLIPS).forEach(k => {
  const t = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 1, 1, 0, gl.RED, gl.UNSIGNED_BYTE, new Uint8Array([0]));
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  textures[k] = {tex:t, ready:false};
  const img = new Image();
  img.decoding = "async";
  img.onload = () => {
    try{
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, gl.RED, gl.UNSIGNED_BYTE, img);
      textures[k].ready = true;
      gl.bindTexture(gl.TEXTURE_2D, textures[clipId].tex);
    }catch(err){
      /* a page opened from file:// cannot hand its images to WebGL */
      console.error(err);
      setTimeout(() => toast(T().fileProto), 400);
    }
  };
  img.src = CLIPS[k].field;
});
const fieldReady = () => textures[clipId].ready;

const hex2rgb = h => { const n = parseInt(h.slice(1),16); return [((n>>16)&255)/255,((n>>8)&255)/255,(n&255)/255]; };

/* ============================================================
   State
   ============================================================ */
let W=1, H=1, dpr=1, time=0, phase=0, dPhase=0, rateNow=1, playing=true, reveal=1, revealing=false;

/* ENV[clip][frame] = that frame's ink, normalised to the clip's own peak.
   It is what the playhead rides: a fuller frame is played slower. */
const ENV = Object.fromEntries(Object.keys(CLIPS).map(k => [k, CLIPS[k].env]));
function loopSpan(){
  const S = SHEET();
  if(!P.seamless) return {lo:0, xf:0, L:S.frames};
  const lo = Math.max(0, Math.min(P.loopIn, P.loopOut-2));
  const xf = Math.max(0, Math.min(P.xfade, (P.loopOut-lo)-1));
  return {lo, xf, L:Math.max(1, P.loopOut - lo - xf)};
}
/* real seconds one loop takes, with the hold curve integrated in */
function loopSeconds(){
  const S = SHEET(), sp = loopSpan();
  let f = 0;
  for(let i=0;i<sp.L;i++) f += slowAt(sp.lo + sp.xf + i);
  return f / S.fps / Math.max(P.speed, 0.01);
}
function fullnessAt(absFrame){
  const e = ENV[clipId];
  const i = Math.max(0, Math.min(e.length-1, Math.round(absFrame)));
  return e[i];
}
/* Gaussian centred on the peak frame, wrapped into the loop */
function peakG(absFrame){
  if(P.dwell <= 0 && P.peakLift <= 0) return 0;
  const L = loopSpan().L;
  let d = absFrame - P.peakFrame;
  d = ((d % L) + L*1.5) % L - L/2;
  const w = Math.max(1, P.dwellWidth);
  return Math.exp(-(d*d)/(w*w));
}
/* dwell depth chosen so the pause lasts exactly P.dwell seconds */
function dwellDepth(){
  const w = Math.max(1, P.dwellWidth);
  return P.dwell > 0 ? (P.dwell*SHEET().fps)/(w*Math.sqrt(Math.PI)) : 0;
}
function slowAt(absFrame){
  return 1 + P.hold*4*fullnessAt(absFrame) + dwellDepth()*peakG(absFrame);
}
let last=performance.now(), fpsAcc=0, fpsN=0, compareOn=false;
const ptr = {tx:0,ty:0,x:0,y:0,vx:0,vy:0,energy:0,inside:false};
const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
const video = document.getElementById("ref");

function resize(){
  const r = cv.getBoundingClientRect();
  dpr = Math.min(window.devicePixelRatio||1, 2);
  const w = Math.max(1,Math.round(r.width*dpr)), h = Math.max(1,Math.round(r.height*dpr));
  if(w!==W||h!==H){ W=w; H=h; cv.width=W; cv.height=H; gl.viewport(0,0,W,H); }
}
new ResizeObserver(resize).observe(cv);

/* The source frames the hexagon at 60.5% of picture width / 53.8% of picture height.
   min(W*0.15125, H*0.269) reproduces exactly that inside an object-fit:contain 16:9 box,
   so the rebuild and the reference video land on the same pixels in Compare. */
function unitPx(){
  if(P.shapeMode===0) return Math.min(W*0.15125, H*0.269)*P.size;
  if(P.shapeMode===1) return Math.max(W*0.25, H*0.5)*P.size;
  return Math.min(W,H)*0.5*P.size;
}

function frame(now){
  const dt = Math.min(0.1,(now-last)/1000); last = now;
  fpsAcc += dt; fpsN++;
  if(fpsAcc>0.5){ roF.textContent = Math.round(fpsN/fpsAcc); fpsAcc=0; fpsN=0; }

  dPhase = 0;
  if(compareOn && !video.paused){
    time = video.currentTime; phase = time*SHEET().fps; rateNow = 1;
  }else if(playing){
    const sp0 = loopSpan();
    const tt = ((phase % sp0.L) + sp0.L) % sp0.L;
    rateNow = 1/slowAt(sp0.lo + sp0.xf + tt);
    dPhase = dt*P.speed*SHEET().fps*rateNow;
    phase += dPhase;
    time  += dt*P.speed*rateNow;
  }
  if(revealing){ reveal = Math.min(1, reveal+dt/1.15); if(reveal>=1) revealing = false; }

  const k = 1-Math.pow(1-P.pInertia, dt*60);
  const ox=ptr.x, oy=ptr.y;
  ptr.x += (ptr.tx-ptr.x)*k; ptr.y += (ptr.ty-ptr.y)*k;
  if(dt>0){
    ptr.vx += (((ptr.x-ox)/dt)*0.09-ptr.vx)*Math.min(1,dt*6);
    ptr.vy += (((ptr.y-oy)/dt)*0.09-ptr.vy)*Math.min(1,dt*6);
  }
  const want = (P.hover && ptr.inside)?1:0;
  ptr.energy += (want-ptr.energy)*Math.min(1, dt*(want?4.5:2.6));

  resize();
  const S = SHEET(), sp = loopSpan();
  const unit = unitPx(), cell = 2/Math.max(2,P.density);
  const fi = compareOn ? time*S.fps : phase;
  const persistOn = (P.useField && !compareOn && (P.sustain > 0 || P.fade > 0) && fieldReady());

  if(persistOn){
    allocPersist(S.inner[0], S.inner[1]);
    gl.useProgram(pProg);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, textures[clipId].tex);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, pTex[pIdx]);
    gl.uniform1i(PU.uField, 0); gl.uniform1i(PU.uPrev, 1);
    gl.uniform2f(PU.uPSize, pSize[0], pSize[1]);
    gl.uniform1f(PU.uFrame, fi);
    gl.uniform1f(PU.uFrames, S.frames);
    gl.uniform1f(PU.uCols, S.cols);
    gl.uniform1f(PU.uXfade, sp.xf);
    gl.uniform2f(PU.uLoop, sp.lo, sp.lo + sp.xf + sp.L);
    gl.uniform2f(PU.uTileIn, S.inner[0], S.inner[1]);
    gl.uniform2f(PU.uSheet, S.size[0], S.size[1]);
    gl.uniform1f(PU.uStep, dPhase);
    gl.uniform1f(PU.uHold, P.sustain);
    gl.uniform1f(PU.uRelease, P.fade);
    gl.uniform1f(PU.uInit, pInit ? 1 : 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, pFbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, pTex[1-pIdx], 0);
    gl.viewport(0, 0, pSize[0], pSize[1]);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, W, H);
    pIdx = 1 - pIdx; pInit = false;
    gl.useProgram(prog);
  }else{
    pInit = true;
  }
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, textures[clipId].tex);
  gl.uniform1i(U.uField, 0);
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, pTex[pIdx] || textures[clipId].tex);
  gl.uniform1i(U.uPersist, 1);
  gl.uniform1f(U.uUsePersist, persistOn ? 1 : 0);

  gl.uniform2f(U.uCenter, W/2, H/2);
  gl.uniform1f(U.uUnit, unit);
  gl.uniform1f(U.uTime, time);
  gl.uniform1f(U.uUseField, (P.useField && fieldReady())?1:0);
  gl.uniform1f(U.uFrame, fi);
  gl.uniform1f(U.uFrames, S.frames);
  gl.uniform1f(U.uCols, S.cols);
  gl.uniform2f(U.uTileIn, S.inner[0], S.inner[1]);
  gl.uniform2f(U.uSheet, S.size[0], S.size[1]);
  gl.uniform1f(U.uXfade, compareOn ? 0 : sp.xf);
  gl.uniform2f(U.uLoop, compareOn ? 0 : sp.lo, compareOn ? S.frames : (sp.lo+sp.xf+sp.L));
  gl.uniform1i(U.uShapeMode, P.shapeMode|0);
  gl.uniform1f(U.uHourglass, P.hourglass?1:0);
  gl.uniform1f(U.uTileGap, P.tileGap);
  gl.uniform1f(U.uFeather, P.feather);
  gl.uniform2f(U.uMirror, P.mirrorX?1:0, P.mirrorY?1:0);
  gl.uniform1f(U.uKaleido, P.kaleido?1:0);
  gl.uniform1f(U.uLayers, P.layers);
  gl.uniform1f(U.uFreq, P.freq);
  gl.uniform1f(U.uFlowAngle, P.flowAngle);
  gl.uniform1f(U.uSwirl, P.swirl);
  gl.uniform1f(U.uNoiseMix, P.noiseMix);
  gl.uniform1f(U.uNoiseScale, P.noiseScale);
  gl.uniform1f(U.uNoiseDrift, P.noiseDrift);
  gl.uniform1f(U.uContrast, P.contrast);
  gl.uniform1f(U.uBias, P.bias + P.peakLift*peakG(sp.lo + sp.xf + (((phase%sp.L)+sp.L)%sp.L)));
  gl.uniform1f(U.uBreathAmt, P.breathAmt);
  gl.uniform1f(U.uBreathPer, P.breathPer);
  gl.uniform1f(U.uGamma, P.gamma);
  gl.uniform1f(U.uCell, cell);
  gl.uniform1f(U.uDotMax, P.dotMax);
  gl.uniform1f(U.uJitter, P.jitter);
  gl.uniform1f(U.uScatter, P.scatter);
  gl.uniform1f(U.uStagger, P.stagger?1:0);
  gl.uniform1f(U.uGridAngle, P.gridAngle);
  gl.uniform1f(U.uSoft, P.soft);
  gl.uniform1f(U.uInvert, P.invert?1:0);
  gl.uniform1i(U.uSpot, P.spot|0);
  gl.uniform3fv(U.uInkA, hex2rgb(P.inkA));
  gl.uniform3fv(U.uInkB, hex2rgb(P.inkB));
  gl.uniform3fv(U.uGroundC, hex2rgb(P.ground));
  gl.uniform3fv(U.uBg, hex2rgb(P.bg));
  gl.uniform1f(U.uDuo, P.duo);
  gl.uniform1f(U.uOpacity, P.opacity);
  gl.uniform2f(U.uPointer, ptr.x, ptr.y);
  gl.uniform2f(U.uPVel, ptr.vx, ptr.vy);
  gl.uniform1f(U.uPEnergy, ptr.energy);
  gl.uniform1f(U.uPRadius, P.pRadius);
  gl.uniform1f(U.uPStrength, P.pStrength);
  gl.uniform1f(U.uPMirror, P.pMirror?1:0);
  gl.uniform1i(U.uPMode, P.pMode|0);
  gl.uniform1f(U.uReveal, P.useField?1:reveal);
  gl.uniform1f(U.uFlicker, P.flicker);
  gl.uniform1f(U.uFlickRate, P.flickRate);
  gl.uniform1f(U.uCentreDip, P.centreDip);

  gl.drawArrays(gl.TRIANGLES, 0, 3);

  roT.textContent = loopSeconds().toFixed(2);
  roFr.textContent = String(Math.round(sp.lo+sp.xf+(((phase%sp.L)+sp.L)%sp.L)));
  roB.textContent = "×"+(1/Math.max(rateNow,1e-3)).toFixed(2);
  drawTimeline();
  roG.textContent = P.density;
  roC.textContent = (cell*unit/dpr).toFixed(1)+"px";
  requestAnimationFrame(frame);
}

function toHex(e){
  const r = cv.getBoundingClientRect(), unit = unitPx();
  return [((e.clientX-r.left)*dpr-W/2)/unit, (H/2-(e.clientY-r.top)*dpr)/unit];
}
cv.addEventListener("pointermove", e => { const q=toHex(e); ptr.tx=q[0]; ptr.ty=q[1]; ptr.inside=true; });
cv.addEventListener("pointerenter", e => { const q=toHex(e); if(ptr.energy<0.01){ptr.x=q[0];ptr.y=q[1];} ptr.tx=q[0]; ptr.ty=q[1]; ptr.inside=true; });
cv.addEventListener("pointerleave", () => { ptr.inside=false; });
cv.addEventListener("pointerdown", e => { cv.setPointerCapture(e.pointerId); ptr.inside=true; });

/* ============================================================
   UI
   ============================================================ */
const rail = document.getElementById("rail");
const rows = [];           // {it, key, wrap, sync, setLang}
const groups = [];
let tlCanvas = null, tlCtx = null;

function autoLoop(){
  const e = ENV[clipId], n = e.length;
  let lo = 0, hi = n-1;
  while(lo < n-1 && e[lo] < 0.12) lo++;
  while(hi > 0   && e[hi] < 0.12) hi--;
  P.loopIn = lo; P.loopOut = hi;
  P.xfade = Math.max(4, Math.min(40, Math.round((hi-lo)/6)));
  P.seamless = 1; phase = 0; syncAll();
}

function drawTimeline(){
  if(!tlCanvas || !tlCtx) return;
  const e = ENV[clipId], n = e.length;
  const r = tlCanvas.getBoundingClientRect();
  if(r.width < 4) return;
  const w = Math.round(r.width*dpr), h = Math.round(r.height*dpr);
  if(tlCanvas.width !== w || tlCanvas.height !== h){ tlCanvas.width = w; tlCanvas.height = h; }
  const cs = getComputedStyle(document.documentElement);
  let acc = cs.getPropertyValue("--accent").trim();
  if(!/^#[0-9a-f]{6}$/i.test(acc)) acc = "#db0011";
  const tlDim  = cs.getPropertyValue("--tl-dim").trim()  || "rgba(0,0,0,.5)";
  const tlMark = cs.getPropertyValue("--tl-mark").trim() || "#888";
  const tlPeak = cs.getPropertyValue("--tl-peak").trim() || "#fff";
  const c = tlCtx, pad = 3*dpr, gh = h-2*pad, X = i => pad + (Math.max(0,Math.min(n-1,i))/(n-1))*(w-2*pad);
  c.clearRect(0,0,w,h);

  c.beginPath(); c.moveTo(X(0), h-pad);
  for(let i=0;i<n;i++) c.lineTo(X(i), h-pad-e[i]*gh);
  c.lineTo(X(n-1), h-pad); c.closePath();
  c.fillStyle = "rgba(128,136,146,0.42)"; c.fill();

  if(P.hold > 0.001 || P.dwell > 0.001){
    c.beginPath();
    for(let i=0;i<n;i++){
      const y = h-pad-(1/slowAt(i))*gh;
      i ? c.lineTo(X(i),y) : c.moveTo(X(i),y);
    }
    c.strokeStyle = acc; c.lineWidth = 1.4*dpr;
    c.setLineDash([3*dpr,3*dpr]); c.stroke(); c.setLineDash([]);
  }

  const sp = loopSpan();
  if(P.seamless){
    const a = X(sp.lo), b = X(sp.lo+sp.xf+sp.L);
    c.fillStyle = tlDim; c.fillRect(0,0,a,h); c.fillRect(b,0,w-b,h);
    c.fillStyle = acc+"2e";
    c.fillRect(a,0,X(sp.lo+sp.xf)-a,h);
    c.fillRect(X(sp.lo+sp.L),0,b-X(sp.lo+sp.L),h);
    c.fillStyle = tlMark;
    c.fillRect(a-dpr,0,2*dpr,h); c.fillRect(b-dpr,0,2*dpr,h);
  }
  if(P.dwell > 0.001 || P.peakLift > 0.001){
    c.fillStyle = tlPeak;
    const pw = Math.max(2*dpr, X(P.peakFrame+P.dwellWidth)-X(P.peakFrame-P.dwellWidth));
    c.fillRect(X(P.peakFrame)-pw/2, h-3*dpr, pw, 3*dpr);
    c.fillRect(X(P.peakFrame)-dpr*0.75, 0, 1.5*dpr, h);
  }
  const tt = ((phase % sp.L)+sp.L)%sp.L;
  c.fillStyle = acc; c.fillRect(X(sp.lo+sp.xf+tt)-dpr, 0, 2*dpr, h);
}

function build(){
  rail.textContent = "";
  rows.length = 0; groups.length = 0;
  SCHEMA.forEach(g => {
    const d = document.createElement("details");
    d.className = "grp"; d.open = g.open;
    const s = document.createElement("summary"); d.appendChild(s);
    const body = document.createElement("div"); body.className = "grp-body";
    let noteEl = null;
    if(g.note){ noteEl = document.createElement("p"); noteEl.className = "grpnote"; body.appendChild(noteEl); }
    g.items.forEach(it => body.appendChild(makeCtl(it)));
    d.appendChild(body); rail.appendChild(d);
    groups.push({g, s, noteEl});
  });
  const act = document.createElement("div");
  act.className = "grp-body"; act.style.paddingTop = "16px";
  act.innerHTML = '<div class="rowbtns"><button class="btn" id="btnReset"></button>'+
    '<button class="btn" id="btnShader"></button></div><p class="hint" id="foot"></p>';
  rail.appendChild(act);
  document.getElementById("btnReset").addEventListener("click", () => {
    Object.assign(P, DEFAULTS, CLIPS[clipId].preset);
    Object.assign(P, STAGE[effectiveTheme()]);
    syncAll(); applyLang(); stageFollowTheme();
  });
  document.getElementById("btnShader").addEventListener("click", () => copy(FRAG, "GLSL"));
}

function makeCtl(it){
  const key = it.key || it.k;
  const wrap = document.createElement("div"); wrap.className = "ctl";
  const id = "c_" + key;
  let setLang = () => {};

  if(it.t === "range"){
    wrap.innerHTML = '<div class="lab"><label for="'+id+'"><span></span></label><output></output></div>'+
      '<input type="range" id="'+id+'" min="'+it.min+'" max="'+it.max+'" step="'+it.step+'">';
    const inp = wrap.querySelector("input"), out = wrap.querySelector("output"), lb = wrap.querySelector("span");
    const sync = () => { inp.value = P[key]; out.textContent = it.fmt(+P[key]); };
    inp.addEventListener("input", () => { P[key] = +inp.value; out.textContent = it.fmt(+inp.value); refreshCtx(); });
    setLang = () => { lb.textContent = T()[it.k] || it.k; };
    rows.push({it, key, wrap, sync, setLang});
  }
  else if(it.t === "toggle"){
    wrap.innerHTML = '<div class="sw"><span></span><button class="tog" id="'+id+'" role="switch"></button></div>';
    const b = wrap.querySelector("button"), lb = wrap.querySelector("span");
    const sync = () => b.setAttribute("aria-pressed", P[key] ? "true" : "false");
    b.addEventListener("click", () => { P[key] = P[key] ? 0 : 1; sync(); refreshCtx(); });
    setLang = () => { lb.textContent = T()[it.k] || it.k; };
    rows.push({it, key, wrap, sync, setLang});
  }
  else if(it.t === "seg"){
    wrap.innerHTML = '<div class="lab"><span></span></div><div class="segs"></div>';
    const box = wrap.querySelector(".segs"), lb = wrap.querySelector("span");
    const n = Array.isArray(it.opts) ? it.opts.length : T()[it.opts].length;
    const btns = [];
    for(let i=0;i<n;i++){
      const b = document.createElement("button");
      b.className = "seg"; b.dataset.v = i;
      b.addEventListener("click", () => { P[key] = i; sync(); refreshCtx(); });
      box.appendChild(b); btns.push(b);
    }
    const sync = () => btns.forEach(b => b.setAttribute("aria-pressed", (+b.dataset.v === +P[key]) ? "true":"false"));
    setLang = () => {
      lb.textContent = T()[it.k] || it.k;
      const names = Array.isArray(it.opts) ? it.opts.map(o => T()[o] || o) : T()[it.opts];
      btns.forEach((b,i) => b.textContent = names[i]);
    };
    rows.push({it, key, wrap, sync, setLang});
  }
  else if(it.t === "timeline"){
    wrap.innerHTML = '<div class="lab tlrow"><span></span><button type="button" class="tlauto"></button></div>'+
      '<canvas class="tl"></canvas>';
    const lb = wrap.querySelector("span"), btn = wrap.querySelector(".tlauto");
    tlCanvas = wrap.querySelector("canvas"); tlCtx = tlCanvas.getContext("2d");
    btn.addEventListener("click", autoLoop);
    tlCanvas.addEventListener("pointerdown", e => {
      tlCanvas.setPointerCapture(e.pointerId);
      const n = CLIPS[clipId].frames;
      const pick = ev => {
        const rc = tlCanvas.getBoundingClientRect();
        return Math.max(0, Math.min(n, Math.round(((ev.clientX-rc.left)/rc.width)*(n-1))));
      };
      const f0 = pick(e);
      const grab = Math.abs(f0-P.loopIn) < Math.abs(f0-P.loopOut) ? "loopIn" : "loopOut";
      const move = ev => {
        const fr = pick(ev);
        if(grab === "loopIn") P.loopIn = Math.min(fr, P.loopOut-4);
        else                  P.loopOut = Math.max(fr, P.loopIn+4);
        P.seamless = 1; syncAll();
      };
      move(e);
      const up = () => { window.removeEventListener("pointermove",move); window.removeEventListener("pointerup",up); };
      window.addEventListener("pointermove",move); window.addEventListener("pointerup",up);
      e.preventDefault();
    });
    const sync = () => {};
    setLang = () => { lb.textContent = T()[it.k] || it.k; btn.textContent = T().auto; };
    rows.push({it, key:it.k, wrap, sync, setLang});
  }
  else if(it.t === "color"){
    wrap.innerHTML = '<div class="lab"><label for="'+id+'"><span></span></label></div>'+
      '<div class="colorrow"><input type="color" id="'+id+'"><code></code></div>';
    const inp = wrap.querySelector("input"), code = wrap.querySelector("code"), lb = wrap.querySelector("span");
    const sync = () => { inp.value = P[key]; code.textContent = P[key]; };
    inp.addEventListener("input", () => { P[key] = inp.value; code.textContent = inp.value; refreshCtx(); });
    setLang = () => { lb.textContent = T()[it.k] || it.k; };
    rows.push({it, key, wrap, sync, setLang});
  }

  const hintEl = document.createElement("p"); hintEl.className = "hint"; wrap.appendChild(hintEl);
  const whyEl = document.createElement("p"); whyEl.className = "why"; wrap.appendChild(whyEl);
  const r = rows[rows.length-1];
  r.hintEl = hintEl; r.whyEl = whyEl;
  const base = r.setLang;
  r.setLang = () => { base(); hintEl.textContent = it.hint ? (T()[it.hint]||"") : ""; hintEl.hidden = !it.hint; };
  r.sync();
  return wrap;
}

function refreshCtx(){
  rows.forEach(r => {
    const ok = r.it.when ? !!r.it.when() : true;
    r.wrap.classList.toggle("off", !ok);
    if(!ok){
      const w = typeof r.it.why === "function" ? r.it.why() : r.it.why;
      r.whyEl.textContent = w ? (T()[w] || "") : "";
    }
  });
  groups.forEach(o => { if(o.noteEl) o.noteEl.textContent = T()[o.g.note()] || ""; });
}
const syncAll = () => { rows.forEach(r => r.sync()); refreshCtx(); };

function applyLang(){
  const t = T();
  document.getElementById("ttl").textContent = t.title;
  document.getElementById("sub").textContent = t.sub;
  document.getElementById("mOrig").textContent = t.orig;
  document.getElementById("mProc").textContent = t.proc;
  document.getElementById("btnCmp").textContent = t.compare;
  document.getElementById("btnPlay").textContent = playing ? t.play : t.paused;
  document.getElementById("btnReplay").textContent = t.replay;
  document.getElementById("btnSolo").textContent =
    document.getElementById("stage").classList.contains("solo") ? t.exitSolo : t.solo;
  document.getElementById("btnCopy").textContent = t.copy;
  document.getElementById("btnLang").textContent = lang === "zh" ? "EN" : "中文";
  document.getElementById("labL").textContent = t.labL;
  document.getElementById("labR").textContent = t.labR;
  document.getElementById("rlT").firstChild.nodeValue = t.rlT + " ";
  document.getElementById("rlFr").firstChild.nodeValue = t.rlFr + " ";
  document.getElementById("rlG").firstChild.nodeValue = t.rlG + " ";
  document.getElementById("rlC").firstChild.nodeValue = t.rlC + " ";
  document.getElementById("rlB").firstChild.nodeValue = t.rlB + " ";
  document.getElementById("btnReset").textContent = t.reset;
  document.getElementById("btnShader").textContent = t.glsl;
  document.getElementById("foot").textContent = t.hFoot;
  groups.forEach(o => o.s.textContent = t[o.g.id] || o.g.id);
  rows.forEach(r => r.setLang());
  refreshCtx();
  document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
}

const DEFAULTS = Object.assign({}, P);
build(); applyLang(); syncAll();

/* ---------- toolbar ---------- */
const toast = msg => {
  const el = document.getElementById("toast");
  el.textContent = msg; el.classList.add("on");
  clearTimeout(toast._id); toast._id = setTimeout(() => el.classList.remove("on"), 1800);
};
async function copy(text, label){
  try{ await navigator.clipboard.writeText(text); toast(label + " " + T().copied); }
  catch(e){ toast(T().clipFail); }
}
/* header clip switcher, one button per manifest entry */
const clipBox = document.getElementById("clipsw");
Object.keys(CLIPS).forEach(k => {
  const b = document.createElement("button");
  b.type = "button"; b.dataset.clip = k; b.textContent = CLIPS[k].name;
  b.setAttribute("aria-pressed", k === clipId ? "true" : "false");
  b.addEventListener("click", () => setClip(k));
  clipBox.appendChild(b);
});
function setClip(k){
  clipId = k;
  Object.assign(P, CLIPS[k].preset);
  [...clipBox.children].forEach(b => b.setAttribute("aria-pressed", b.dataset.clip === k ? "true" : "false"));
  document.getElementById("sub").textContent = CLIPS[k].name;
  time = 0; phase = 0;
  rows.forEach(r => {
    if(r.key === "loopIn" || r.key === "loopOut" || r.key === "peakFrame"){
      const inp = r.wrap.querySelector("input"); if(inp) inp.max = CLIPS[k].frames;
    }
  });
  video.src = CLIPS[k].ref;
  if(compareOn){ video.currentTime = 0; video.play().catch(()=>{}); }
  syncAll();
}

const setMode = useField => {
  P.useField = useField ? 1 : 0;
  document.getElementById("mOrig").setAttribute("aria-pressed", useField ? "true":"false");
  document.getElementById("mProc").setAttribute("aria-pressed", useField ? "false":"true");
  if(!useField){ reveal = 0; revealing = true; }
  refreshCtx();
};
document.getElementById("mOrig").addEventListener("click", () => setMode(true));
document.getElementById("mProc").addEventListener("click", () => setMode(false));

const btnPlay = document.getElementById("btnPlay");
const setPlay = v => {
  playing = v; btnPlay.textContent = v ? T().play : T().paused;
  if(compareOn){ v ? video.play() : video.pause(); }
};
setPlay(!reduced);
btnPlay.addEventListener("click", () => setPlay(!playing));
document.getElementById("btnReplay").addEventListener("click", () => {
  time = 0; phase = 0; if(compareOn) video.currentTime = 0;
  if(!P.useField){ reveal = 0; revealing = true; }
});
document.getElementById("btnSolo").addEventListener("click", () => {
  const on = document.getElementById("stage").classList.toggle("solo");
  document.getElementById("btnSolo").textContent = on ? T().exitSolo : T().solo;
  requestAnimationFrame(resize);
});
document.getElementById("btnCopy").addEventListener("click", () => copy(JSON.stringify(P,null,2), "Config"));
/* ---------- theme: auto / light / dark, for the chrome and the stage ---------- */
const STAGE = { light:{bg:"#ffffff", ground:"#ffffff"}, dark:{bg:"#000000", ground:"#000000"} };
const root = document.documentElement;
const hostTheme = root.getAttribute("data-theme");       // whatever the page was opened with
const mqDark = matchMedia("(prefers-color-scheme: dark)");
let themeMode = "auto";
try{ const t = localStorage.getItem("hml_theme"); if(t === "light" || t === "dark" || t === "auto") themeMode = t; }catch(e){}
function effectiveTheme(){
  if(themeMode !== "auto") return themeMode;
  const h = root.getAttribute("data-theme");
  if(h === "light" || h === "dark") return h;
  return mqDark.matches ? "dark" : "light";
}
/* swap the stage colours only if they are still the other theme's defaults,
   so a colour you picked by hand survives a theme change */
function stageFollowTheme(){
  const eff = effectiveTheme(), other = eff === "dark" ? "light" : "dark";
  let changed = false;
  ["bg","ground"].forEach(k => {
    if(String(P[k]).toLowerCase() === STAGE[other][k]){ P[k] = STAGE[eff][k]; changed = true; }
  });
  if(changed) syncAll();
  const b = document.getElementById("btnTheme");
  if(b) b.textContent = T()["theme_"+themeMode];
}
function applyTheme(){
  if(themeMode === "auto"){ hostTheme ? root.setAttribute("data-theme", hostTheme) : root.removeAttribute("data-theme"); }
  else root.setAttribute("data-theme", themeMode);
  stageFollowTheme();
}
document.getElementById("btnTheme").addEventListener("click", () => {
  themeMode = themeMode === "auto" ? "light" : themeMode === "light" ? "dark" : "auto";
  try{ localStorage.setItem("hml_theme", themeMode); }catch(e){}
  applyTheme();
});
mqDark.addEventListener("change", () => { if(themeMode === "auto") stageFollowTheme(); });
new MutationObserver(() => { if(themeMode === "auto") stageFollowTheme(); })
  .observe(root, {attributes:true, attributeFilter:["data-theme"]});
applyTheme();

document.getElementById("btnLang").addEventListener("click", () => {
  lang = lang === "zh" ? "en" : "zh";
  try{ localStorage.setItem("hml_lang", lang); }catch(e){}
  build(); applyLang(); syncAll(); stageFollowTheme();
});

/* ---------- compare ---------- */
const stage = document.getElementById("stage"), split = document.getElementById("split");
let splitX = 0.5;
function layoutSplit(){
  split.style.left = (splitX*100) + "%";
  video.style.clipPath = "inset(0 0 0 " + (splitX*100) + "%)";
  document.getElementById("labR").style.opacity = splitX > 0.88 ? "0" : "1";
  document.getElementById("labL").style.opacity = splitX < 0.12 ? "0" : "1";
}
layoutSplit();
document.getElementById("btnCmp").addEventListener("click", e => {
  compareOn = !compareOn;
  e.currentTarget.setAttribute("aria-pressed", compareOn ? "true":"false");
  stage.classList.toggle("cmp", compareOn);
  if(compareOn){
    setMode(true); P.speed = 1; P.loopMode = 0; P.shapeMode = 0; P.size = 1;
    syncAll();
    video.currentTime = 0; video.play().catch(()=>{});
    if(!playing) setPlay(true);
  }else{ video.pause(); }
  refreshCtx();
});
split.addEventListener("pointerdown", e => {
  split.setPointerCapture(e.pointerId);
  const move = ev => {
    const r = stage.getBoundingClientRect();
    splitX = Math.min(1, Math.max(0, (ev.clientX-r.left)/r.width));
    layoutSplit();
  };
  const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); };
  window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  e.preventDefault();
});

document.addEventListener("keydown", e => {
  if(e.key === "Escape" && stage.classList.contains("solo")){
    stage.classList.remove("solo");
    document.getElementById("btnSolo").textContent = T().solo;
  }
  if(e.key === " " && e.target === document.body){ e.preventDefault(); setPlay(!playing); }
});

const roT=document.getElementById("roT"), roFr=document.getElementById("roFr"),
      roG=document.getElementById("roG"), roC=document.getElementById("roC"),
      roB=document.getElementById("roB"), roF=document.getElementById("roF");

Object.assign(P, CLIPS[clipId].preset);
syncAll();
video.src = CLIPS[clipId].ref;
resize();
requestAnimationFrame(frame);
window.HexMotion = {params:P, frag:FRAG, gl, canvas:cv, set(o){ Object.assign(P,o); syncAll(); }};
})();
