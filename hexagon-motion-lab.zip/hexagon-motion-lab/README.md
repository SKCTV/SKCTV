# Hexagon Motion Lab

HSBC Iconic Graphic 六边形动效的可交互复刻。不是视频回放：每支片子被逐帧测量成
"每个网格一个覆盖率值"的场，再由 WebGL 网屏引擎实时绘制——所以密度、网点形状、
颜色、取景、速度、循环、鼠标交互都可以改，而运动本身与原片逐帧一致。

## 目录

```
index.html            开发入口（需要本地服务，见下）
src/styles.css        界面样式；浅色 / 深色 token 都在这里
src/i18n.js           中英文案
src/shaders.js        GLSL：VERT 全屏三角形 / FRAG 网屏渲染 / PFRAG 每格生命周期
src/app.js            引擎与界面
clips/clips.js        片段清单：场、参考视频、墨量包络、默认预设
clips/<name>/         field.jpg（全部帧的场图集）+ ref.mp4（对比用参考视频）
tools/add_clip.py     把一支 mp4 测量成片段并写进清单
tools/build.py        打包成单文件
dist/                 打包结果，双击即可打开
```

## 运行

**直接看**：打开 `dist/hexagon-motion-lab.html`，所有素材都内嵌，不需要服务。

**改代码**：在这个文件夹里起一个本地服务，再打开 `index.html`：

```bash
python3 -m http.server 8000
```

然后访问 http://localhost:8000 。直接双击 `index.html` 不行——浏览器不允许
WebGL 读取从 `file://` 加载的图片，页面会提示原因。

## 添加片段

需要 ffmpeg、Python 3、numpy、Pillow。

```bash
# 1. 先探测：测出各个面的网点间距，给出候选网格，然后停下
python3 tools/add_clip.py "path/to/HSBC-Iconic-Graphic-Hexagon-Pulse-A-Red-Black.mp4"

# 2. 选一个网格正式导入
python3 tools/add_clip.py "path/to/...Pulse-A...mp4" --grid 96 --name "Pulse A"

# 3. 重新打包
python3 tools/build.py
```

网格为什么要人来定：方形网屏在 45° 方向上也有周期（间距 × √2），探测时经常是这个
对角周期更强；另外有的片子每个面的网点间距不同。所以探测结果会同时列出
"若为对角周期"的换算值。导入后打开 **对比原片**，拖动分界线看网点是否对齐，就能确认。

已验证的网格：

| 片段 | --grid | 网屏 | 与原片的色调误差 |
|---|---|---|---|
| Transfer A | 96 | 欧氏网点（会合并成实色） | 0.84% |
| Movement B | 32 | 圆点（始终分离） | 1.00% |

工具假设标准的 Iconic Graphic 取景：2:1 六边形居中、宽为画面的 60.5%。取景不同的片子
用 `--box x,y,w,h` 指定六边形外框（像素）。导入后预设是自动推断的（循环区间、峰值帧
取自墨量包络），可以直接在 `clips/clips.js` 里改。

## 打包

```bash
python3 tools/build.py                       # -> dist/hexagon-motion-lab.html
python3 tools/build.py --fragment page.html  # 不带 <html>/<head> 外壳的版本，给自带外壳的宿主用
```

## 嵌入与脚本控制

页面加载后暴露 `window.HexMotion`：

```js
HexMotion.set({ speed: 0.8, sustain: 120, fade: 90, inkA: "#db0011" });
HexMotion.params          // 当前全部参数
HexMotion.canvas          // 画布元素
```

参数名与界面一一对应；**复制配置** 按钮会把当前参数以 JSON 复制出来，可以直接传给 `set()`。

## 几个要点

- **循环**：循环区间内的最后若干帧溶回开头，数学上首尾相等，没有接缝。条带上可以直接拖入点和出点。
- **满屏减速 / 峰值停留**：播放头跟着每帧的实测墨量走，越满越慢；峰值停留在指定帧上缓入缓出地驻足，时长以秒计。
- **点的持续 / 消退**：每个格子在一个小的反馈缓冲里跑"起亮 → 保持 → 消退"，以源帧计时，所以不受速度影响、也不会闪烁。Movement B 靠它才会出现完整的六边形。
- **主题**：自动 / 浅色 / 深色，同时切换界面和舞台底色；你手动改过的舞台颜色不会被覆盖。

## 已知限制

- Movement B 的原片在不同的面上用了不同朝向、不同间距的点阵（外三角约 18.5px，内三角约 13.4px）。
  复刻用的是统一的 32 行网格：运动、点径分布、疏密都来自实测，但点的落位是规整的，凑近看与原片不同。
- 对比用的参考视频是原片的黑底，浅色主题下分屏另一侧仍是黑底。
- 场图集是 JPEG（q92），逐点闪烁与原片的相关度约 0.96；需要更高时可以改 `--quality`。
