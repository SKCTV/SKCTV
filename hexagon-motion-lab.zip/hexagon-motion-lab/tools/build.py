#!/usr/bin/env python3
"""Bundle Hexagon Motion Lab into a single self-contained HTML file.

    python3 tools/build.py                 -> dist/hexagon-motion-lab.html (full document)
    python3 tools/build.py --fragment OUT  -> body-only page for hosts that supply their own
                                              <html>/<head> wrapper

Stylesheet and scripts are inlined, and every clip asset named in clips/clips.js
(field sheet, reference video) becomes a data: URI, so the result opens straight
from disk with no server.
"""
import argparse
import base64
import mimetypes
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def data_uri(rel):
    path = os.path.join(ROOT, rel)
    mime = mimetypes.guess_type(path)[0] or "application/octet-stream"
    with open(path, "rb") as f:
        return "data:%s;base64,%s" % (mime, base64.b64encode(f.read()).decode("ascii"))


def inline_clips(js):
    """Swap every local asset path inside the manifest for a data URI."""
    def sub(m):
        rel = m.group(1)
        if not os.path.exists(os.path.join(ROOT, rel)):
            sys.exit("clips.js references a missing file: " + rel)
        return '"%s"' % data_uri(rel)
    return re.sub(r'"(clips/[^"]+\.(?:jpg|jpeg|png|webp|mp4|webm))"', sub, js)


def build(fragment):
    html = read("index.html")

    css = read("src/styles.css")
    html = html.replace('<link rel="stylesheet" href="src/styles.css">', "<style>\n%s</style>" % css)

    def script(m):
        rel = m.group(1)
        body = read(rel)
        if rel == "clips/clips.js":
            body = inline_clips(body)
        return "<script>\n%s</script>" % body.replace("</script", "<\\/script")
    html = re.sub(r'<script src="([^"]+)"></script>', script, html)

    if fragment:
        head = re.search(r"<head>(.*?)</head>", html, re.S).group(1)
        body = re.search(r"<body>(.*?)</body>", html, re.S).group(1)
        # keep the title, fonts and styles; the host provides charset and viewport
        head = "\n".join(l for l in head.splitlines()
                         if not l.startswith("<meta ")).strip()
        html = head + "\n" + body.strip() + "\n"
    return html


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--fragment", metavar="OUT", help="write a body-only page to OUT instead")
    args = ap.parse_args()

    if args.fragment:
        out, html = args.fragment, build(True)
    else:
        out, html = os.path.join(ROOT, "dist", "hexagon-motion-lab.html"), build(False)
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print("wrote %s (%d KB)" % (os.path.relpath(out), len(html.encode("utf-8")) // 1024))


if __name__ == "__main__":
    main()
