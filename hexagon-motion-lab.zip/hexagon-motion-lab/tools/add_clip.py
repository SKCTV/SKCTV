#!/usr/bin/env python3
"""Measure a hexagon motion clip and add it to the lab.

    python3 tools/add_clip.py path/to/clip.mp4                       # probe: suggests grids
    python3 tools/add_clip.py path/to/clip.mp4 --grid 96 --name "Pulse A"

What it does, in order:
  1. Uses the grid you pass with --grid (cell rows across the hexagon height).
     Without --grid it only probes: it measures the dot pitch inside each facet and
     prints the candidates, then stops. Halftone screens are ambiguous here — a square
     screen also repeats at pitch x sqrt(2) on the diagonal, and some clips run a
     different pitch per facet — so the choice is yours; check it with Compare.
  2. Area-averages every frame onto that grid. Each cell's value is its ink
     coverage: distance from the background colour, divided by the distance of solid
     ink measured on full-resolution dot cores. Red-on-black, white-on-black and
     red-on-white clips all work, dense or sparse.
  3. Diffuses values across the masked-out areas so the field is continuous
     for the full-bleed and honeycomb framings.
  4. Packs all frames into one padded JPEG sheet, records the ink envelope, picks
     loop points and a peak frame from it, and encodes a small reference video.
  5. Writes clips/<slug>/field.jpg + ref.mp4 and adds the entry to clips/clips.js.

Needs ffmpeg/ffprobe on PATH, plus numpy and Pillow.
Assumes the HSBC Iconic Graphic framing: a 2:1 hexagon centred in frame at 60.5% of
the picture width. Pass --box x,y,w,h (pixels) for anything framed differently.
"""
import argparse
import json
import math
import os
import re
import subprocess
import sys

import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MANIFEST = os.path.join(ROOT, "clips", "clips.js")
REF_BOX_1080 = (379, 249, 1161, 581)   # hexagon bbox measured on the 1920x1080 masters


def run(cmd, **kw):
    return subprocess.run(cmd, check=True, capture_output=True, **kw)


def probe(path):
    out = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-count_frames",
               "-show_entries", "stream=width,height,r_frame_rate,nb_read_frames",
               "-of", "json", path]).stdout
    st = json.loads(out)["streams"][0]
    num, den = st["r_frame_rate"].split("/")
    return int(st["width"]), int(st["height"]), int(st["nb_read_frames"]), float(num) / float(den)


def frames_rgb(path, vf, w, h):
    """Yield float32 HxWx3 frames after the given filter chain."""
    # convert to RGB *before* any crop: cropping in yuv420p silently rounds the box
    # to even pixels. passthrough stops ffmpeg padding a select() back to constant rate.
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-i", path, "-vf", "format=rgb24," + vf,
                          "-fps_mode", "passthrough", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                         stdout=subprocess.PIPE)
    size = w * h * 3
    while True:
        buf = p.stdout.read(size)
        if len(buf) < size:
            break
        yield np.frombuffer(buf, np.uint8).reshape(h, w, 3).astype(np.float32)
    p.wait()


def art_sdf(gw, gh):
    """Signed distance to the hexagon-minus-hourglass, sampled at cell centres."""
    xs = (np.arange(gw) + 0.5) / gw * 4 - 2
    ys = 1 - (np.arange(gh) + 0.5) / gh * 2
    X, Y = np.meshgrid(xs, ys)
    qx, qy = np.abs(X), np.abs(Y)
    hexd = np.maximum(qy - 1, qx + qy - 2)
    hour = np.maximum(qx - 1, qy - qx)
    return np.maximum(hexd, -hour)


def laplace_fill(f, mask, iters=220):
    g = f.copy()
    g[~mask] = f[mask].mean() if mask.any() else 0.0
    for _ in range(iters):
        n = (np.roll(g, 1, 0) + np.roll(g, -1, 0) + np.roll(g, 1, 1) + np.roll(g, -1, 1)) * 0.25
        n[0, :], n[-1, :], n[:, 0], n[:, -1] = g[1, :], g[-2, :], g[:, 1], g[:, -2]
        g = np.where(mask, f, n)
    return g


def estimate_pitch(path, box, frames):
    """Dot pitch in source pixels.

    Looks only inside the four facets (a 45-degree edge in the window puts a streak
    across the spectrum that can outscore the screen), on frames whose coverage is
    middling (where a halftone screen is strongest), after removing the smooth field
    with a high-pass. Returns the median over all patches and frames.
    """
    x, y, w, h = box
    a = h / 2.0                                    # hexagon half-height in pixels
    # facet interiors, as (cx, cy) in hexagon units and a half-size in units
    patches = [(0.0, -0.62, 0.26), (0.0, 0.62, 0.26), (-1.45, 0.0, 0.24), (1.45, 0.0, 0.24)]

    # rank frames by how close their mean coverage is to 0.4 on a cheap preview
    step = max(1, frames // 60)
    scored = []
    for i, fr in enumerate(frames_rgb(path, "crop=%d:%d:%d:%d,scale=160:80,select='not(mod(n\\,%d))'"
                                       % (w, h, x, y, step), 160, 80)):
        m = fr.max(2)
        if m.max() < 8:
            continue
        cov = m.mean() / max(m.max(), 1.0)
        scored.append((abs(cov - 0.4), i * step))
    picks = [f for _, f in sorted(scored)[:3]] or [frames // 2]

    N = 1024
    c = N // 2
    yy, xx = np.mgrid[0:N, 0:N]
    r = np.hypot(yy - c, xx - c)
    ring = (r > N / 40.0) & (r < N / 4.0)          # pitch between 4 and 40 px
    found = []
    for fidx in picks:
        fr = next(frames_rgb(path, "select='eq(n\\,%d)',crop=%d:%d:%d:%d" % (fidx, w, h, x, y), w, h))
        g = fr.max(2)
        for (ux, uy, hs) in patches:
            px, py, half = int(w / 2 + ux * a), int(h / 2 + uy * a), int(hs * a)
            p = g[max(0, py - half):py + half, max(0, px - half):px + half]
            if p.size < 400 or p.std() < 2:
                continue
            k = 9                                   # high-pass: subtract a box blur
            pad = np.pad(p, k // 2, mode="edge")
            from numpy.lib.stride_tricks import sliding_window_view
            p = p - sliding_window_view(pad, (k, k)).mean((2, 3))
            p = p * np.outer(np.hanning(p.shape[0]), np.hanning(p.shape[1]))
            F = np.abs(np.fft.fftshift(np.fft.fft2(p, s=(N, N))))
            kk = np.argmax(np.where(ring, F, 0))
            found.append(N / r.flat[kk])
    if not found:
        sys.exit("could not see a dot screen; pass --grid")
    return float(np.median(found)), picks[0], found


def next_free_id(existing):
    for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        if ch not in existing:
            return ch
    sys.exit("no free single-letter id left; pass --id")


def read_manifest():
    txt = open(MANIFEST, encoding="utf-8").read()
    m = re.search(r"/\*BEGIN\*/(.*)/\*END\*/", txt, re.S)
    if not m:
        sys.exit("clips.js lost its /*BEGIN*/ ... /*END*/ markers")
    return txt, json.loads(m.group(1))


def write_manifest(txt, data):
    lines = [" %s:%s" % (json.dumps(k), json.dumps(v, ensure_ascii=False, separators=(",", ":")))
             for k, v in data.items()]
    body = "{\n" + ",\n".join(lines) + "\n}"
    txt = re.sub(r"/\*BEGIN\*/.*/\*END\*/", "/*BEGIN*/" + body.replace("\\", "\\\\") + "/*END*/", txt, flags=re.S)
    open(MANIFEST, "w", encoding="utf-8").write(txt)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--name", help="label on the clip switcher (default: from the file name)")
    ap.add_argument("--id", help="manifest key (default: next free letter)")
    ap.add_argument("--grid", type=int, help="cell rows across the hexagon height; omit to probe")
    ap.add_argument("--box", help="hexagon bounding box in source pixels, x,y,w,h")
    ap.add_argument("--quality", type=int, default=92, help="JPEG quality of the field sheet (default 92)")
    ap.add_argument("--no-ref", action="store_true", help="skip the reference video used by Compare")
    args = ap.parse_args()

    src = os.path.abspath(args.video)
    W, H, frames, fps = probe(src)
    print("clip       %dx%d, %d frames @ %.2f fps" % (W, H, frames, fps))

    if args.box:
        box = tuple(int(v) for v in args.box.split(","))
    else:
        s = W / 1920.0
        box = tuple(int(round(v * s)) for v in REF_BOX_1080)
        if abs(H / W - 1080 / 1920) > 0.01:
            print("warning    not 16:9 — the default hexagon box may be off; pass --box")
    x, y, w, h = box

    if args.grid:
        gh = args.grid
        print("grid       %d rows (given)" % gh)
    else:
        _, at, found = estimate_pitch(src, box, frames)
        # cluster the per-patch pitches (within 6%) and report each with its vote count
        clusters = []
        for v in sorted(found):
            if clusters and v <= clusters[-1][-1] * 1.06:
                clusters[-1].append(v)
            else:
                clusters.append([v])
        clusters.sort(key=len, reverse=True)
        print("probe      dot pitch measured in %d facet patches (frames around %d):" % (len(found), at))
        for cl in clusters:
            p = float(np.median(cl))
            print("             %5.1f px  x%-2d  -> --grid %d   (if that is the diagonal: --grid %d)"
                  % (p, len(cl), round(h / p), round(h / (p / math.sqrt(2)))))
        print("           pick one, then rerun with --grid N and check it against the source with Compare.")
        return
    gw = gh * 2

    # background = median colour of the frame border over the whole clip
    border = []
    for fr in frames_rgb(src, "scale=96:54", 96, 54):
        border.append(np.concatenate([fr[0], fr[-1], fr[:, 0], fr[:, -1]]))
    bg = np.median(np.concatenate(border), axis=0)
    print("background rgb(%d, %d, %d)" % tuple(bg))

    cells = []
    for fr in frames_rgb(src, "crop=%d:%d:%d:%d,scale=%d:%d:flags=area" % (w, h, x, y, gw, gh), gw, gh):
        cells.append(np.linalg.norm(fr - bg, axis=2))
    C = np.array(cells, np.float32)
    # Scale by the ink colour itself, measured on full-resolution pixels (dot cores are
    # solid ink). Normalising by the cells' own distribution would inflate sparse clips.
    step = max(1, frames // 8)
    px = []
    for fr in frames_rgb(src, "select='not(mod(n\\,%d))',crop=%d:%d:%d:%d" % (step, w, h, x, y), w, h):
        dist = np.linalg.norm(fr - bg, axis=2)
        px.append(dist[dist > 24])
    px = np.concatenate(px) if px else np.array([1.0])
    ink = float(np.percentile(px, 99.5)) if px.size else 1.0
    print("ink        %.1f from background (full-resolution dot cores)" % ink)
    C = np.clip(C / max(ink, 1.0), 0, 1)
    T = len(C)

    valid = art_sdf(gw, gh) < -0.04
    env = np.array([C[t][valid].mean() for t in range(T)])
    env = env / max(env.max(), 1e-6)
    F = np.array([laplace_fill(C[t], art_sdf(gw, gh) < -0.02) for t in range(T)], np.float32)

    # pack: 1 px edge-replicated padding per tile, sheet kept inside 4096 px
    tw, th = gw + 2, gh + 2
    cols = max(1, min(T, 4096 // tw, int(math.ceil(math.sqrt(T * th / tw)))))
    rows = int(math.ceil(T / cols))
    if rows * th > 4096:
        sys.exit("sheet would be %d px tall; lower --grid" % (rows * th))
    sheet = np.zeros((rows * th, cols * tw), np.uint8)
    for i in range(T):
        r, c = divmod(i, cols)
        sheet[r * th:(r + 1) * th, c * tw:(c + 1) * tw] = np.pad((F[i] * 255).round().astype(np.uint8), 1, mode="edge")

    data_txt, data = read_manifest()
    cid = args.id or next_free_id(data)
    name = args.name or re.sub(r"[-_]+", " ", os.path.splitext(os.path.basename(src))[0])
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or cid.lower()
    out = os.path.join(ROOT, "clips", slug)
    os.makedirs(out, exist_ok=True)
    Image.fromarray(sheet, "L").save(os.path.join(out, "field.jpg"), quality=args.quality, optimize=True, subsampling=0)

    ref = None
    if not args.no_ref:
        run(["ffmpeg", "-v", "error", "-y", "-i", src, "-vf", "scale=560:-2", "-c:v", "libx264",
             "-crf", "28", "-preset", "veryslow", "-pix_fmt", "yuv420p", "-an",
             "-movflags", "+faststart", os.path.join(out, "ref.mp4")])
        ref = "clips/%s/ref.mp4" % slug

    on = np.nonzero(env > 0.12)[0]
    lo, hi = (int(on[0]), int(on[-1])) if len(on) else (0, T - 1)
    xf = max(4, min(40, (hi - lo) // 6))
    peak = int(np.argmax(env))
    merges = float((F[:, valid] > 0.6).mean())       # does the screen ever go solid?
    bright_bg = bg.mean() > 128

    entry = {
        "name": name,
        "field": "clips/%s/field.jpg" % slug,
        "ref": ref or "",
        "frames": T, "cols": cols, "inner": [gw, gh], "size": [cols * tw, rows * th],
        "fps": round(fps, 3),
        "preset": {
            "density": gh, "spot": 0 if merges > 0.05 else 1, "dotMax": 1.0, "feather": 0.4,
            "stagger": 0, "gridAngle": 0, "flicker": 0, "contrast": 1, "bias": 0, "gamma": 1,
            "loopIn": lo, "loopOut": hi, "xfade": xf,
            "peakFrame": peak, "dwell": 0.6, "dwellWidth": 14, "peakLift": 0,
            "sustain": 0, "fade": 0,
        },
        "env": [round(float(v), 3) for v in env],
    }
    if bright_bg:
        entry["note"] = "light background in source; use Theme > Light for a like-for-like look"
    data[cid] = entry
    write_manifest(data_txt, data)

    kb = os.path.getsize(os.path.join(out, "field.jpg")) // 1024
    print("screen     %s, peak frame %d, loop [%d, %d] with %d-frame crossfade"
          % ("euclidean (goes solid)" if entry["preset"]["spot"] == 0 else "circle (stays open)", peak, lo, hi, xf))
    print("wrote      clips/%s/field.jpg (%d KB, %d x %d sheet)%s"
          % (slug, kb, cols * tw, rows * th, " + ref.mp4" if ref else ""))
    print("manifest   clips.js now has %s  ->  run tools/build.py to rebuild dist/" % ", ".join(data.keys()))


if __name__ == "__main__":
    main()
